# Облако «ИИ Мастер» — как поднять (пилот, срез 27)

Что уже готово и проверено (20 проверок, `node --no-warnings tools/tests/cloud-api.js`):
сервер, встроенная база, регистрация и вход, пароли только хэшем, сессии, хранение состояния
на сервере, изоляция данных между людьми, живучесть после перезапуска, отдача страницы приложения.

Осталось: купить сервер, поднять его по шагам ниже, добавить поддомен и HTTPS.
Экран входа в самом приложении — следующий шаг (срез 28).

---

## Шаг 1. Купить сервер (это делает владелец — платит он)

Что брать: **VPS/VDS**, локация **Россия**, ОС **Ubuntu 24.04**,
минимум: 1–2 ядра, 1–2 ГБ памяти, 20–40 ГБ диска. Цена ориентировочно **200–900 ₽/мес**
(рабочий вариант «2 ядра / 2 ГБ / 40 ГБ» — около 900 ₽/мес на Timeweb Cloud).
Подойдут Timeweb Cloud, Selectel, Beget — что удобнее по оплате.

Важно: у хостинга должна быть **веб-консоль** (вход в сервер прямо в браузере) — тогда пароли
никому пересылать не нужно.

## Шаг 2. Поддомен для облака (в личном кабинете REG.RU)

Главный `ii-master.ru` занят сайтом. Для облака добавляем отдельный поддомен:
**`app.ii-master.ru`**, тип **A**, значение — **IP вашего нового сервера** (покажется в кабинете
хостинга после покупки). Ждём 10–60 минут, пока обновится.

## Шаг 3. Установка (одна команда в веб-консоли сервера)

Открыть веб-консоль хостинга (там вы уже под root) и вставить целиком:

```bash
apt-get update && apt-get install -y curl unzip caddy ca-certificates && \
curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && \
apt-get install -y nodejs && \
mkdir -p /opt/ii-master && cd /opt/ii-master && \
curl -fsSL -o app.zip "$ZIP_URL" && unzip -o app.zip && \
printf '%s\n' 'app.ii-master.ru {' '  reverse_proxy 127.0.0.1:8790' '}' > /etc/caddy/Caddyfile && \
systemctl restart caddy && \
printf '%s\n' '[Unit]' 'Description=II Master cloud' 'After=network.target' '' '[Service]' 'WorkingDirectory=/opt/ii-master' 'Environment=CLOUD_PORT=8790' 'Environment=CLOUD_DATA=/opt/ii-master/data' 'ExecStart=/usr/bin/node --no-warnings tools/cloud/server.js' 'Restart=always' 'RestartSec=5' '' '[Install]' 'WantedBy=multi-user.target' > /etc/systemd/system/ii-master.service && \
systemctl daemon-reload && systemctl enable --now ii-master && \
sleep 2 && curl -s http://127.0.0.1:8790/api/health
```

**Проверенная ссылка на архив (путь А, сверено 01.10.2026):**
`https://iimaster-app.github.io/iimaster/deploy/ii-master-cloud.zip` — отдаёт 200 и ровно
10 021 584 байта. Основной домен `ii-master.ru` для этого НЕ годится, пока не выпущен HTTPS
(по HTTPS отвечает `000`). **После установки архив с сайта удалить** — обещано владельцу.

**САМЫЙ НАДЁЖНЫЙ способ (02.10.2026, после того как серийная консоль Timeweb исказила длинную
команду при вставке и владелец вставил её в строку входа): короткая команда + скрипт.**
Владелец логинится в консоли (login: root → пароль, при вводе он НЕ отображается) и вставляет:

```
curl -fsSL https://iimaster-app.github.io/iimaster/deploy/install.sh | bash
```

Скрипт `tools/cloud/install.sh` делает всё то же самое по шагам и печатает `{"ok":true,...}` в конце.
Ссылку на скрипт тоже удалить после установки.

Готовая команда целиком (одной строкой — так надёжнее в веб-консоли, переносы строк она может съесть):

```
apt-get update && apt-get install -y curl unzip caddy ca-certificates && curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt-get install -y nodejs && mkdir -p /opt/ii-master && cd /opt/ii-master && curl -fsSL -o app.zip https://iimaster-app.github.io/iimaster/deploy/ii-master-cloud.zip && unzip -o app.zip && printf '%s\n' 'app.ii-master.ru {' '  reverse_proxy 127.0.0.1:8790' '}' > /etc/caddy/Caddyfile && systemctl restart caddy && printf '%s\n' '[Unit]' 'Description=II Master cloud' 'After=network.target' '' '[Service]' 'WorkingDirectory=/opt/ii-master' 'Environment=CLOUD_PORT=8790' 'Environment=CLOUD_DATA=/opt/ii-master/data' 'ExecStart=/usr/bin/node --no-warnings tools/cloud/server.js' 'Restart=always' 'RestartSec=5' '' '[Install]' 'WantedBy=multi-user.target' > /etc/systemd/system/ii-master.service && systemctl daemon-reload && systemctl enable --now ii-master && sleep 3 && curl -s http://127.0.0.1:8790/api/health
```

**Про Beget (по скриншоту владельца 01.10.2026):** в Санкт-Петербурге «нет свободных ресурсов» —
заказ уйдёт в очередь, сервер создастся не сразу. Меняем регион на **Москву**. Услуга
**«Базы 90 ₽/мес» не нужна** (у нас своя встроенная база), **«Публичный IP» 200 ₽/мес нужен**.
Итого ≈ **790 ₽/мес** (590 + 200), а не 792 ₽. Если и в Москве очередь — брать Timeweb Cloud
(та же конфигурация ≈ 900 ₽/мес, без очереди).

**Важно:** у арендованного VPS файлового менеджера обычно НЕТ (он есть у обычного хостинга сайтов).
У VPS — веб-консоль и SFTP (FileZilla). Поэтому «загрузить файловым менеджером» на VPS, скорее
всего, не получится: используем ссылку выше (путь А, согласован с владельцем).

**Варианты доставки архива (владелец выбрал путь А):**

- **Одной строкой (выбрано):** архив лежит по ссылке, команда скачивает его сама.
- **Файловым менеджером:** только если у хостинга он есть (тогда команда без `curl -o app.zip`).

**Важно про Node:** Ubuntu 24.04 ставит Node 18, а нашей встроенной базе (`node:sqlite`) нужен
**Node 22+**. Поэтому в команде выше Node ставится из официального репозитория NodeSource (версия 22).
Если поставить системный `nodejs` — сервер не запустится, и в журнале будет ошибка про `node:sqlite`.

В конце команда должна ответить что-то вида `{"ok":true,"users":0,...}` — это значит сервер работает.

**HTTPS (сертификат) Caddy получает сам.** Когда DNS поддомена обновится, откройте
`https://app.ii-master.ru/` — сертификат выпустится автоматически, платить не нужно.

## Шаг 4. Проверка

- `https://app.ii-master.ru/api/health` → `{"ok":true,...}`
- `https://app.ii-master.ru/` → страница приложения
- Зарегистрировать первого пользователя (срез 28 добавит экран входа в приложении;
  сейчас можно проверить через `/api/register`).

## Что НЕ решено в этом шаге (честно)

- **Экран входа в приложении** — срез 28: без него обычный человек облаком не воспользуется.
- **Перенос диалогов** из браузера на сервер — срез 28.
- **Бэкапы** — срез 32. Пока данные лежат на одном сервере: если его потерять, потеряем всё.
- **Ключ z.ai**: для пилота у облака будет один общий ключ владельца → **нужны лимиты**,
  иначе один человек сожжёт баланс. Лимиты — срез 29.
- **Платежи и документы** — срез 31, отдельно (юрстатус, оферта, РКН).

## Заметки для меня (не для владельца)

- Порт приложения 8790, сервер сам себе прокси к z.ai ещё НЕ делает — на срезе 28 добавить
  прокси (сейчас в облаке работают только аккаунты и состояние).
- `node:sqlite` помечен как экспериментальный (`--no-warnings` в службе уже учтён).
- Разделение: локальный `tools/serve.js` (порт 8787) остаётся для настольной версии,
  облачный `tools/cloud/server.js` (порт 8790) — для сервера. Не смешивать.
