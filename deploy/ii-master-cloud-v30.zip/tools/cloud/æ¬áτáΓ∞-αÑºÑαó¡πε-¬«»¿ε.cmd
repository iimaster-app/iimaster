@echo off
setlocal
set SERVER=https://app.ii-master.ru
set DEST=%USERPROFILE%\Documents\ИИ Мастер - резервные копии

echo.
echo   Забрать резервную копию с сервера
echo   ---------------------------------
echo   Введите почту и пароль, под которыми вы входите
echo   в приложение на https://app.ii-master.ru
echo.
set EMAIL=
set PASS=
set /p EMAIL=  Почта: 
set /p PASS=  Пароль: 
if "%EMAIL%"=="" goto nomail
if not exist "%DEST%" mkdir "%DEST%"
cd /d "%DEST%"
echo.
echo Забираю копию...
curl -fsS -OJ -X POST -H "Content-Type: application/json" -d "{\"email\":\"%EMAIL%\",\"password\":\"%PASS%\"}" "%SERVER%/api/backup/with-account"
if errorlevel 1 goto failed

echo.
echo   ГОТОВО! Копия лежит здесь:
echo   %DEST%
echo.
echo   Теперь скопируйте этот файл на ВНЕШНИЙ ДИСК и на ФЛЭШКУ.
goto end

:nomail
echo Почта не введена - выходим.
goto end

:failed
echo.
echo   НЕ ПОЛУЧИЛОСЬ.
echo   Если написано 404 - сервер ещё не обновлён: обновите его в браузере
echo   (панель Timeweb, вкладка "Консоль") и запустите файл снова.
echo   Если написано 401 - не подошли почта или пароль.

:end
echo.
pause
