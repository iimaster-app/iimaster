# Сохраняет данные из облака «ИИ Мастер» на компьютер — это и есть резервная копия.
# Никаких паролей сервера и консоли: только почта и пароль от приложения.
# Окно всегда остаётся открытым, чтобы было видно результат.
$ErrorActionPreference = 'Stop'
$server = if ($env:IIM_SERVER) { $env:IIM_SERVER } else { 'https://app.ii-master.ru' }
$dest = Join-Path $env:USERPROFILE 'Documents\ИИ Мастер - резервные копии'

try {
  Write-Host ''
  Write-Host '  Сохранить мои данные из облака «ИИ Мастер»'
  Write-Host '  -----------------------------------------'
  $email = Read-Host '  Почта (от приложения)'
  $sec = Read-Host '  Пароль (от приложения, ввод не отображается)' -AsSecureString
  $pass = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))

  if ([string]::IsNullOrWhiteSpace($email) -or [string]::IsNullOrWhiteSpace($pass)) {
    throw 'Почта и пароль обязательны.'
  }

  if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest | Out-Null }

  Write-Host ''
  Write-Host '  Вхожу на сервер...'
  $login = Invoke-RestMethod -Method Post -Uri ($server + '/api/login') `
    -ContentType 'application/json' `
    -Body (@{ email = $email; password = $pass } | ConvertTo-Json)

  if (-not $login.token) { throw 'Сервер не дал доступ — проверьте почту и пароль.' }

  Write-Host '  Забираю данные...'
  $headers = @{ Authorization = ('Bearer ' + $login.token) }
  $state = Invoke-RestMethod -Method Get -Uri ($server + '/api/state') -Headers $headers

  $stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm'
  $file = Join-Path $dest ('мои данные ' + $stamp + '.json')
  $pack = [ordered]@{
    saved_at = (Get-Date).ToString('s')
    account  = $email
    server   = $server
    state    = $state.state
  }
  $pack | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $file -Encoding UTF8

  $size = [math]::Round((Get-Item -LiteralPath $file).Length / 1KB, 1)
  Write-Host ''
  Write-Host '  ГОТОВО!' -ForegroundColor Green
  Write-Host ('  Файл копии: ' + $file)
  Write-Host ('  Размер: ' + $size + ' КБ')
  Write-Host ''
  Write-Host '  Скопируйте этот файл на ВНЕШНИЙ ДИСК и на ФЛЭШКУ.'
} catch {
  Write-Host ''
  Write-Host ('  НЕ ПОЛУЧИЛОСЬ: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  Если это про почту и пароль — проверьте их (те же, что в приложении).'
}

Write-Host ''
Read-Host '  Нажмите Enter, чтобы закрыть окно'
