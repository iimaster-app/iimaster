@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Сохранить-мои-данные.ps1"
echo.
echo  --- окно можно закрыть ---
pause
