'use strict';

/**
 * Сборщик таблиц Excel (.xlsx) — один код и для компьютера, и для телефона.
 *
 * Почему так: .xlsx — это ZIP с XML-частями (OOXML). На компьютере файл собирает локальный сервер
 * (у него есть Node-модуль zlib), а на телефоне сервера нет — книгу собирает сама страница
 * (сжатие через CompressionStream, а если браузер не умеет — без сжатия, файл просто чуть больше).
 * Поэтому здесь нет ничего, кроме чистого JavaScript: работает и в Node, и в браузере.
 *
 * Умеет: несколько листов, жирные заголовки с заливкой, числа и денежный формат, автофильтр,
 * условное форматирование «полосы данных», формулы и диаграммы (столбцы и круговая).
 *
 * Использование:  const { buildXlsx } = require('../src/xlsx.js');   // или window.XLSX в браузере
 *                 const bytes = await buildXlsx({ sheets: [...], charts: [...] });
 */

/* ---------------- сжатие и контрольные суммы (работает везде) ---------------- */

let CRC_TABLE = null;
function crc32(u8) {
  if (!CRC_TABLE) {
    CRC_TABLE = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      CRC_TABLE[n] = c >>> 0;
    }
  }
  let c = 0xFFFFFFFF;
  for (let i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function hasNodeZlib() {
  return typeof process !== 'undefined' && process.versions && process.versions.node;
}

async function deflateRaw(u8) {
  if (hasNodeZlib()) {
    /* Node: обычный zlib */
    const zlib = require('node:zlib');
    return new Uint8Array(zlib.deflateRawSync(Buffer.from(u8), { level: 9 }));
  }
  if (typeof CompressionStream === 'function') {
    try {
      const stream = new Blob([u8]).stream().pipeThrough(new CompressionStream('deflate-raw'));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch (e) { /* ниже — сохраним без сжатия */ }
  }
  return null;   /* без сжатия: файл больше, но открывается так же */
}

/* ---------------- ZIP ---------------- */

function u32(v) { return [v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF]; }
function u16(v) { return [v & 0xFF, (v >>> 8) & 0xFF]; }

async function zip(files) {
  const enc = new TextEncoder();
  const parts = [];
  const central = [];
  let offset = 0;
  for (const f of files) {
    const name = enc.encode(f.name);
    const raw = (typeof f.data === 'string') ? enc.encode(f.data) : f.data;
    const packed = await deflateRaw(raw);
    const data = packed || raw;
    const method = packed ? 8 : 0;
    const crc = crc32(raw);
    const local = [].concat([0x50, 0x4B, 0x03, 0x04],   /* подпись */
      u16(20), u16(0x0800), u16(method), u16(0), u16(0),
      u32(crc), u32(data.length), u32(raw.length), u16(name.length), u16(0));
    parts.push(new Uint8Array(local), name, data);
    central.push([].concat([0x50, 0x4B, 0x01, 0x02], u16(20), u16(20), u16(0x0800), u16(method),
      u16(0), u16(0), u32(crc), u32(data.length), u32(raw.length), u16(name.length),
      u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset)), name);
    offset += local.length + name.length + data.length;
  }
  const cd = [];
  central.forEach((c) => c.forEach((piece) => cd.push(piece)));
  const cdBytes = flatten(cd);
  const end = flatten([].concat([0x50, 0x4B, 0x05, 0x06], u16(0), u16(0),
    u16(files.length), u16(files.length), u32(cdBytes.length), u32(offset), u16(0)));
  return flatten(parts.concat([cdBytes, end]));
}

function flatten(list) {
  /* элементы могут быть массивами чисел, Uint8Array — или отдельными числами (заголовки ZIP).
     Раньше отдельные числа считались «куском без длины», и каталог архива получался пустым —
     файл .xlsx собирался, но Excel его не открывал (поймано проверкой 28.09.2026). */
  const blocks = [];
  let size = 0;
  list.forEach((x) => {
    if (x && x.length != null) { blocks.push(x); size += x.length; }
    else { blocks.push([x || 0]); size += 1; }
  });
  const out = new Uint8Array(size);
  let at = 0;
  blocks.forEach((x) => { out.set(x, at); at += x.length; });
  return out;
}

/* ---------------- XML-помощники ---------------- */

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
function colName(n) {
  let s = '';
  while (n > 0) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
function cellRef(row, col) { return colName(col) + row; }
function sheetRef(name) { return "'" + String(name).replace(/'/g, "''") + "'!"; }

const S = { plain: 0, header: 1, number: 2, bold: 3, boldNum: 4, money: 5, boldMoney: 6 };
/* Стиль в ячейке можно назвать словом: {f:'SUM(B2:B5)', s:'boldMoney'} — так понятнее в коде
   приложения, чем «магические» числа. Перевод в номер живёт здесь, в одном месте. */
const STYLE_BY_NAME = { plain: S.plain, header: S.header, number: S.number, bold: S.bold,
  boldNum: S.boldNum, money: S.money, boldMoney: S.boldMoney };
function styleOf(v) {
  if (typeof v === 'string') return (STYLE_BY_NAME[v] != null) ? STYLE_BY_NAME[v] : S.plain;
  const n = Number(v);
  return isFinite(n) ? n : S.plain;
}

function stylesXml() {
  return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
    + '<fonts count="3">'
    + '<font><sz val="11"/><name val="Calibri"/></font>'
    + '<font><b/><sz val="11"/><name val="Calibri"/></font>'
    + '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
    + '</fonts>'
    + '<fills count="3">'
    + '<fill><patternFill patternType="none"/></fill>'
    + '<fill><patternFill patternType="gray125"/></fill>'
    + '<fill><patternFill patternType="solid"><fgColor rgb="FF6D28D9"/><bgColor indexed="64"/></patternFill></fill>'
    + '</fills>'
    + '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
    + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    + '<cellXfs count="7">'
    + '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
    + '<xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + '<alignment vertical="center"/></xf>'
    + '<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
    + '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
    + '<xf numFmtId="4" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyNumberFormat="1"/>'
    + '<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
    + '<xf numFmtId="4" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyNumberFormat="1"/>'
    + '</cellXfs>'
    + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
    + '</styleSheet>';
}

function cellXml(row, col, value, defStyle) {
  const ref = cellRef(row, col);
  let v = value, style = defStyle, formula = null, type = null;
  if (v && typeof v === 'object' && !(v instanceof Date)) {
    if (v.s != null) style = v.s;
    if (v.f) formula = v.f;
    if (v.t) type = v.t;
    v = (v.v == null ? '' : v.v);
  }
  if (formula) return '<c r="' + ref + '" s="' + style + '"><f>' + esc(formula) + '</f></c>';
  if (typeof v === 'number' && isFinite(v)) return '<c r="' + ref + '" s="' + style + '"><v>' + v + '</v></c>';
  const text = String(v == null ? '' : v);
  if (text === '') return '<c r="' + ref + '"' + (style ? ' s="' + style + '"' : '') + '/>';
  if (type === 'n' && isFinite(Number(text))) {
    return '<c r="' + ref + '" s="' + style + '"><v>' + Number(text) + '</v></c>';
  }
  return '<c r="' + ref + '" s="' + style + '" t="inlineStr"><is><t xml:space="preserve">'
    + esc(text) + '</t></is></c>';
}

function sheetXml(sheet, drawingId) {
  const rows = sheet.rows || [];
  const cols = rows.reduce((m, r) => Math.max(m, r.length), 0);
  let out = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
    + ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    + (sheet.widths && sheet.widths.length
      ? '<cols>' + sheet.widths.map((w, i) => '<col min="' + (i + 1) + '" max="' + (i + 1)
        + '" width="' + w + '" customWidth="1"/>').join('') + '</cols>'
      : '')
    + '<sheetData>';
  rows.forEach((row, i) => {
    const r = i + 1;
    out += '<row r="' + r + '">';
    row.forEach((value, j) => {
      let def = S.plain;
      if (sheet.header && i === 0) def = S.header;
      else if (sheet.numberStyle && sheet.numberStyle[j] != null) def = sheet.numberStyle[j];
      else if (sheet.bold && sheet.bold.indexOf(j) !== -1) def = S.bold;
      out += cellXml(r, j + 1, value, def);
    });
    out += '</row>';
  });
  out += '</sheetData>';
  if (sheet.filter) out += '<autoFilter ref="A1:' + colName(cols) + rows.length + '"/>';
  (sheet.dataBars || []).forEach((bar, k) => {
    const ref = colName(bar.col) + (sheet.header ? 2 : 1) + ':' + colName(bar.col) + rows.length;
    out += '<conditionalFormatting sqref="' + ref + '"><cfRule type="dataBar" priority="' + (k + 1) + '">'
      + '<dataBar><cfvo type="min"/><cfvo type="max"/><color rgb="FFA855F7"/></dataBar>'
      + '</cfRule></conditionalFormatting>';
  });
  if (drawingId) out += '<drawing r:id="' + drawingId + '"/>';
  out += '</worksheet>';
  return out;
}

function cacheXml(values, isNum) {
  if (!values || !values.length) return '';
  return '<c:ptCount val="' + values.length + '"/>'
    + values.map((v, i) => '<c:pt idx="' + i + '">'
      + (isNum ? '<c:v>' + (isFinite(Number(v)) ? Number(v) : 0) + '</c:v>'
        : '<c:v>' + esc(v) + '</c:v>') + '</c:pt>').join('');
}

function chartXml(ch, index) {
  const cat = ch.cats || [], val = ch.vals || [];
  const ser = '<c:ser><c:idx val="0"/><c:order val="0"/>'
    + '<c:tx><c:v>' + esc(ch.valTitle || 'Значение') + '</c:v></c:tx>'
    + '<c:cat><c:strRef><c:f>' + esc(ch.catRef) + '</c:f><c:strCache>' + cacheXml(cat, false) + '</c:strCache></c:strRef></c:cat>'
    + '<c:val><c:numRef><c:f>' + esc(ch.valRef) + '</c:f><c:numCache>' + cacheXml(val, true) + '</c:numCache></c:numRef></c:val>'
    + '</c:ser>';
  const pie = ch.kind === 'pie';
  const axes = '1111111' + index;
  const axes2 = '2222222' + index;
  const plot = pie
    ? '<c:pieChart><c:varyColors val="1"/>' + ser + '<c:dLbls><c:showPercent val="1"/></c:dLbls></c:pieChart>'
    : '<c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>' + ser
      + '<c:gapWidth val="80"/><c:axId val="' + axes + '"/><c:axId val="' + axes2 + '"/></c:barChart>'
      + '<c:catAx><c:axId val="' + axes + '"/><c:scaling><c:orientation val="minMax"/></c:scaling>'
      + '<c:delete val="0"/><c:axPos val="b"/><c:crossAx val="' + axes2 + '"/></c:catAx>'
      + '<c:valAx><c:axId val="' + axes2 + '"/><c:scaling><c:orientation val="minMax"/></c:scaling>'
      + '<c:delete val="0"/><c:axPos val="l"/><c:crossAx val="' + axes + '"/></c:valAx>';
  return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    + '<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"'
    + ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
    + ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    + '<c:chart>'
    + (ch.title ? '<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:t>' + esc(ch.title)
      + '</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>' : '')
    + '<c:plotArea><c:layout/>' + plot + '</c:plotArea>'
    + '<c:legend><c:legendPos val="b"/><c:overlay val="0"/></c:legend>'
    + '<c:plotVisOnly val="1"/></c:chart></c:chartSpace>';
}

/* ---------------- разбор «человеческого» описания книги ----------------
   Колонки приходят с единицы (как в Excel): money:[3] — деньги в третьей колонке,
   bar:[3] — полосы данных в третьей, bold:[1] — жирным первую.
   Диаграмма описывается колонками и строками (catCol, valCol, from, to) — ссылки собираем сами. */
function normalize(spec) {
  const num = (v) => { const n = Number(v); return isFinite(n) ? n : 0; };
  const money = (list) => {
    const out = {};
    (list || []).forEach((c) => { const n = num(c); if (n > 0) out[n - 1] = S.money; });
    return out;
  };
  const sheets = (spec.sheets || []).map((s) => ({
    name: String(s.name || 'Лист'),
    rows: (s.rows || []).map((row) => (row || []).map((cell) => (
      (cell && typeof cell === 'object' && !(cell instanceof Date) && typeof cell.s === 'string')
        ? Object.assign({}, cell, { s: styleOf(cell.s) })
        : cell))),
    header: !!s.header,
    filter: !!s.filter,
    widths: s.widths || [],
    bold: (s.bold || []).map((c) => num(c) - 1),
    numberStyle: money(s.money),
    dataBars: (s.bar || []).map((c) => ({ col: num(c) })),
  }));
  const colRef = (sheet, col, from, to) => sheetRef(sheet) + '$' + colName(num(col)) + '$'
    + num(from) + ':$' + colName(num(col)) + '$' + num(to);
  const charts = (spec.charts || []).map((c) => ({
    kind: c.kind === 'pie' ? 'pie' : 'bar',
    sheet: String(c.sheet || ''),
    title: String(c.title || ''),
    valTitle: String(c.valTitle || 'Значение'),
    cats: c.cats || [],
    vals: c.vals || [],
    catRef: c.catRef || colRef(c.sheet, c.catCol, c.from, c.to),
    valRef: c.valRef || colRef(c.sheet, c.valCol, c.from, c.to),
  }));
  return { sheets, charts };
}

/* ---------------- сборка книги ---------------- */

async function buildXlsx(rawSpec) {
  const spec = normalize(rawSpec);
  const sheets = (spec.sheets || []).filter((s) => s && s.name);
  if (!sheets.length) throw new Error('нужен хотя бы один лист');
  const charts = (spec.charts || []).filter((c) => c && c.catRef && c.valRef);
  const chartOwner = {};
  charts.forEach((c) => {
    const i = Math.max(0, sheets.findIndex((s) => s.name === c.sheet));
    (chartOwner[i] = chartOwner[i] || []).push(c);
  });

  const files = [];
  const types = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
    '<Default Extension="xml" ContentType="application/xml"/>',
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];

  files.push({ name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    + '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"'
    + ' Target="xl/workbook.xml"/></Relationships>' });

  const wbSheets = [];
  sheets.forEach((s, i) => {
    const id = i + 1;
    let drawingId = null;
    if (chartOwner[i]) {
      drawingId = 'rId' + (chartOwner[i].length + 1);
      const drels = chartOwner[i].map((c, k) => '<Relationship Id="rId' + (k + 1)
        + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart"'
        + ' Target="../charts/chart' + (charts.indexOf(c) + 1) + '.xml"/>').join('')
        + '<Relationship Id="' + drawingId + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing"'
        + ' Target="../drawings/drawing1.xml"/>';
      files.push({ name: 'xl/worksheets/_rels/sheet' + id + '.xml.rels',
        data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + drels + '</Relationships>' });
    }
    files.push({ name: 'xl/worksheets/sheet' + id + '.xml', data: sheetXml(s, drawingId) });
    types.push('<Override PartName="/xl/worksheets/sheet' + id + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>');
    wbSheets.push('<sheet name="' + esc(s.name) + '" sheetId="' + id + '" r:id="rId' + id + '"/>');
  });

  charts.forEach((c, k) => {
    files.push({ name: 'xl/charts/chart' + (k + 1) + '.xml', data: chartXml(c, k + 1) });
    types.push('<Override PartName="/xl/charts/chart' + (k + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>');
  });

  if (Object.keys(chartOwner).length) {
    const anchors = charts.map((c, k) => {
      const fromRow = 2 + k * 16;
      return '<xdr:twoCellAnchor><xdr:from><xdr:col>3</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>'
        + fromRow + '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>'
        + '<xdr:to><xdr:col>12</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>' + (fromRow + 15)
        + '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>'
        + '<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr>'
        + '<xdr:cNvPr id="' + (k + 2) + '" name="Диаграмма ' + (k + 1) + '"/>'
        + '<xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>'
        + '<xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm>'
        + '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart">'
        + '<c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"'
        + ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
        + ' r:id="rId' + (k + 1) + '"/></a:graphicData></a:graphic></xdr:graphicFrame>'
        + '<xdr:clientData/></xdr:twoCellAnchor>';
    }).join('');
    files.push({ name: 'xl/drawings/drawing1.xml',
      data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        + '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"'
        + ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">' + anchors + '</xdr:wsDr>' });
    files.push({ name: 'xl/drawings/_rels/drawing1.xml.rels',
      data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + charts.map((c, k) => '<Relationship Id="rId' + (k + 1)
          + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart"'
          + ' Target="../charts/chart' + (k + 1) + '.xml"/>').join('')
        + '</Relationships>' });
    types.push('<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>');
  }

  files.push({ name: 'xl/workbook.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
    + ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    + '<sheets>' + wbSheets.join('') + '</sheets></workbook>' });
  files.push({ name: 'xl/_rels/workbook.xml.rels',
    data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
      + sheets.map((s, i) => '<Relationship Id="rId' + (i + 1)
        + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"'
        + ' Target="worksheets/sheet' + (i + 1) + '.xml"/>').join('')
      + '<Relationship Id="rId' + (sheets.length + 1)
      + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
      + '</Relationships>' });
  files.push({ name: 'xl/styles.xml', data: stylesXml() });
  files.push({ name: '[Content_Types].xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' + types.join('') + '</Types>' });

  /* [Content_Types].xml — первым, как во всех сборщиках */
  files.sort((a, b) => (a.name === '[Content_Types].xml' ? -1 : b.name === '[Content_Types].xml' ? 1 : 0));
  return zip(files);
}

/* В браузере страница берёт сборщик через window.XLSX; в Node — через require */
if (typeof module !== 'undefined' && module.exports) module.exports = { buildXlsx, normalize, colName, sheetRef, S };
if (typeof window !== 'undefined') window.XLSX = { buildXlsx, normalize, colName, sheetRef, S };
