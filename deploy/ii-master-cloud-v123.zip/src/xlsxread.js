'use strict';
/* ===== Чтение Excel (.xlsx/.xlsm) прямо в приложении =====
   Зачем: до этого «ИИ Мастер» не умел открывать Excel — .xlsx прикреплялся «как есть»,
   модель его не видела, и задача «перенеси данные из одного файла в другой» падала с ошибкой
   сервиса (скриншот владельца 19.10.2026: код 429/1305 после 25 минут ожидания).
   Теперь книга читается на устройстве: ZIP → XML → строки и столбцы. Модель не нужна.

   Формат .xlsx — это ZIP с XML-частями (OOXML): xl/workbook.xml (листы),
   xl/sharedStrings.xml (тексты), xl/worksheets/sheetN.xml (ячейки), xl/styles.xml (форматы).

   Работает и в браузере (DecompressionStream), и в Node (zlib) — чтобы проверять тестами.
   Своя реализация, без внешних библиотек: правило проекта «только свой код». */

/* ---------- байты ---------- */
const u16 = (b, o) => b[o] | (b[o + 1] << 8);
const u32 = (b, o) => ((b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0);

function toBytes(input) {
  if (input instanceof Uint8Array) return input;
  if (input instanceof ArrayBuffer) return new Uint8Array(input);
  if (input && input.buffer instanceof ArrayBuffer) return new Uint8Array(input.buffer, input.byteOffset || 0, input.byteLength);
  throw new Error('ожидал байты файла');
}

const utf8 = (u8) => {
  if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(u8);
  return Buffer.from(u8).toString('utf8');  /* Node без TextDecoder не бывает, но пусть будет */
};

/* ---------- распаковка ---------- */
async function inflateRaw(u8) {
  if (typeof DecompressionStream !== 'undefined') {
    try {
      const stream = new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      const buf = await new Response(stream).arrayBuffer();
      return new Uint8Array(buf);
    } catch (e) { /* ниже попробуем zlib */ }
  }
  try {
    const zlib = require('node:zlib');
    return new Uint8Array(zlib.inflateRawSync(Buffer.from(u8)));
  } catch (e) {
    throw new Error('не могу распаковать книгу: браузер не поддерживает распаковку');
  }
}

/* Разбор ZIP: центральный каталог в конце файла, затем локальные заголовки */
async function unzip(input) {
  const b = toBytes(input);
  let eocd = -1;
  for (let i = b.length - 22; i >= 0 && i > b.length - 66000; i--) {
    if (b[i] === 0x50 && b[i + 1] === 0x4B && b[i + 2] === 0x05 && b[i + 3] === 0x06) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('это не zip-архив (не похоже на .xlsx)');
  const count = u16(b, eocd + 10);
  let off = u32(b, eocd + 16);
  const out = {};
  for (let n = 0; n < count && off + 46 <= b.length; n++) {
    if (u32(b, off) !== 0x02014B50) break;
    const method = u16(b, off + 10);
    const csize = u32(b, off + 20);
    const nameLen = u16(b, off + 28);
    const extraLen = u16(b, off + 30);
    const commentLen = u16(b, off + 32);
    const lho = u32(b, off + 42);
    const name = utf8(b.subarray(off + 46, off + 46 + nameLen));
    const dataStart = lho + 30 + u16(b, lho + 26) + u16(b, lho + 28);
    out[name] = { method, start: dataStart, size: csize };
    off += 46 + nameLen + extraLen + commentLen;
  }
  return {
    names: Object.keys(out),
    has: (name) => !!out[name],
    async text(name) {
      const e = out[name];
      if (!e) return '';
      const raw = b.subarray(e.start, e.start + e.size);
      return utf8(e.method === 0 ? raw : await inflateRaw(raw));
    },
    async bytes(name) {
      const e = out[name];
      if (!e) return new Uint8Array(0);
      const raw = b.subarray(e.start, e.start + e.size);
      return e.method === 0 ? raw : await inflateRaw(raw);
    },
  };
}

/* ---------- XML ---------- */
function unesc(s) {
  return String(s || '')
    .replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

function attrs(tag) {
  const o = {};
  const re = /([\w:.-]+)\s*=\s*"([^"]*)"/g;
  let m;
  while ((m = re.exec(tag))) o[m[1]] = unesc(m[2]);
  return o;
}

/* =ВПР-подобные ссылки на листы: 'Лист 1'!A1:Z50 */
function colToNum(letters) {
  let n = 0;
  const s = String(letters || '').toUpperCase();
  for (let i = 0; i < s.length; i++) n = n * 26 + (s.charCodeAt(i) - 64);
  return n - 1;
}
function numToCol(n) {
  let s = '';
  n = Number(n) + 1;
  while (n > 0) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26); }
  return s;
}

/* ---------- форматы дат ---------- */
const DATE_FMT_IDS = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47];
function looksDate(fmt) {
  const f = String(fmt || '').replace(/"[^"]*"/g, '').replace(/\[[^\]]*\]/g, '');
  return /[dmy]/i.test(f) && !/[#0]/.test(f.slice(0, 2));
}
function excelDate(serial, withTime) {
  const ms = Math.round((serial - 25569) * 86400000);
  const d = new Date(ms);
  if (isNaN(d.getTime())) return serial;
  const p = (n) => String(n).padStart(2, '0');
  const date = p(d.getUTCDate()) + '.' + p(d.getUTCMonth() + 1) + '.' + d.getUTCFullYear();
  if (!withTime) return date;
  return date + ' ' + p(d.getUTCHours()) + ':' + p(d.getUTCMinutes());
}

/* ---------- сборка стилей: индекс ячейки → формат числа ---------- */
function parseStyles(xml) {
  const fmtBy = {};
  const reN = /<numFmt[^>]*>/g;
  let m;
  while ((m = reN.exec(xml))) {
    const a = attrs(m[0]);
    if (a.numFmtId != null) fmtBy[Number(a.numFmtId)] = a.formatCode || '';
  }
  const xfs = [];
  const blk = /<cellXfs[^>]*>([\s\S]*?)<\/cellXfs>/.exec(xml);
  if (blk) {
    const reX = /<xf[^>]*>/g;
    while ((m = reX.exec(blk[1]))) {
      const a = attrs(m[0]);
      xfs.push(Number(a.numFmtId || 0));
    }
  }
  return (styleIndex) => {
    const id = xfs[Number(styleIndex) || 0];
    if (id == null) return { date: false };
    if (DATE_FMT_IDS.indexOf(id) >= 0) return { date: true, time: id === 22 || id === 21 || id === 45 || id === 47 };
    const fmt = fmtBy[id];
    if (fmt && looksDate(fmt)) return { date: true, time: /[hs]/i.test(fmt) };
    return { date: false };
  };
}

/* ---------- строки общего словаря ---------- */
function parseShared(xml) {
  const list = [];
  const re = /<si>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = re.exec(xml))) {
    let text = '';
    const reT = /<t[^>]*>([\s\S]*?)<\/t>/g;
    let t;
    while ((t = reT.exec(m[1]))) text += unesc(t[1]);
    list.push(text);
  }
  return list;
}

/* ---------- лист ---------- */
function parseSheet(xml, shared, styleOf) {
  const cells = [];
  let maxRow = 0, maxCol = 0;
  const reRow = /<row[^>]*r="(\d+)"[^>]*>([\s\S]*?)<\/row>/g;
  let r;
  const rowsByNum = {};
  while ((r = reRow.exec(xml))) {
    const rowNum = Number(r[1]);
    const cellsXml = r[2];
    const reC = /<c([^>]*?)\/>|<c([^>]*?)>([\s\S]*?)<\/c>/g;
    let c;
    const out = {};
    while ((c = reC.exec(cellsXml))) {
      const a = attrs(c[1] != null ? c[1] : c[2]);
      const ref = a.r || '';
      const letters = (ref.match(/^[A-Z]+/i) || [''])[0];
      const col = letters ? colToNum(letters) : Object.keys(out).length;
      const type = a.t || '';
      const inner = c[3] || '';
      let val = null;
      if (type === 's') {
        const idx = Number((/<v>([\s\S]*?)<\/v>/.exec(inner) || [])[1]);
        val = shared[idx] != null ? shared[idx] : '';
      } else if (type === 'inlineStr') {
        let text = '';
        const reT = /<t[^>]*>([\s\S]*?)<\/t>/g;
        let t;
        while ((t = reT.exec(inner))) text += unesc(t[1]);
        val = text;
      } else if (type === 'str') {
        val = unesc((/<v>([\s\S]*?)<\/v>/.exec(inner) || [])[1] || '');
      } else if (type === 'b') {
        val = (/(<v>1<\/v>)/.test(inner)) ? 'ИСТИНА' : 'ЛОЖЬ';
      } else {
        const raw = (/<v>([\s\S]*?)<\/v>/.exec(inner) || [])[1];
        if (raw == null || raw === '') val = null;
        else {
          const num = Number(raw);
          if (!isFinite(num)) val = unesc(raw);
          else {
            const st = styleOf(a.s);
            val = st.date && num > 0 ? excelDate(num, st.time) : num;
          }
        }
      }
      out[col] = val;
      if (col > maxCol) maxCol = col;
    }
    rowsByNum[rowNum] = out;
    if (rowNum > maxRow) maxRow = rowNum;
  }
  /* пропуски в нумерации строк и столбцов заполняем пустыми ячейками - номер строки = индекс+1 */
  for (let i = 1; i <= maxRow; i++) {
    const src = rowsByNum[i] || {};
    const line = [];
    for (let j = 0; j <= maxCol; j++) line.push(src[j] != null ? src[j] : null);
    cells.push(line);
  }
  return cells;
}

/* ---------- главная функция ---------- */
async function readXlsx(input) {
  const zip = await unzip(input);
  if (!zip.has('xl/workbook.xml')) throw new Error('внутри нет книги Excel (xl/workbook.xml)');

  const wbXml = await zip.text('xl/workbook.xml');
  const relsXml = zip.has('xl/_rels/workbook.xml.rels') ? await zip.text('xl/_rels/workbook.xml.rels') : '';
  const relTarget = {};
  {
    const re = /<Relationship[^>]*>/g;
    let m;
    while ((m = re.exec(relsXml))) {
      const a = attrs(m[0]);
      if (a.Id && a.Target) relTarget[a.Id] = a.Target.replace(/^\/?xl\//, '').replace(/^\.\//, '');
    }
  }
  const sheetsMeta = [];
  {
    const re = /<sheet[^>]*>/g;
    let m;
    while ((m = re.exec(wbXml))) {
      const a = attrs(m[0]);
      if (!a.name) continue;
      sheetsMeta.push({ name: a.name, rid: a['r:id'] || a.id || '' });
    }
  }
  const shared = zip.has('xl/sharedStrings.xml') ? parseShared(await zip.text('xl/sharedStrings.xml')) : [];
  const styleOf = zip.has('xl/styles.xml') ? parseStyles(await zip.text('xl/styles.xml')) : () => ({ date: false });

  const sheets = [];
  for (let i = 0; i < sheetsMeta.length; i++) {
    const meta = sheetsMeta[i];
    const target = relTarget[meta.rid] || ('worksheets/sheet' + (i + 1) + '.xml');
    const path = 'xl/' + target.replace(/^xl\//, '');
    if (!zip.has(path)) continue;
    const xml = await zip.text(path);
    let rows = parseSheet(xml, shared, styleOf);
    /* Excel хранит лишние пустые строки/столбцы - подчищаем хвост */
    while (rows.length && rows[rows.length - 1].every((v) => v == null || v === '')) rows.pop();
    rows = rows.map((line) => {
      const copy = line.slice();
      while (copy.length && (copy[copy.length - 1] == null || copy[copy.length - 1] === '')) copy.pop();
      return copy;
    });
    sheets.push({ name: meta.name, rows });
  }
  if (!sheets.length) throw new Error('в книге нет ни одного листа с данными');
  return { sheets };
}

if (typeof module !== 'undefined' && module.exports) module.exports = { readXlsx, unzip, parseSheet, parseShared, parseStyles, numToCol, colToNum };
if (typeof window !== 'undefined') window.XLSXREAD = { readXlsx, unzip, numToCol, colToNum };
