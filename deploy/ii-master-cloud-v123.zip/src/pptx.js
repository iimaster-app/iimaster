'use strict';

/**
 * Сборщик настоящих презентаций PowerPoint (.pptx) — один код для компьютера, телефона и Node.
 *
 * Почему свой: .pptx — это ZIP с XML-частями (OOXML PresentationML). Готовых библиотек у нас нет
 * (и на телефон их не поставить), поэтому собираем сами — ровно как .xlsx и .docx. ZIP берём из
 * src/xlsx.js (одна проверенная реализация на весь проект), поэтому перед сборкой .pptx нужен
 * загруженный сборщик таблиц (в браузере это window.XLSX.zip).
 *
 * Что делает: слайды 16:9, каждый слайд — заголовок и список тезисов. Форматирование задаём прямо
 * в слайде (шрифт, размер, цвет), поэтому вид не зависит от темы. Шрифт вшивать НЕ нужно:
 * Calibri/Arial есть в системе, и кириллица отображается правильно.
 *
 * Использование:  const b = await buildPptx({ slides:[{title:'Слайд 1', bullets:['раз','два']}] });
 *                 (в браузере — window.PPTX.buildPptx, в Node — require('../src/pptx.js'))
 */

/* ---------------- мелкие помощники ---------------- */

function xmlEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
    /* управляющие символы XML недопустимы — иначе файл не откроется */
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ' ');
}

function zipFn() {
  if (typeof window !== 'undefined' && window.XLSX && window.XLSX.zip) return window.XLSX.zip;
  if (typeof module !== 'undefined' && module.exports) {
    try { return require('./xlsx.js').zip; } catch (e) { /* ниже — скажем честно */ }
  }
  return null;
}

const XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';

/* Ссылки на пространства имён — они повторяются во всех частях PresentationML */
const NS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
  + 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
  + 'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';

const REL_NS = 'xmlns="http://schemas.openxmlformats.org/package/2006/relationships"';
const T_CONTENT = 'http://schemas.openxmlformats.org/package/2006/relationships';
const R_OFFICE = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

/* Размер слайда 16:9 в EMU (как в PowerPoint) */
const SLIDE_W = 12192000, SLIDE_H = 6858000;

/* ---------------- разбор ответа модели на слайды ---------------- */

/* Заголовок слайда: «## Слайд 1. Название», «# Название», «Слайд 3: Итоги» */
function slideTitleOf(line) {
  let t = String(line || '').replace(/^\s*#{1,6}\s+/, '').replace(/\*\*/g, '').trim();
  t = t.replace(/^(слайд|slide)\s*\d+\s*[.):\-—]?\s*/i, '').trim();
  return t;
}
function isHeadingLine(line) { return /^\s*#{1,6}\s+\S/.test(String(line || '')); }
function isBulletLine(line) { return /^\s*(?:[-•*]|\d+[.)])\s+\S/.test(String(line || '')); }
function bulletTextOf(line) {
  return String(line || '')
    .replace(/^\s*(?:[-•*]|\d+[.)])\s+/, '')
    .replace(/\*\*/g, '').replace(/`/g, '')
    .replace(/\[([^\]\[]+)\]\([^)]*\)/g, '$1')
    .replace(/\s+/g, ' ').trim();
}

/**
 * Превращает ответ модели (markdown) в слайды.
 * Правила: строка с «#» — заголовок нового слайда; строка «- …» — тезис; обычный текст —
 * тезис текущего слайда, а если тезисы уже были — заголовок нового слайда.
 */
function slidesFromMarkdown(md) {
  const out = [];
  let cur = null;
  String(md == null ? '' : md).replace(/\r/g, '').split('\n').forEach(function (raw) {
    const line = raw.trim();
    if (!line) return;
    if (isHeadingLine(line)) {
      cur = { title: slideTitleOf(line) || 'Слайд', bullets: [] };
      out.push(cur);
      return;
    }
    if (isBulletLine(line)) {
      if (!cur) { cur = { title: '', bullets: [] }; out.push(cur); }
      const b = bulletTextOf(line);
      if (b) cur.bullets.push(b);
      return;
    }
    const text = bulletTextOf(line);
    if (!text) return;
    if (!cur) { cur = { title: text, bullets: [] }; out.push(cur); }
    else if (cur.bullets.length) { cur = { title: text, bullets: [] }; out.push(cur); }
    else cur.bullets.push(text);
  });
  /* Приводим к разумным размерам: слишком длинную презентацию не показывать целиком */
  const slides = out.slice(0, 60).map(function (s) {
    return {
      title: String(s.title || '').slice(0, 120),
      bullets: s.bullets.slice(0, 12).map(function (b) { return String(b).slice(0, 240); }),
    };
  });
  /* Если разметки не было вовсе — кладём текст одним слайдом, чтобы файл не был пустым */
  if (!slides.length) slides.push({ title: 'Презентация', bullets: ['Текст не разобран на слайды'] });
  return slides;
}

/* ---------------- части файла ---------------- */

function bulletParagraph(text, lvl) {
  const t = xmlEsc(text);
  return '<a:p><a:pPr lvl="' + lvl + '" marL="' + (342900 + lvl * 342900) + '" indent="-342900">'
    + '<a:buChar char="•"/></a:pPr>'
    + '<a:r><a:rPr lang="ru-RU" sz="2000" dirty="0"/><a:t>' + t + '</a:t></a:r></a:p>';
}
function titleShape(text) {
  return '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Заголовок"/>'
    + '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>'
    + '<p:spPr><a:xfrm><a:off x="838200" y="365760"/><a:ext cx="10515600" cy="1325563"/></a:xfrm>'
    + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>'
    + '<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r>'
    + '<a:rPr lang="ru-RU" sz="4000" b="1" dirty="0"><a:solidFill><a:srgbClr val="1B1035"/></a:solidFill>'
    + '<a:latin typeface="Calibri Light"/></a:rPr><a:t>' + xmlEsc(text) + '</a:t></a:r></a:p></p:txBody></p:sp>';
}
function bodyShape(bullets) {
  const ps = (bullets && bullets.length ? bullets : [''])
    .map(function (b) { return bulletParagraph(b, 0); }).join('');
  return '<p:sp><p:nvSpPr><p:cNvPr id="3" name="Текст слайда"/>'
    + '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr>'
    + '<p:spPr><a:xfrm><a:off x="838200" y="1828800"/><a:ext cx="10515600" cy="4525963"/></a:xfrm>'
    + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>'
    + '<p:txBody><a:bodyPr/><a:lstStyle/>' + ps + '</p:txBody></p:sp>';
}
function emptyTree() {
  return '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
    + '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
    + '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree>';
}

function slideXml(slide) {
  return XML_HEAD + '<p:sld ' + NS + '>'
    + '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
    + '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
    + '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
    + titleShape(slide.title || '')
    + bodyShape(slide.bullets)
    + '</p:spTree></p:cSld>'
    + '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
}

function slideRelXml() {
  return XML_HEAD + '<Relationships ' + REL_NS + '>'
    + '<Relationship Id="rId1" Type="' + R_OFFICE + '/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
    + '</Relationships>';
}

function slideMasterXml() {
  return XML_HEAD + '<p:sldMaster ' + NS + '>'
    + '<p:cSld>' + emptyTree() + '</p:cSld>'
    + '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" '
    + 'accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
    + '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
    + '<p:txStyles>'
    + '<p:titleStyle><a:lvl1pPr algn="l"><a:defRPr sz="4000" b="1" dirty="0">'
    + '<a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="Calibri Light"/></a:defRPr></a:lvl1pPr></p:titleStyle>'
    + '<p:bodyStyle><a:lvl1pPr marL="342900" indent="-342900"><a:buChar char="\u2022"/>'
    + '<a:defRPr sz="2000" dirty="0"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill>'
    + '<a:latin typeface="Calibri"/></a:defRPr></a:lvl1pPr></p:bodyStyle>'
    + '<p:otherStyle><a:defPPr><a:defRPr lang="ru-RU"/></a:defPPr></p:otherStyle>'
    + '</p:txStyles></p:sldMaster>';
}

function slideMasterRelXml() {
  return XML_HEAD + '<Relationships ' + REL_NS + '>'
    + '<Relationship Id="rId1" Type="' + R_OFFICE + '/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
    + '<Relationship Id="rId2" Type="' + R_OFFICE + '/theme" Target="../theme/theme1.xml"/>'
    + '</Relationships>';
}

function slideLayoutXml() {
  return XML_HEAD + '<p:sldLayout ' + NS + ' type="blank" preserve="1">'
    + '<p:cSld name="Пустой слайд">' + emptyTree() + '</p:cSld>'
    + '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>';
}

function slideLayoutRelXml() {
  return XML_HEAD + '<Relationships ' + REL_NS + '>'
    + '<Relationship Id="rId1" Type="' + R_OFFICE + '/slideMaster" Target="../slideMasters/slideMaster1.xml"/>'
    + '</Relationships>';
}

function themeXml() {
  const ln = (w) => '<a:ln w="' + w + '" cap="flat" cmpd="sng" algn="ctr">'
    + '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>';
  const fill = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>';
  return XML_HEAD + '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="ИИ Мастер">'
    + '<a:themeElements>'
    + '<a:clrScheme name="ИИ Мастер">'
    + '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>'
    + '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>'
    + '<a:dk2><a:srgbClr val="1B1035"/></a:dk2><a:lt2><a:srgbClr val="F2EEFB"/></a:lt2>'
    + '<a:accent1><a:srgbClr val="7B2FF7"/></a:accent1><a:accent2><a:srgbClr val="00D4FF"/></a:accent2>'
    + '<a:accent3><a:srgbClr val="FF3DDA"/></a:accent3><a:accent4><a:srgbClr val="2BD9A5"/></a:accent4>'
    + '<a:accent5><a:srgbClr val="FFB020"/></a:accent5><a:accent6><a:srgbClr val="4C6FFF"/></a:accent6>'
    + '<a:hlink><a:srgbClr val="00A0FF"/></a:hlink><a:folHlink><a:srgbClr val="B000A0"/></a:folHlink>'
    + '</a:clrScheme>'
    + '<a:fontScheme name="ИИ Мастер">'
    + '<a:majorFont><a:latin typeface="Calibri Light"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>'
    + '<a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont>'
    + '</a:fontScheme>'
    + '<a:fmtScheme name="ИИ Мастер">'
    + '<a:fillStyleLst>' + fill + fill + fill + '</a:fillStyleLst>'
    + '<a:lnStyleLst>' + ln(6350) + ln(12700) + ln(19050) + '</a:lnStyleLst>'
    + '<a:effectStyleLst>'
    + '<a:effectStyle><a:effectLst/></a:effectStyle>'
    + '<a:effectStyle><a:effectLst/></a:effectStyle>'
    + '<a:effectStyle><a:effectLst/></a:effectStyle>'
    + '</a:effectStyleLst>'
    + '<a:bgFillStyleLst>' + fill + fill + fill + '</a:bgFillStyleLst>'
    + '</a:fmtScheme></a:themeElements>'
    + '<a:objectDefaults/><a:extraClrSchemeLst/></a:theme>';
}

function presentationXml(count) {
  let ids = '';
  for (let i = 0; i < count; i++) ids += '<p:sldId id="' + (256 + i) + '" r:id="rId' + (2 + i) + '"/>';
  return XML_HEAD + '<p:presentation ' + NS + ' saveSubsetFonts="1">'
    + '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
    + '<p:sldIdLst>' + ids + '</p:sldIdLst>'
    + '<p:sldSz cx="' + SLIDE_W + '" cy="' + SLIDE_H + '"/>'
    + '<p:notesSz cx="6858000" cy="9144000"/>'
    + '</p:presentation>';
}

function presentationRelXml(count) {
  let rels = '<Relationship Id="rId1" Type="' + R_OFFICE + '/slideMaster" Target="slideMasters/slideMaster1.xml"/>';
  for (let i = 0; i < count; i++)
    rels += '<Relationship Id="rId' + (2 + i) + '" Type="' + R_OFFICE + '/slide" Target="slides/slide' + (i + 1) + '.xml"/>';
  rels += '<Relationship Id="rId' + (2 + count) + '" Type="' + R_OFFICE + '/theme" Target="theme/theme1.xml"/>';
  return XML_HEAD + '<Relationships ' + REL_NS + '>' + rels + '</Relationships>';
}

function contentTypesXml(count) {
  let over = '<Override PartName="/ppt/presentation.xml" '
    + 'ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
    + '<Override PartName="/ppt/slideMasters/slideMaster1.xml" '
    + 'ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>'
    + '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" '
    + 'ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
    + '<Override PartName="/ppt/theme/theme1.xml" '
    + 'ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>';
  for (let i = 0; i < count; i++)
    over += '<Override PartName="/ppt/slides/slide' + (i + 1) + '.xml" '
      + 'ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>';
  return XML_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    + '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    + '<Default Extension="xml" ContentType="application/xml"/>' + over + '</Types>';
}

function rootRelXml() {
  return XML_HEAD + '<Relationships ' + REL_NS + '>'
    + '<Relationship Id="rId1" Type="' + R_OFFICE + '/officeDocument" Target="ppt/presentation.xml"/>'
    + '</Relationships>';
}

/**
 * Собирает .pptx и возвращает байты (Uint8Array).
 * slides: [{ title:'…', bullets:['…','…'] }] — или передайте { markdown:'…' }, и слайды разберутся сами.
 */
async function buildPptx(opts) {
  const o = opts || {};
  const slides = (o.slides && o.slides.length)
    ? o.slides.map(function (s) { return { title: s.title || '', bullets: s.bullets || [] }; })
    : slidesFromMarkdown(o.markdown || '');
  if (!slides.length) throw new Error('нет слайдов для презентации');

  const zip = zipFn();
  if (!zip) throw new Error('нужен сборщик ZIP (src/xlsx.js)');

  const files = [];
  files.push({ name: '[Content_Types].xml', data: contentTypesXml(slides.length) });
  files.push({ name: '_rels/.rels', data: rootRelXml() });
  files.push({ name: 'ppt/presentation.xml', data: presentationXml(slides.length) });
  files.push({ name: 'ppt/_rels/presentation.xml.rels', data: presentationRelXml(slides.length) });
  files.push({ name: 'ppt/slideMasters/slideMaster1.xml', data: slideMasterXml() });
  files.push({ name: 'ppt/slideMasters/_rels/slideMaster1.xml.rels', data: slideMasterRelXml() });
  files.push({ name: 'ppt/slideLayouts/slideLayout1.xml', data: slideLayoutXml() });
  files.push({ name: 'ppt/slideLayouts/_rels/slideLayout1.xml.rels', data: slideLayoutRelXml() });
  files.push({ name: 'ppt/theme/theme1.xml', data: themeXml() });
  slides.forEach(function (s, i) {
    files.push({ name: 'ppt/slides/slide' + (i + 1) + '.xml', data: slideXml(s) });
    files.push({ name: 'ppt/slides/_rels/slide' + (i + 1) + '.xml.rels', data: slideRelXml() });
  });
  return zip(files);
}

if (typeof module !== 'undefined' && module.exports) module.exports = { buildPptx, slidesFromMarkdown };
if (typeof window !== 'undefined') window.PPTX = { buildPptx, slidesFromMarkdown };
