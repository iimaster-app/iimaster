'use strict';

/**
 * Облачный сервер «ИИ Мастер» - пилот, срез 27 (01.10.2026).
 *
 * Задача среза: приложение должно открываться с любого телефона, а данные (диалоги, агенты,
 * настройки, Баксы) жить на сервере, а не в браузере. Это первый шаг: сервер + база + аккаунты.
 * Экран входа в самом приложении - следующий шаг (срез 28).
 *
 * Решения:
 *  - База - встроенная в Node `node:sqlite` (ничего не компилируется, на сервере не нужны библиотеки).
 *  - Пароли - только в виде хэша scrypt со своей солью (`node:crypto`), открытый пароль не хранится.
 *  - Токены сессии - случайные 32 байта; в базе лежит только их SHA-256 (утечка базы не даёт войти).
 *  - SQL - только параметризованный (никаких склеек строк).
 *  - Данные строго разделены по пользователю: любой запрос к состоянию идёт через его user_id.
 *
 * Запуск:  node tools/cloud/server.js          (порт 8790)
 *          CLOUD_PORT=8080 CLOUD_DATA=/opt/ii-master/data node tools/cloud/server.js
 */

const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

/* У api.z.ai есть и IPv4, и IPv6. Если у провайдера IPv6 не работает, запрос уходит в «мёртвую»
   сеть и падает. Ставим приоритет IPv4 - как в локальном сервере (tools/serve.js). */
try { dns.setDefaultResultOrder('ipv4first'); } catch (e) { /* старая версия Node */ }

const ROOT = path.resolve(__dirname, '..', '..');
const DATA_DIR = process.env.CLOUD_DATA ? path.resolve(process.env.CLOUD_DATA) : path.join(ROOT, 'data');
const PORT = Number(process.env.CLOUD_PORT || 8790);
const MAX_BODY = 1024 * 1024;          /* 1 МБ на запрос - состояние, а не файлы */
const MAX_VALUE = 200 * 1024;          /* 200 КБ на одно значение состояния */
const MIN_PASS = 8;

/* Лимит трат на человека в день, в рублях. Баксы считаем по курсу приложения.
   Владелец меняет переменной CLOUD_LIMIT_RUB при запуске службы; 0 - без ограничения. */
/* Лимит трат в рублях на человека в день. Берём из простого файла limit.txt (там только число)
   или из переменной. Владелец меняет короткой командой БЕЗ подчёркиваний:
   echo 300 > /opt/ii-master/limit.txt   (потом systemctl restart ii-master) */
const LIMIT_RUB = (function () {
  if (process.env.CLOUD_LIMIT_RUB) return Number(process.env.CLOUD_LIMIT_RUB);
  try {
    const n = Number(fs.readFileSync(path.join(path.dirname(DATA_DIR), 'limit.txt'), 'utf8').trim());
    if (Number.isFinite(n) && n >= 0) return n;
  } catch (e) { /* файла нет - значение по умолчанию */ }
  return 100;
})();
const BAKS_PER_RUB = 11666.67;
/* Приветственный бонус: даётся ОДИН раз на аккаунт (баланс общий для облака, ПК и телефона) */
const WELCOME_BAKS = Math.max(0, Math.floor(Number(process.env.CLOUD_WELCOME_BAKS || 1000000)));
const LIMIT_BAKS = LIMIT_RUB > 0 ? Math.floor(LIMIT_RUB * BAKS_PER_RUB) : 0;
/* ===== ОБЩИЙ КЛЮЧ (просьба владельца 15.10.2026) =====
   Пользователю НЕ нужно вставлять свои ключи: приложение спрашивает наш сервер, а сервер зовёт модель
   НАШИМ ключом (переменная окружения). Ключ остаётся на сервере и в приложение не попадает.
   За каждый ответ списываются Баксы, дневной лимит общий с остальными расходами. */
const MODEL_KEY = String(process.env.CLOUD_MODEL_KEY || '').trim();                 /* наш ключ (z.ai) */
const MODEL_BASE = String(process.env.CLOUD_MODEL_BASE || 'https://api.z.ai/api/paas/v4').replace(/\/+$/, '');
const MODEL_NAME = String(process.env.CLOUD_MODEL || 'glm-4.5-flash').trim();       /* бесплатная модель */
const MODEL_VISION = String(process.env.CLOUD_MODEL_VISION || 'glm-4.6v-flash').trim(); /* разбор картинок */
const ASSIST_RUB = Math.max(0, Number(process.env.CLOUD_ASSIST_RUB || 1.5));        /* себестоимость ответа */
const ASSIST_BAKS = Math.round(ASSIST_RUB * BAKS_PER_RUB);
function assistantOn() { return !!MODEL_KEY; }
function todayKey() { return new Date().toISOString().slice(0, 10); }
function spentTodayBaks(userId) {
  return db.prepare('SELECT COALESCE(SUM(baks), 0) AS s FROM spend WHERE user_id = ? AND day = ?')
    .get(userId, todayKey()).s;
}

/* ---------- резервные копии (срез 32) ----------
   Правило владельца: три копии на трёх разных носителях (оригинал на сервере + внешний диск +
   флэшка). Здесь делается первая часть: сервер сам раз в сутки снимает копию базы и хранит
   последние N. Копия снимается командой VACUUM INTO - это безопасно даже во время работы
   (обычное копирование файла может поймать базу «на полуслове»).
   Забрать копию на компьютер владельца можно по ключу: /api/backup/latest?key=… */
const BACKUP_DIR = process.env.CLOUD_BACKUP_DIR || path.join(path.dirname(DATA_DIR), 'backups');
const BACKUP_KEEP = Number(process.env.CLOUD_BACKUP_KEEP || 14);
const KEY_FILE = path.join(path.dirname(DATA_DIR), 'key.txt');
/* Ключ для скачивания копий. Владельцу НЕ нужно ничего придумывать и вводить команды с
   подчёркиваниями: сервер сам создаёт ключ при первом запуске и кладёт его в файл key.txt.
   Прочитать: cat /opt/ii-master/key.txt */
const BACKUP_KEY = (function () {
  const fromEnv = String(process.env.CLOUD_BACKUP_KEY || '');
  if (fromEnv) return fromEnv;
  try {
    const saved = fs.readFileSync(KEY_FILE, 'utf8').trim();
    if (saved) return saved;
  } catch (e) { /* файла ещё нет */ }
  const fresh = crypto.randomBytes(12).toString('hex');
  try { fs.writeFileSync(KEY_FILE, fresh, 'utf8'); } catch (e) { /* не смогли сохранить - покажем в консоли */ }
  return fresh;
})();
fs.mkdirSync(BACKUP_DIR, { recursive: true });

function makeBackup(reason) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(BACKUP_DIR, 'cloud-' + stamp + '.db');
  try {
    db.exec("VACUUM INTO '" + file.replace(/'/g, "''") + "'");
    const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
    for (const old of files.slice(0, Math.max(0, files.length - BACKUP_KEEP))) {
      try { fs.unlinkSync(path.join(BACKUP_DIR, old)); } catch (e) { /* не критично */ }
    }
    console.log('[резерв] копия готова: ' + path.basename(file) + ' (' + reason + ')');
    return path.basename(file);
  } catch (e) {
    console.log('[резерв] НЕ удалось сделать копию: ' + (e && e.message ? e.message : e));
    return null;
  }
}

/* Проверяем раз в час: если за сегодня копии ещё нет - делаем. Так копия появится даже после
   перезагрузки сервера, и не нужен внешний планировщик. */
function backupTick() {
  try {
    const day = todayKey();
    const has = fs.readdirSync(BACKUP_DIR).some((f) => f.indexOf(day) !== -1);
    if (!has) makeBackup('по расписанию');
  } catch (e) { /* каталог недоступен - уже сообщили при создании копии */ }
}
setInterval(backupTick, 3600000);

fs.mkdirSync(DATA_DIR, { recursive: true });

/* Robokassa (срез 31, шаг 3). Пока переменные пусты - работает тестовый режим.
   Когда владелец впишет данные в /opt/ii-master/pay.env и перезапустит службу - включится
   боевой приём платежей (ссылка на оплату + зачисление по ResultURL). */
const RB_LOGIN = String(process.env.ROBOKASSA_LOGIN || '').trim();
const RB_PASS1 = String(process.env.ROBOKASSA_PASS1 || '').trim();
const RB_PASS2 = String(process.env.ROBOKASSA_PASS2 || '').trim();
const RB_ON = !!(RB_LOGIN && RB_PASS1 && RB_PASS2);
const md5hex = (s) => crypto.createHash('md5').update(String(s)).digest('hex');

/* ЮKassa (срез 31, шаг 4). Владелец - самозанятая (НПД), поэтому выбран провайдер, который
   подключает НПД штатно: без ИП, без кассы, чеки - через «Мой налог». Пока переменные пусты -
   работает тестовый режим. Когда владелец впишет данные в /opt/ii-master/pay.env и перезапустит
   службу - включится боевой приём платежей (ссылка на оплату + зачисление по вебхуку).
   Ключи живут только в pay.env: в коде и логах их нет. */
const YK_SHOP_ID = String(process.env.YOOKASSA_SHOP_ID || '').trim();
const YK_SECRET = String(process.env.YOOKASSA_SECRET_KEY || '').trim();
const YK_API = String(process.env.YOOKASSA_API || 'https://api.yookassa.ru').replace(/\/+$/, '');
const YK_RETURN_URL = String(process.env.YOOKASSA_RETURN_URL || 'https://app.ii-master.ru/').trim();

/* ===== Вход через Яндекс/Google (срез 38) =====
   Секреты берём ТОЛЬКО из окружения - файл /opt/ii-master/oauth.env (в репозиторий не попадают).
   Адрес возврата строится из OAUTH_BASE (по умолчанию живой домен приложения). */
const OAUTH_BASE = String(process.env.OAUTH_BASE || 'https://app.ii-master.ru').replace(/\/+$/, '');
const YA_ID = String(process.env.YANDEX_CLIENT_ID || '').trim();
const YA_SECRET = String(process.env.YANDEX_CLIENT_SECRET || '').trim();
const GO_ID = String(process.env.GOOGLE_CLIENT_ID || '').trim();
const GO_SECRET = String(process.env.GOOGLE_CLIENT_SECRET || '').trim();
/* VK ID (id.vk.com): вход, который есть у всех - и он же нужен для RuStore.
   Протокол 2.1 требует PKCE, поэтому рядом со state храним code_verifier. */
const VK_ID = String(process.env.VK_CLIENT_ID || '').trim();
const VK_SECRET = String(process.env.VK_CLIENT_SECRET || '').trim();
const vkVerifiers = new Map();     /* state -> { v: code_verifier, t: время } */
const oauthStates = new Map();     /* state -> время создания (защита от подмены, живёт 10 минут) */
const YK_ON = !!(YK_SHOP_ID && YK_SECRET);

/* Один запрос к API ЮKassa. Авторизация - Basic (shopId:секретный ключ).
   Возвращаем { ok, status, data }, где ok = успешный HTTP-ответ (2xx). */
async function ykRequest(method, pathname, body, idempotenceKey) {
  const auth = 'Basic ' + Buffer.from(YK_SHOP_ID + ':' + YK_SECRET).toString('base64');
  const headers = { authorization: auth, 'content-type': 'application/json' };
  if (idempotenceKey) headers['idempotence-key'] = idempotenceKey;
  const res = await fetch(YK_API + pathname, {
    method: method,
    headers: headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data = null;
  try { data = await res.json(); } catch (e) { data = null; }
  return { ok: res.ok, status: res.status, data: data };
}

const db = new DatabaseSync(path.join(DATA_DIR, 'cloud.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');
db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  pass_salt TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  last_seen TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS state (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, key)
)`);
/* Учёт расходов: одна строка на каждую трату человека. Нужен, чтобы лимит считался на сервере,
   а не «на глазок» в браузере (срез 29). */
db.exec(`CREATE TABLE IF NOT EXISTS spend (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  at TEXT NOT NULL,
  baks INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT ''
)`);
/* Платежи (срез 31): пополнение Баксов. Тестовый режим зачисляет сразу; боевой (ЮKassa) будет
   ждать подтверждения от провайдера. Таблица отдельная - для истории покупок. */
db.exec(`CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  pack TEXT NOT NULL DEFAULT '',
  price_rub INTEGER NOT NULL,
  baks INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'created',
  provider TEXT NOT NULL DEFAULT 'test'
)`);

/* Реферальная программа: код у каждого пользователя, учёт переходов и заработка.
   users.ref_code - личный код; users.ref_by - кто пригласил (id пригласившего). */
try { db.exec('ALTER TABLE users ADD COLUMN ref_code TEXT'); } catch (e) { /* уже есть */ }
try { db.exec('ALTER TABLE users ADD COLUMN ref_by INTEGER'); } catch (e) { /* уже есть */ }
db.exec(`CREATE TABLE IF NOT EXISTS ref_clicks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL,
  at TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS ref_earn (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  at TEXT NOT NULL
)`);
/* Учёт номеров телефонов - защита приветственного бонуса от накрутки.
   Номер хранится ТОЛЬКО хешем (sha256), персональные данные не держим. */
db.exec(`CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT
)`);
/* Уведомления всем пользователям (срез 94). Пишет только владелец из «Сейфа»,
   читают все - панель уведомлений в приложении и колокольчик. */
db.exec(`CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  text TEXT NOT NULL,
  kind TEXT DEFAULT 'notice',
  at TEXT,
  active INTEGER DEFAULT 1
)`);
/* Пароль «Сейфа» владельца (меняется переменной окружения CLOUD_ADMIN_PASS).
   Грабля 12.10.2026: панель открывалась по ЛЮБОМУ паролю - проверка была только на сервере,
   а приложение пускало в панель сразу. Теперь приложение сначала спрашивает сервер (см. adminOpen). */
const ADMIN_PASS = String(process.env.CLOUD_ADMIN_PASS || 'Miratorg19@7777777fff55555').trim();
/* Учёт номеров: защита приветственного бонуса от накрутки.
   Номер храним ТОЛЬКО хешем (sha256), персональные данные не держим. */
db.exec(`CREATE TABLE IF NOT EXISTS phone_uses (
  phone_hash TEXT PRIMARY KEY,
  n INTEGER NOT NULL DEFAULT 0,
  last_at TEXT
)`);

/* Начисление Баксов человеку: прибавляем к его состоянию 'app'. Одна точка на все способы
   оплаты (тестовый режим, Робокасса, ЮKassa) - чтобы зачисление нигде не расходилось. */
function creditBaks(userId, baks, at) {
  const row = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(userId, 'app');
  let st = {};
  if (row) { try { st = JSON.parse(row.value) || {}; } catch (e) { st = {}; } }
  /* Баланс НИКОГДА не уходит в минус (просьба владельца 18.10.2026): даже если списание пришло
     с опозданием, ниже нуля не опускаемся. */
  st.baks = Math.max(0, Math.floor(Number(st.baks || 0)) + Math.floor(Number(baks || 0)));
  db.prepare(`INSERT INTO state (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
    ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
    .run(userId, 'app', JSON.stringify(st), at || new Date().toISOString());
  return st.baks;
}
/* Текущий баланс человека (Баксы) - читаем из состояния 'app' */
function baksOf(userId) {
  const row = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(userId, 'app');
  if (!row) return 0;
  try { const st = JSON.parse(row.value) || {}; return Math.max(0, Math.floor(Number(st.baks || 0))); }
  catch (e) { return 0; }
}

/* Озвучка через наш ключ Yandex SpeechKit (19.10.2026) */
const YA_TTS_KEY = String(process.env.CLOUD_YANDEX_TTS_KEY || process.env.YANDEX_TTS_KEY || '').trim();
const YA_FOLDER = String(process.env.CLOUD_YANDEX_FOLDER || process.env.YANDEX_FOLDER_ID || '').trim();
const TTS_RUB_PER_1K = Math.max(0, Number(process.env.CLOUD_TTS_RUB_PER_1K || 0.4));
const TTS_BASE = String(process.env.CLOUD_TTS_BASE || 'https://tts.api.cloud.yandex.net').replace(/\/+$/, '');
function ttsReady() { return !!YA_TTS_KEY; }
/* ===== КАРТИНКИ, ВИДЕО, МУЗЫКА И УМНЫЙ РЕЖИМ ЧЕРЕЗ НАШ КЛЮЧ (19.10.2026) =====
   Пользователю ключ не нужен: приложение зовёт наш сервер, сервер обращается к GPTunnel
   НАШИМ ключом (CLOUD_GPT_KEY), а Баксы списываем по цене модели с наценкой из «Сейфа». */
const GPT_KEY = String(process.env.CLOUD_GPT_KEY || '').trim();
const GPT_BASE = String(process.env.CLOUD_GPT_BASE || 'https://gptunnel.ru').replace(/\/+$/, '');   /* адрес можно переопределить (тесты) */
const SMART_RUB = Math.max(0, Number(process.env.CLOUD_SMART_RUB || 3));   /* себестоимость «умного» ответа */
function gptReady() { return !!GPT_KEY; }
/* Наценки из «Сейфа» (те же, что видит владелец) */
function pricingMargins() {
  let m = { default: 1.5, image: 1.5, video: 1.4, music: 1.5, text: 1.5, asr: 2, tts: 2 };
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('pricing');
  if (row) {
    try {
      const v = JSON.parse(row.value) || {};
      if (v.margins && typeof v.margins === 'object') m = Object.assign(m, v.margins);
      else if (Number(v.margin) > 0) m.default = Number(v.margin);
    } catch (e) { /* дефолт */ }
  }
  return m;
}
function marginFor(kind) {
  const m = pricingMargins();
  const v = Number(m[kind] || m.default || 1.5);
  return (isFinite(v) && v >= 1 && v <= 5) ? v : 1.5;
}
/* Список моделей GPTunnel (кэш 10 минут) - нужен и клиенту, и для расчёта цены */
let gptModelsCache = { at: 0, list: null };
async function gptModelsAll() {
  if (!gptReady()) return null;
  if (gptModelsCache.list && Date.now() - gptModelsCache.at < 10 * 60 * 1000) return gptModelsCache.list;
  try {
    const r = await fetch(GPT_BASE + '/api/v2/media/models', { headers: { Authorization: GPT_KEY } });
    const j = await r.json().catch(() => null);
    const list = (j && Array.isArray(j.models)) ? j.models : [];
    if (list.length) { gptModelsCache = { at: Date.now(), list: list }; return list; }
  } catch (e) { /* нет связи - вернём что есть */ }
  return gptModelsCache.list;
}
async function gptPriceOf(modelId) {
  const list = await gptModelsAll();
  if (!list) return 0;
  const m = list.filter((x) => String(x.id) === String(modelId))[0];
  const p = m ? Number(m.price) : 0;
  return isFinite(p) && p > 0 ? p : 0;
}
function chargeBaks(userId, baks, kind) {
  if (!(baks > 0)) return baksOf(userId);
  db.prepare('INSERT INTO spend (user_id, day, at, baks, kind) VALUES (?, ?, ?, ?, ?)')
    .run(userId, todayKey(), new Date().toISOString(), baks, String(kind || 'media').slice(0, 40));
  return creditBaks(userId, -baks, new Date().toISOString());
}
/* Поток для «умного режима» через наш ключ GPTunnel */
async function smartChat(req, res) {
  const me = userOf(req);
  if (!me) return json(res, 401, { error: 'Нужно войти в аккаунт' });
  if (!gptReady()) return json(res, 503, { error: 'Умный режим не настроен' });
  let body;
  try { body = await readBody(req, 2 * 1024 * 1024); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
  const messages = (Array.isArray(body.messages) ? body.messages : []).slice(-20)
    .map((m) => ({ role: (m && m.role) || 'user', content: String((m && m.content) || '').slice(0, 12000) }))
    .filter((m) => m.content);
  if (!messages.length) return json(res, 400, { error: 'Пустой запрос' });
  const руб = SMART_RUB;
  const бакс = Math.round(руб * BAKS_PER_RUB);
  if (бакс > 0 && baksOf(me.id) < бакс) return json(res, 402, { error: 'Не хватает Баксов на ответ', baks: baksOf(me.id), need: бакс });
  let up;
  try {
    up = await fetch(GPT_BASE + '/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: GPT_KEY },
      body: JSON.stringify({ model: String(body.model || '').trim() || undefined, messages: messages, stream: true, temperature: 0.7 }),
    });
  } catch (e) { return json(res, 502, { error: 'Модель не ответила: ' + String((e && e.message) || e) }); }
  if (!up.ok) {
    const raw = await up.text().catch(() => '');
    return json(res, 502, { error: 'Модель не ответила (код ' + up.status + ')' + (raw ? ': ' + raw.slice(0, 120) : '') });
  }
  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  let text = '';
  try {
    const reader = up.body.getReader(); const dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      const chunk = dec.decode(value, { stream: true });
      try { res.write(chunk); } catch (e) { break; }
      buf += chunk;
      const lines = buf.split('\n'); buf = lines.pop();
      for (const line of lines) {
        const s = line.trim(); if (!s.startsWith('data:')) continue;
        const p = s.slice(5).trim(); if (!p || p === '[DONE]') continue;
        try {
          const j = JSON.parse(p); const c = j.choices && j.choices[0];
          const t = (c && c.delta && c.delta.content) || (c && c.message && c.message.content);
          if (t) text += t;
        } catch (e) { /* служебные куски */ }
      }
    }
  } catch (e) { /* обрыв */ }
  let left = baksOf(me.id);
  let charged = 0;
  if (text.trim() && бакс > 0) { left = chargeBaks(me.id, бакс, 'smart'); charged = бакс; }
  try { res.write('data: ' + JSON.stringify({ __ii: 'done', baks: left, charged: charged }) + '\n\n'); res.end(); }
  catch (e) { try { res.end(); } catch (e2) {} }
}

/* ---------- реферальная программа ---------- */
const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   /* без похожих 0/O и 1/I */
function genRefCode() {
  let s = '';
  for (let i = 0; i < 10; i++) s += REF_ALPHABET[crypto.randomInt(REF_ALPHABET.length)];
  return s;
}
/* Личный код пользователя (создаём при первом обращении, если его ещё нет) */
function ensureRefCode(userId) {
  const row = db.prepare('SELECT ref_code FROM users WHERE id = ?').get(userId);
  if (!row) return '';
  if (row.ref_code) return row.ref_code;
  for (let i = 0; i < 20; i++) {
    const code = genRefCode();
    if (!db.prepare('SELECT id FROM users WHERE ref_code = ?').get(code)) {
      db.prepare('UPDATE users SET ref_code = ? WHERE id = ?').run(code, userId);
      return code;
    }
  }
  return '';
}
/* Покупка Баксов: начисляем покупателю и, если его кто-то пригласил, 10% - пригласившему. */
function grantPurchase(userId, baks, at) {
  const now = at || new Date().toISOString();
  const total = creditBaks(userId, baks, now);
  try {
    const u = db.prepare('SELECT ref_by FROM users WHERE id = ?').get(userId);
    if (u && u.ref_by && u.ref_by !== userId) {
      const bonus = Math.floor(Number(baks) * 0.10);
      if (bonus > 0) {
        creditBaks(u.ref_by, bonus, now);
        db.prepare('INSERT INTO ref_earn (referrer_id, amount, at) VALUES (?, ?, ?)').run(u.ref_by, bonus, now);
      }
    }
  } catch (e) { /* реферальный бонус не должен ломать зачисление */ }
  return total;
}
function refStats(userId) {
  const code = ensureRefCode(userId);
  const clicks = db.prepare('SELECT COUNT(*) AS n FROM ref_clicks WHERE code = ?').get(code).n;
  const regs = db.prepare('SELECT COUNT(*) AS n FROM users WHERE ref_by = ?').get(userId).n;
  const earned = db.prepare('SELECT COALESCE(SUM(amount), 0) AS s FROM ref_earn WHERE referrer_id = ?').get(userId).s;
  return { code, clicks, regs, earned };
}
function linkForCode(code) { return (OAUTH_BASE + '/?ref=' + encodeURIComponent(code)); }

/* ===== Бесплатный поиск в интернете (DuckDuckGo) - в облаке тоже =====
   Тот же приём, что в локальном сервере, но через fetch: сервер идёт в lite.duckduckgo.com
   и разбирает результаты. Ключей и оплаты нет; работает для облачной и мобильной версии. */
const UA_BROWSER = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/126 Safari/537.36';
function stripTags(s) {
  return String(s == null ? '' : s).replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&#0?39;|&apos;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCharCode(+n))
    .replace(/\s+/g, ' ').trim();
}
function ddgRealUrl(href) {
  let h = String(href || '');
  const m = h.match(/[?&]uddg=([^&]+)/);
  if (m) { try { h = decodeURIComponent(m[1]); } catch (e) {} }
  if (h.startsWith('//')) h = 'https:' + h;
  return h;
}
function parseDdg(html) {
  const snippets = [];
  const sn = /class=['"]result-snippet['"][^>]*>([\s\S]*?)<\/td>/gi;
  let ms;
  while ((ms = sn.exec(html))) snippets.push(stripTags(ms[1]));
  const out = [];
  const re = /<a\b[^>]*class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>/gi;
  let m, i = 0;
  while ((m = re.exec(html))) {
    const href = (m[0].match(/href=["']([^"']+)["']/i) || [])[1] || '';
    const url = ddgRealUrl(href);
    const title = stripTags(m[1]);
    if (!/^https?:\/\//i.test(url) || !title) continue;
    let host = '';
    try { host = new URL(url).hostname.replace(/^www\./, ''); } catch (e) {}
    out.push({ title, url, snippet: snippets[i] || '', host });
    i += 1;
  }
  return out.slice(0, 8);
}
/* ---- Цены Wildberries: открытый каталог (без ключей). Поиск даёт товары без цен,
   цену берём из карточки. Если сервис не отдал - честно сообщаем, ничего не выдумываем. ---- */
const WB_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36';
function wbPriceRub(pr) {
  const cands = [pr.salePriceU, pr.priceU, pr.salePrice, pr.price];
  for (const c of cands) { const n = Number(c); if (isFinite(n) && n > 0) return Math.round(n / 100); }
  const sz = Array.isArray(pr.sizes) && pr.sizes[0];
  const p = sz && (sz.price || (sz.sizes && sz.sizes[0]));
  const total = p && (p.total || p.product);
  const n2 = Number(total);
  return isFinite(n2) && n2 > 0 ? Math.round(n2 / 100) : null;
}
async function wbFetchJson(url) {
  try {
    const r = await fetch(url, { headers: { 'User-Agent': WB_UA, 'Accept': 'application/json',
      'Referer': 'https://www.wildberries.ru/', 'Origin': 'https://www.wildberries.ru' } });
    if (!r.ok) return { ok: false, status: r.status };
    return { ok: true, j: await r.json() };
  } catch (e) { return { ok: false, status: 0 }; }
}
/* Поиск по каталогу WB: версия API меняется без предупреждения, поэтому пробуем несколько.
   С 15.10.2026 WB отвечает 403/498 на любые серверные запросы (антибот) - тогда честно сообщаем,
   а приложение само уходит в поиск по интернету и не показывает пустую таблицу. */
async function wbSearch(q) {
  const vers = ['v13', 'v9', 'v5', 'v4'];
  let last = 0;
  for (const v of vers) {
    const s = await wbFetchJson('https://search.wb.ru/exactmatch/ru/common/' + v + '/search'
      + '?ab_testing=false&appType=1&curr=rub&dest=-1257786&query=' + encodeURIComponent(q)
      + '&resultset=catalog&sort=popular&spp=30&suppressSpellcheck=false');
    if (s.ok) return { ok: true, j: s.j, версия: v };
    last = s.status || 0;
  }
  const антибот = (last === 403 || last === 498 || last === 429);
  return { ok: false, error: антибот
    ? 'Wildberries закрыл серверный доступ к ценам (антибот, код ' + last + '). Точную цену не подтверждаю.'
    : 'Wildberries не ответил (код ' + (last || 'сеть') + ')' };
}
async function wbPrices(q, limit) {
  const s = await wbSearch(q);
  if (!s.ok) return { ok: false, error: s.error };
  const list = ((s.j && s.j.data && s.j.data.products) || []).slice(0, limit);
  if (!list.length) return { ok: false, error: 'Wildberries ничего не нашёл по запросу «' + q + '»' };
  const items = [];
  for (const p of list) {
    let price = wbPriceRub(p);
    if (price === null && p.id) {
      const c = await wbFetchJson('https://card.wb.ru/cards/v2/detail?appType=1&curr=rub&dest=-1257786&nm=' + p.id);
      const cp = c.ok && c.j && c.j.data && c.j.data.products && c.j.data.products[0];
      if (cp) price = wbPriceRub(cp);
    }
    items.push({ name: String(p.name || '').trim(), brand: String(p.brand || '').trim(),
      price: price, rating: Number(p.rating) || 0, feedbacks: Number(p.feedbacks) || 0,
      url: p.id ? ('https://www.wildberries.ru/catalog/' + p.id + '/detail.aspx') : '' });
  }
  const withPrice = items.filter((i) => i.price);
  withPrice.sort((a, b) => a.price - b.price);
  return { ok: true, source: 'wildberries', items: withPrice.length ? withPrice : items,
    note: withPrice.length ? '' : 'цены не отдались', date: new Date().toISOString().slice(0, 10) };
}

async function searchWeb(payload, res) {  const q = String((payload && payload.q) || '').trim();
  if (!q) return json(res, 400, { error: 'Пустой запрос' });
  try {
    const r = await fetch('https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(q), {
      headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,application/xhtml+xml', 'Accept-Language': 'ru,en;q=0.8' },
    });
    const results = parseDdg(await r.text());
    if (!results.length) {
      return json(res, 200, { ok: false, error: 'Поиск не дал результатов (сервис мог ограничить частые запросы). Повторите позже.' });
    }
    console.log('[поиск] облако: ' + results.length + ' результатов (DuckDuckGo)');
    return json(res, 200, { ok: true, results });
  } catch (e) {
    return json(res, 502, { error: 'Не удалось выполнить поиск: ' + (e && e.message ? e.message : e) });
  }
}

/* ---------- пароли и токены ---------- */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function checkPassword(password, salt, hash) {
  const calc = crypto.scryptSync(String(password), String(salt), 64);
  const saved = Buffer.from(String(hash), 'hex');
  return calc.length === saved.length && crypto.timingSafeEqual(calc, saved);
}
function tokenOf() { return crypto.randomBytes(32).toString('hex'); }
function tokenKey(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[a-zа-яё]{2,}$/i;
/* Телефон для защиты бонуса: российский номер в виде +7XXXXXXXXXX (принимаем и 8..., и 7...). */
const PHONE_RE = /^\+7\d{10}$/;
const PHONE_MAX_ACCOUNTS = Math.max(1, Math.floor(Number(process.env.CLOUD_PHONE_MAX || 3)));   /* просьба владельца: 3 аккаунта на телефон */
function normPhone(v) {
  let d = String(v || '').replace(/[^\d]/g, '');
  if (d.length === 11 && (d[0] === '8' || d[0] === '7')) d = '+7' + d.slice(1);
  else if (d.length === 10) d = '+7' + d;
  else d = '+' + d;
  return PHONE_RE.test(d) ? d : '';
}
function phoneKey(phone) { return crypto.createHash('sha256').update('iimaster-phone:' + phone).digest('hex'); }
/* Сколько аккаунтов уже заведено на этот номер */
function phoneUsed(phone) {
  const row = db.prepare('SELECT n FROM phone_uses WHERE phone_hash = ?').get(phoneKey(phone));
  return row ? Number(row.n) || 0 : 0;
}
function phoneNote(phone, at) {
  const key = phoneKey(phone);
  const row = db.prepare('SELECT n FROM phone_uses WHERE phone_hash = ?').get(key);
  if (row) db.prepare('UPDATE phone_uses SET n = n + 1, last_at = ? WHERE phone_hash = ?').run(at, key);
  else db.prepare('INSERT INTO phone_uses (phone_hash, n, last_at) VALUES (?, 1, ?)').run(key, at);
}

/* ---------- вход через Яндекс/Google ---------- */
/* Выдаём сессию (токен) пользователю - тот же механизм, что при обычном входе */
function newSession(userId) {
  const token = tokenOf();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
    .run(tokenKey(token), userId, now, now);
  return token;
}
/* Почта из соцпрофиля: есть такой аккаунт - входим в него (привязка по почте), нет - создаём.
   Пароль у соц-аккаунта случайный: вход по паролю для него не предусмотрен (только через соцсеть). */
function findOrCreateByEmail(email) {
  const mail = String(email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(mail)) return null;
  let row = db.prepare('SELECT id, email FROM users WHERE email = ?').get(mail);
  if (row) { ensureRefCode(row.id); return { user: row, isNew: false }; }
  const { salt, hash } = hashPassword(crypto.randomBytes(24).toString('hex'));
  const now = new Date().toISOString();
  db.prepare('INSERT INTO users (email, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?)')
    .run(mail, salt, hash, now);
  row = db.prepare('SELECT id, email FROM users WHERE email = ?').get(mail);
  ensureRefCode(row.id);
  return { user: row, isNew: true };
}
function redirect(res, to) {
  res.writeHead(302, { location: to, 'cache-control': 'no-store' });
  res.end();
}
function newOauthState() {
  const s = crypto.randomBytes(16).toString('hex');
  const limit = Date.now() - 10 * 60 * 1000;
  for (const [k, t] of oauthStates) if (t < limit) oauthStates.delete(k);
  oauthStates.set(s, Date.now());
  return s;
}
function checkOauthState(s) {
  const key = String(s || '');
  const t = oauthStates.get(key);
  if (!t) return false;
  oauthStates.delete(key);
  return Date.now() - t < 10 * 60 * 1000;
}

/* ---------- простые помощники ---------- */
function json(res, code, obj) {
  const body = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'Content-Type, Authorization, X-Api-Base',
    'access-control-allow-methods': 'GET, POST, PUT, OPTIONS',
  });
  res.end(body);
}
function readBody(req, maxBytes) {
  const limit = Number(maxBytes) > 0 ? Number(maxBytes) : MAX_BODY;
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('too_large')); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => {
      try { resolve(parts.length ? JSON.parse(Buffer.concat(parts).toString('utf8')) : {}); }
      catch (e) { reject(new Error('bad_json')); }
    });
    req.on('error', reject);
  });
}
/* Кто это. Токен приходит в заголовке Authorization: Bearer <токен> */
function userOf(req) {
  const raw = String(req.headers.authorization || '');
  const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(raw);
  if (!m) return null;
  const row = db.prepare(
    'SELECT s.user_id AS id, u.email AS email, s.token_hash AS th FROM sessions s'
    + ' JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?'
  ).get(tokenKey(m[1]));
  if (!row) return null;
  db.prepare('UPDATE sessions SET last_seen = ? WHERE token_hash = ?')
    .run(new Date().toISOString(), row.th);
  return { id: row.id, email: row.email };
}

/* Ограничение попыток входа: не больше 20 неудач с одного адреса за 10 минут */
const tries = new Map();
function tooManyTries(ip) {
  const now = Date.now();
  const rec = tries.get(ip);
  if (!rec || now > rec.until) { tries.set(ip, { n: 0, until: now + 600000 }); return false; }
  return rec.n >= 20;
}
function noteTry(ip) {
  const rec = tries.get(ip) || { n: 0, until: Date.now() + 600000 };
  rec.n += 1;
  tries.set(ip, rec);
}

/* ---------- отдача приложения и прокси к моделям ----------
   Точно так же, как локальный tools/serve.js: браузер не может звать z.ai напрямую (CORS),
   поэтому приложение просит /proxy/<путь>, а сервер пересылает запрос выбранному сервису.
   Ключ сервиса остаётся у пользователя в настройках и уходит только выбранному сервису. */
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
};
const ALLOW = [
  /^https:\/\/api\.z\.ai\//,
  /^https:\/\/gptunnel\.ru\//,
  /^https:\/\/agenthere\.ru\//,
  /^https:\/\/llm\.api\.cloud\.yandex\.net\//,
  /^https:\/\/tts\.api\.cloud\.yandex\.net\//,
  /^https:\/\/api\.telegram\.org\//,
  /^https:\/\/openrouter\.ai\//,
  /^https:\/\/www\.cbr\.ru\//,
];
/* Признак для приложения: страницу отдал облачный сервер. Приложение по нему понимает, что
   нужно просить вход и хранить данные на сервере (см. блок «Облачный режим» в src/index.html). */
const CLOUD_FLAG = '<script>window.__cloudServer=true;</script>';
const IDLE_MS = 90000;
const MAX_BODY_UP = 4 * 1024 * 1024;

function upstream(u, req, res, body) {
  const mod = u.protocol === 'https:' ? https : http;
  const headers = Object.assign({}, req.headers);
  delete headers.host;
  delete headers['content-length'];
  delete headers['x-api-base'];
  if (body.length) headers['content-length'] = Buffer.byteLength(body);

  const p = mod.request({
    hostname: u.hostname,
    port: u.port || (u.protocol === 'https:' ? 443 : 80),
    path: u.pathname + u.search,
    method: req.method,
    headers,
  }, (up) => {
    const out = Object.assign({}, up.headers);
    delete out['transfer-encoding'];
    delete out.connection;
    res.writeHead(up.statusCode || 502, out);
    up.pipe(res);
  });
  p.on('socket', (s) => {
    s.setTimeout(IDLE_MS, () => p.destroy(Object.assign(new Error('таймаут связи'), { code: 'TIMEOUT' })));
  });
  p.on('error', (e) => {
    if (res.headersSent) { res.end(); return; }
    const code = (e && e.code) || '';
    console.log('[прокси] ошибка обращения к ' + u.hostname + ': ' + code);
    json(res, 502, {
      error: code === 'ENOTFOUND'
        ? 'Нет связи с сервисом: не удалось определить его адрес. Проверьте интернет на сервере.'
        : 'Не удалось связаться с сервисом: ' + (e && e.message ? e.message : e),
      code: code || 'unknown',
    });
  });
  p.end(body);
}

/* Ключи владельца для серверного режима: пользователь их не видит и не вводит. */
function ownerKeyFor(host) {
  const h = String(host || '').toLowerCase();
  if (h.indexOf('api.z.ai') >= 0) return String(process.env.OWNER_ZAI_KEY || '');
  if (h.indexOf('gptunnel') >= 0) return String(process.env.OWNER_GPTUNNEL_KEY || '');
  if (h.indexOf('openrouter') >= 0) return String(process.env.OWNER_OPENROUTER_KEY || '');
  return '';
}

function proxyRequest(req, res, target) {
let u;
try { u = new URL(target); } catch (e) { json(res, 400, { error: 'Плохой адрес' }); return; }
/* КЛЮЧ ВЛАДЕЛЬЦА (срез 160). Новый пользователь не должен вводить ключ:
   если он не дал своего, берём наш ключ из окружения сервера (OWNER_ZAI_KEY / OWNER_GPTUNNEL_KEY),
   но только при действующей сессии - иначе это открытый прокси для всего интернета. */
const hadKey = String(req.headers.authorization || '').trim().length > 0;
if (!hadKey) {
  /* токен облака приходит отдельным заголовком: Authorization занят ключом сервиса */
  let who = null;
  const cloudTok = String(req.headers['x-cloud-token'] || '').trim();
  if (cloudTok) {
    const keepAuth = req.headers.authorization;
    req.headers.authorization = 'Bearer ' + cloudTok;
    try { who = userOf(req); } catch (e) { who = null; }
    req.headers.authorization = keepAuth;
  }
  if (!who) { json(res, 401, { error: 'Нужен вход в аккаунт: без ключа запросы идут через сервер только для зарегистрированных.' }); return; }
  const ownerKey = ownerKeyFor(u.hostname);
  if (!ownerKey) { json(res, 402, { error: 'Ключ сервиса не настроен на сервере (OWNER_ZAI_KEY).' }); return; }
  req.headers.authorization = 'Bearer ' + ownerKey;
}
  readRawBody(req).then((body) => upstream(u, req, res, body)).catch(() => {
    if (res.headersSent) { res.end(); return; }
    json(res, 413, { error: 'Запрос слишком большой' });
  });
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY_UP) { reject(new Error('too_large')); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}

function serveStatic(res, urlPath, host) {
  /* Загруженные пользователем файлы (для «дорисовки» фото): /u/<имя> - отдаём из папки данных */
  if (urlPath.indexOf('/u/') === 0) {
    const name = path.basename(decodeURIComponent(urlPath.slice(3)));
    const fullU = path.join(DATA_DIR, 'uploads', name);
    if (!name || !fullU.startsWith(path.join(DATA_DIR, 'uploads'))) { res.writeHead(403); res.end('Запрещено'); return; }
    fs.readFile(fullU, (e, d) => {
      if (e) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Не найдено'); return; }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(fullU).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'public, max-age=86400' });
      res.end(d);
    });
    return;
  }
  let file = urlPath;
  const h = String(host || '').toLowerCase();
  /* Один сервер обслуживает и приложение, и лендинг:
     app.ii-master.ru (и любой другой адрес) - приложение,
     ii-master.ru - лендинг. Так у сайта появляется рабочий HTTPS. */
  const isMain = h.indexOf('ii-master.ru') !== -1 && h.indexOf('app.') !== 0;
  if (file === '/' || file === '') file = isMain ? '/site/index.html' : '/src/index.html';
  if (file === '/manifest.webmanifest') file = '/src/manifest.webmanifest';
  if (file === '/sw.js') file = '/src/sw.js';
  if (isMain) {
    if (file.indexOf('/assets/') === 0) file = '/site' + file;
    if (file === '/privacy.html' || file === '/terms.html' || file === '/favicon.ico') file = '/site' + file;
  }
  const full = path.normalize(path.join(ROOT, file));
  if (!full.startsWith(ROOT)) { res.writeHead(403); res.end('Запрещено'); return; }
  fs.readFile(full, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Не найдено: ' + file);
      return;
    }
    const headers = { 'Content-Type': TYPES[path.extname(full).toLowerCase()] || 'application/octet-stream' };
    if (file === '/src/sw.js') headers['Service-Worker-Allowed'] = '/';
    if (/\.(html|webmanifest)$/i.test(file) || file === '/src/sw.js') {
      headers['Cache-Control'] = 'no-store, no-cache, must-revalidate';
    }
    if (file === '/src/index.html') {
      const html = data.toString('utf8').replace('<head>', '<head>' + CLOUD_FLAG);
      res.writeHead(200, headers);
      res.end(html);
      return;
    }
    res.writeHead(200, headers);
    res.end(data);
  });
}

/* ---------- маршруты ---------- */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const route = url.pathname;
  const method = req.method || 'GET';
  const ip = (req.socket && req.socket.remoteAddress) || 'local';

  try {
    /* CORS: чтобы приложение с любого устройства могло войти и синхронизироваться с облаком */
    /* Срез 161: сюда же /proxy - иначе приложение на компьютере не сможет звать модель через сервер
       (браузер сначала делает предварительный OPTIONS-запрос). */
    if ((route.startsWith('/api/') || route.startsWith('/tools/') || route.startsWith('/proxy/')) && method === 'OPTIONS') {
      res.writeHead(204, {
        'access-control-allow-origin': '*',
        'access-control-allow-headers': 'Content-Type, Authorization, X-Api-Base, X-Cloud-Token',
        'access-control-allow-methods': 'GET, POST, PUT, OPTIONS',
        'access-control-max-age': '86400',
      });
      return res.end();
    }
    if (method === 'GET' && route === '/api/health') {
      const users = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
      return json(res, 200, { ok: true, build: 'cloud-v2', users, version: '0.1', data: DATA_DIR });
    }

    /* --- какие соцвходы настроены (для экрана входа) --- */
    if (method === 'GET' && route === '/api/auth/providers') {
      return json(res, 200, { yandex: !!(YA_ID && YA_SECRET), google: !!(GO_ID && GO_SECRET), vk: !!(VK_ID && VK_SECRET) });
    }

    /* --- реферальная программа --- */
    if (method === 'GET' && route === '/api/ref') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const st = refStats(me.id);
      return json(res, 200, { code: st.code, link: linkForCode(st.code), clicks: st.clicks, regs: st.regs, earned: st.earned });
    }
    if (method === 'POST' && route === '/api/ref/click') {
      let body = {};
      try { body = await readBody(req); } catch (e) { body = {}; }
      const code = String(body.code || '').trim().toUpperCase();
      if (!/^[A-Z2-9]{6,12}$/.test(code)) return json(res, 400, { error: 'Плохой код' });
      if (db.prepare('SELECT id FROM users WHERE ref_code = ?').get(code)) {
        db.prepare('INSERT INTO ref_clicks (code, at) VALUES (?, ?)').run(code, new Date().toISOString());
      }
      return json(res, 200, { ok: true });
    }

    /* Бесплатный поиск в интернете (DuckDuckGo) - для облачной и мобильной версии */
    if (method === 'POST' && route === '/tools/search') {
      let body = {};
      try { body = await readBody(req); } catch (e) { body = {}; }
      return searchWeb(body, res);
    }

    /* Загрузка картинки (для «дорисовки» фото): нужен вход. Файл кладём в данные, отдаём публичную ссылку.
       Читаем тело ВРУЧНУЮ и ВСЕГДА отвечаем: при превышении размера сообщаем об этом, а не рвём соединение
       (иначе у клиента «висит» загрузка - жалоба владельца 09.10.2026). */
    if (method === 'POST' && route === '/api/upload') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const raw = await new Promise((resolve) => {
        const parts = []; let size = 0; let done = false;
        const finish = (v) => { if (!done) { done = true; resolve(v); } };
        req.on('data', (c) => {
          size += c.length;
          if (size > 12 * 1024 * 1024) { finish({ tooLarge: true }); return; }
          parts.push(c);
        });
        req.on('end', () => finish({ buf: Buffer.concat(parts) }));
        req.on('error', () => finish({ bad: true }));
      });
      if (raw && raw.tooLarge) {
        json(res, 413, { error: 'Файл больше 12 МБ - уменьшите фото и попробуйте снова' });
        try { req.destroy(); } catch (e) {}
        return;
      }
      if (!raw || !raw.buf) return json(res, 400, { error: 'Не удалось прочитать файл' });
      let body = {};
      try { body = JSON.parse(raw.buf.toString('utf8') || '{}'); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать файл' }); }
      const m = /^data:(image\/(?:png|jpeg|jpg|webp|gif));base64,([A-Za-z0-9+/=\s]+)$/.exec(String(body.dataUrl || ''));
      if (!m) return json(res, 400, { error: 'Поддерживаются картинки PNG, JPEG, WebP или GIF' });
      const buf = Buffer.from(m[2].replace(/\s+/g, ''), 'base64');
      if (!buf.length) return json(res, 400, { error: 'Пустой файл' });
      if (buf.length > 8 * 1024 * 1024) return json(res, 413, { error: 'Файл больше 8 МБ - уменьшите фото' });
      const ext = (m[1] === 'image/png') ? '.png' : (m[1] === 'image/webp') ? '.webp' : (m[1] === 'image/gif') ? '.gif' : '.jpg';
      const dir = path.join(DATA_DIR, 'uploads');
      fs.mkdirSync(dir, { recursive: true });
      const name = crypto.createHash('sha1').update(buf).digest('hex').slice(0, 24) + ext;
      fs.writeFileSync(path.join(dir, name), buf);
      const base = process.env.CLOUD_PUBLIC_URL || ('https://' + String(req.headers.host || 'app.ii-master.ru'));
      return json(res, 200, { ok: true, url: base.replace(/\/+$/, '') + '/u/' + name, size: buf.length });
    }


    /* Цены из открытого каталога Wildberries - сервер российский, поэтому шансов больше */
    if (method === 'POST' && route === '/tools/prices') {
      let body = {};
      try { body = await readBody(req); } catch (e) { body = {}; }
      const q = String(body.q || '').trim().slice(0, 120);
      if (!q) return json(res, 400, { error: 'Пустой запрос' });
      const limit = Math.min(10, Math.max(3, Number(body.limit) || 6));
      try {
        const out = await wbPrices(q, limit);
        return json(res, 200, out);
      } catch (e) {
        return json(res, 200, { ok: false, error: String((e && e.message) || e) });
      }
    }

    /* --- Яндекс --- */
    if (method === 'GET' && route === '/api/auth/yandex') {
      if (!(YA_ID && YA_SECRET)) return redirect(res, '/?oauth_error=yandex_off');
      const u = 'https://oauth.yandex.ru/authorize?response_type=code'
        + '&client_id=' + encodeURIComponent(YA_ID)
        + '&redirect_uri=' + encodeURIComponent(OAUTH_BASE + '/api/auth/yandex/callback')
        + '&state=' + newOauthState();
      return redirect(res, u);
    }
    if (method === 'GET' && route === '/api/auth/yandex/callback') {
      const q = new URL(req.url, 'http://localhost').searchParams;
      if (!checkOauthState(q.get('state'))) return redirect(res, '/?oauth_error=state');
      const code = q.get('code');
      if (!code) return redirect(res, '/?oauth_error=yandex_code');
      try {
        const form = new URLSearchParams({ grant_type: 'authorization_code', code: code,
          client_id: YA_ID, client_secret: YA_SECRET });
        const tr = await fetch('https://oauth.yandex.ru/token', {
          method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: form.toString(),
        });
        const tj = await tr.json().catch(() => ({}));
        const access = tj.access_token;
        if (!tr.ok || !access) { console.log('[oauth] yandex: не получили токен'); return redirect(res, '/?oauth_error=yandex_token'); }
        const ir = await fetch('https://login.yandex.ru/info?format=json', { headers: { Authorization: 'OAuth ' + access } });
        const ij = await ir.json().catch(() => ({}));
        const email = ij.default_email || (Array.isArray(ij.emails) && ij.emails[0]) || '';
        const r = findOrCreateByEmail(email);
        if (!r) { console.log('[oauth] yandex: почта не пришла'); return redirect(res, '/?oauth_error=yandex_email'); }
        const token = newSession(r.user.id);
        console.log('[oauth] yandex: ' + (r.isNew ? 'новый аккаунт' : 'вход в существующий') + ' (почта не логируется)');
        return redirect(res, '/?auth=' + token);
      } catch (e) {
        console.log('[oauth] yandex: сбой ' + e.message);
        return redirect(res, '/?oauth_error=yandex_fail');
      }
    }

    /* --- Google --- */
    if (method === 'GET' && route === '/api/auth/google') {
      if (!(GO_ID && GO_SECRET)) return redirect(res, '/?oauth_error=google_off');
      const u = 'https://accounts.google.com/o/oauth2/v2/auth?response_type=code'
        + '&client_id=' + encodeURIComponent(GO_ID)
        + '&redirect_uri=' + encodeURIComponent(OAUTH_BASE + '/api/auth/google/callback')
        + '&scope=' + encodeURIComponent('openid email profile')
        + '&access_type=online&prompt=select_account'
        + '&state=' + newOauthState();
      return redirect(res, u);
    }
    if (method === 'GET' && route === '/api/auth/google/callback') {
      const q = new URL(req.url, 'http://localhost').searchParams;
      if (!checkOauthState(q.get('state'))) return redirect(res, '/?oauth_error=state');
      const code = q.get('code');
      if (!code) return redirect(res, '/?oauth_error=google_code');
      try {
        const form = new URLSearchParams({ grant_type: 'authorization_code', code: code,
          client_id: GO_ID, client_secret: GO_SECRET, redirect_uri: OAUTH_BASE + '/api/auth/google/callback' });
        const tr = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: form.toString(),
        });
        const tj = await tr.json().catch(() => ({}));
        const access = tj.access_token;
        if (!tr.ok || !access) { console.log('[oauth] google: не получили токен'); return redirect(res, '/?oauth_error=google_token'); }
        const ir = await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: 'Bearer ' + access } });
        const ij = await ir.json().catch(() => ({}));
        const email = ij.email || '';
        const r = findOrCreateByEmail(email);
        if (!r) { console.log('[oauth] google: почта не пришла'); return redirect(res, '/?oauth_error=google_email'); }
        const token = newSession(r.user.id);
        console.log('[oauth] google: ' + (r.isNew ? 'новый аккаунт' : 'вход в существующий') + ' (почта не логируется)');
        return redirect(res, '/?auth=' + token);
      } catch (e) {
        console.log('[oauth] google: сбой ' + e.message);
        return redirect(res, '/?oauth_error=google_fail');
      }
    }

    /* --- VK ID (id.vk.com), протокол 2.1 с PKCE ---
       Схема: /api/auth/vk -> id.vk.com/authorize -> /api/auth/vk/callback?code&state&device_id
       -> POST id.vk.com/oauth2/auth (обмен кода) -> почта из ответа или oauth2/user_info. */
    if (method === 'GET' && route === '/api/auth/vk') {
      if (!(VK_ID && VK_SECRET)) return redirect(res, '/?oauth_error=vk_off');
      const verifier = crypto.randomBytes(32).toString('base64url');
      const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
      const state = newOauthState();
      for (const [k, o] of vkVerifiers) if (Date.now() - o.t > 10 * 60 * 1000) vkVerifiers.delete(k);
      vkVerifiers.set(state, { v: verifier, t: Date.now() });
      const u = 'https://id.vk.com/authorize?response_type=code'
        + '&client_id=' + encodeURIComponent(VK_ID)
        + '&redirect_uri=' + encodeURIComponent(OAUTH_BASE + '/api/auth/vk/callback')
        + '&state=' + encodeURIComponent(state)
        + '&scope=email'
        + '&code_challenge=' + encodeURIComponent(challenge)
        + '&code_challenge_method=S256';
      return redirect(res, u);
    }
    if (method === 'GET' && route === '/api/auth/vk/callback') {
      const q = new URL(req.url, 'http://localhost').searchParams;
      const state = q.get('state') || '';
      const saved = vkVerifiers.get(state);
      vkVerifiers.delete(state);
      if (!checkOauthState(state) || !saved) return redirect(res, '/?oauth_error=state');
      const code = q.get('code');
      if (!code) return redirect(res, '/?oauth_error=vk_code');
      try {
        const form = new URLSearchParams({
          grant_type: 'authorization_code',
          code: code,
          code_verifier: saved.v,
          client_id: VK_ID,
          redirect_uri: OAUTH_BASE + '/api/auth/vk/callback',
          device_id: String(q.get('device_id') || ''),
        });
        const tr = await fetch('https://id.vk.com/oauth2/auth', {
          method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: form.toString(),
        });
        const tj = await tr.json().catch(() => ({}));
        const access = tj.access_token;
        let email = tj.email || '';
        if (!tr.ok || !access) { console.log('[oauth] vk: не получили токен'); return redirect(res, '/?oauth_error=vk_token'); }
        if (!email) {
          const ir = await fetch('https://id.vk.com/oauth2/user_info', {
            method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ access_token: access, client_id: VK_ID }).toString(),
          });
          const ij = await ir.json().catch(() => ({}));
          email = (ij.user && ij.user.email) || ij.email || '';
        }
        const r = findOrCreateByEmail(email);
        if (!r) { console.log('[oauth] vk: почта не пришла'); return redirect(res, '/?oauth_error=vk_email'); }
        const token = newSession(r.user.id);
        console.log('[oauth] vk: ' + (r.isNew ? 'новый аккаунт' : 'вход в существующий') + ' (почта не логируется)');
        return redirect(res, '/?auth=' + token);
      } catch (e) {
        console.log('[oauth] vk: сбой ' + e.message);
        return redirect(res, '/?oauth_error=vk_fail');
      }
    }

    if (method === 'POST' && (route === '/api/register' || route === '/api/login')) {
      if (tooManyTries(ip)) return json(res, 429, { error: 'Слишком много попыток. Попробуйте позже.' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      if (!EMAIL_RE.test(email)) return json(res, 400, { error: 'Проверьте адрес почты' });
      if (password.length < MIN_PASS) {
        return json(res, 400, { error: 'Пароль должен быть не короче ' + MIN_PASS + ' знаков' });
      }

      if (route === '/api/register') {
        if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
          return json(res, 409, { error: 'Такая почта уже зарегистрирована' });
        }
        /* Защита приветственного бонуса от накрутки: номер обязателен, и на один номер -
           не больше PHONE_MAX_ACCOUNTS аккаунтов (по умолчанию 3). Номер храним хешем. */
        const phone = normPhone(body.phone);
        if (!phone) {
          return json(res, 400, { error: 'Укажите номер телефона в виде +7XXXXXXXXXX - он нужен, '
            + 'чтобы приветственный бонус не накручивали.' });
        }
        const usedBefore = phoneUsed(phone);
        if (usedBefore >= PHONE_MAX_ACCOUNTS) {
          return json(res, 409, { error: 'На этот номер уже зарегистрировано ' + usedBefore + ' аккаунтов - '
            + 'больше нельзя (защита приветственного бонуса). Войдите в существующий аккаунт.' });
        }
        const { salt, hash } = hashPassword(password);
        const now = new Date().toISOString();
        db.prepare('INSERT INTO users (email, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?)')
          .run(email, salt, hash, now);
        const user = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
        ensureRefCode(user.id);
        phoneNote(phone, now);
        /* Приветственный бонус - ОДИН раз на аккаунт (почту): на телефоне, ПК и в облаке баланс общий */
        const baks = creditBaks(user.id, WELCOME_BAKS, now);
        const refCode = String(body.ref || '').trim().toUpperCase();
        if (refCode) {
          const ref = db.prepare('SELECT id FROM users WHERE ref_code = ?').get(refCode);
          if (ref && ref.id !== user.id) db.prepare('UPDATE users SET ref_by = ? WHERE id = ?').run(ref.id, user.id);
        }
        const token = tokenOf();
        db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
          .run(tokenKey(token), user.id, now, now);
        console.log('Зарегистрирован новый пользователь (всего: '
          + db.prepare('SELECT COUNT(*) AS n FROM users').get().n + ')');
        return json(res, 200, { token, user, baks });
      }

      const row = db.prepare('SELECT id, email, pass_salt, pass_hash FROM users WHERE email = ?').get(email);
      if (!row || !checkPassword(password, row.pass_salt, row.pass_hash)) {
        noteTry(ip);
        return json(res, 401, { error: 'Почта или пароль не подошли' });
      }
      const token = tokenOf();
      const now = new Date().toISOString();
      db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
        .run(tokenKey(token), row.id, now, now);
        const stRow = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(row.id, 'app');
        let baksNow = 0;
        if (stRow) { try { baksNow = Math.max(0, Math.floor(Number(JSON.parse(stRow.value).baks || 0))); } catch (e) { baksNow = 0; } }
        return json(res, 200, { token, user: { id: row.id, email: row.email }, baks: baksNow });
    }

    if (route === '/api/me' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const n = db.prepare('SELECT COUNT(*) AS n FROM state WHERE user_id = ?').get(me.id).n;
      const st = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(me.id, 'app');
      let baks = 0;
      if (st) { try { baks = Math.max(0, Math.floor(Number(JSON.parse(st.value).baks || 0))); } catch (e) { baks = 0; } }
      return json(res, 200, { user: me, keys: n, baks: baks });
    }

    /* ===== Синхронизация чатов между телефоном, ПК и облаком (срез 65) ===== */
    if (route === '/api/chats' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const st = db.prepare('SELECT value, updated_at FROM state WHERE user_id = ? AND key = ?').get(me.id, 'chats');
      let chats = [];
      let memory = [];
      let updatedAt = '';
      if (st) {
        try {
          const v = JSON.parse(st.value) || {};
          if (Array.isArray(v.chats)) chats = v.chats;
          if (Array.isArray(v.memory)) memory = v.memory;
          updatedAt = v.updatedAt || st.updated_at || '';
        } catch (e) { chats = []; }
      }
      return json(res, 200, { chats: chats, memory: memory, updatedAt: updatedAt });
    }
    if (route === '/api/chats' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      let cbody;
      try { cbody = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const chats = Array.isArray(cbody.chats) ? cbody.chats.slice(0, 200) : null;
      if (!chats) return json(res, 400, { error: 'Не переданы чаты' });
      /* Вместе с чатами храним память о владельце (факты) - она едет с аккаунтом на все устройства */
      const memory = Array.isArray(cbody.memory) ? cbody.memory.slice(0, 200) : [];
      const updatedAt = String(cbody.updatedAt || new Date().toISOString());
      db.prepare(`INSERT INTO state (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
        .run(me.id, 'chats', JSON.stringify({ chats: chats, memory: memory, updatedAt: updatedAt }), updatedAt);
      return json(res, 200, { ok: true, count: chats.length, memory: memory.length, updatedAt: updatedAt });
    }

    /* ===== «ЯЩИК» владельца (срез 81): коэффициент прибыли и сводка данных =====
       Коэффициент хранится НА СЕРВЕРЕ - значит, изменение сразу действует для всех пользователей
       (приложение забирает его при запуске и раз в 5 минут), обновлять приложение не нужно.
       Пароль задаётся здесь: CLOUD_ADMIN_PASS (по умолчанию - как просил владелец). */
/* ===== Пакеты Баксов (срез 83) =====
   Цены пакетов живут НА СЕРВЕРЕ (таблица settings, ключ 'packs') и правятся в «Сейфе».
   Оплата принимает ТОЛЬКО имя пакета: цену и объём сервер берёт сам (раньше клиент присылал цену,
   и это позволяло запросить много Баксов за 0 ₽ - закрыто). */
const DEFAULT_PACKS = [
  { name: 'Стартовый', price: 300, baks: 2000000, note: 'попробовать' },
  { name: 'Выгодный', price: 600, baks: 4200000, note: 'примерно 70 картинок' },
  { name: 'Популярный', price: 1200, baks: 8800000, note: 'выбор большинства', best: true },
  { name: 'Большой', price: 2500, baks: 18700000, note: 'для больших проектов' },
  { name: 'Мастерский', price: 5000, baks: 38000000, note: '−10 % на операции навсегда' },
];
function packsList() {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('packs');
  if (row) {
    try {
      const v = JSON.parse(row.value);
      if (Array.isArray(v.packs) && v.packs.length) return v.packs;
    } catch (e) { /* дефолт */ }
  }
  return DEFAULT_PACKS;
}
function findPack(name) {
  const n = String(name || '').trim();
  if (!n) return null;
  return packsList().filter((p) => String(p.name) === n)[0] || null;
}
function normPack(p) {
  const name = String((p && p.name) || '').trim().slice(0, 40);
  const price = Math.floor(Number(p && p.price));
  const baks = Math.floor(Number(p && p.baks));
  if (!name || !(price >= 0 && price <= 100000) || !(baks > 0 && baks <= 1000000000)) return null;
  const out = { name: name, price: price, baks: baks };
  if (p && p.note) out.note = String(p.note).slice(0, 60);
  if (p && p.best) out.best = true;
  return out;
}

    if (route === '/api/pricing' && method === 'GET') {      const row = db.prepare('SELECT value, updated_at FROM settings WHERE key = ?').get('pricing');
      let margins = { default: 1.5, image: 1.5, video: 1.4, music: 1.5, text: 1.5, asr: 2, tts: 2 };
      let updatedAt = '';
      if (row) {
        try {
          const v = JSON.parse(row.value) || {};
          if (v.margins && typeof v.margins === 'object') margins = Object.assign(margins, v.margins);
          else if (Number(v.margin) > 0) margins.default = Number(v.margin);   /* старый формат */
          updatedAt = row.updated_at || '';
        } catch (e) { /* дефолт */ }
      }
      return json(res, 200, { margins: margins, margin: margins.default, packs: packsList(), updatedAt: updatedAt });
    }
    if (route === '/api/admin/pricing' && method === 'POST') {
      let ab;
      try { ab = await readBody(req); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      if (String(ab.pass || '') !== ADMIN_PASS) { noteTry(ip); return json(res, 403, { error: 'Неверный пароль сейфа' }); }
      /* Новый формат: margins по каждой позиции (картинки, видео, музыка, текст, расшифровка, озвучка).
         Старый {margin} поддерживаем - он задаёт общий коэффициент. */
      const margins = {};
      /* Коэффициенты проверяем только если их прислали (запрос может быть только про пакеты) */
      const hasMargins = (ab.margins && typeof ab.margins === 'object') || ab.margin !== undefined;
      if (hasMargins) {
        const src = (ab.margins && typeof ab.margins === 'object') ? ab.margins : { default: ab.margin };
        for (const k of Object.keys(src)) {
          const v = Math.round(Number(src[k]) * 100) / 100;
          if (!(v > 0 && v < 100)) return json(res, 400, { error: 'Коэффициент «' + k + '» должен быть от 0 до 100' });
          margins[String(k)] = v;
        }
      }
      if (!Object.keys(margins).length && !Array.isArray(ab.packs)) return json(res, 400, { error: 'Не передано ни одного коэффициента' });
      const now = new Date().toISOString();
      /* Пакеты Баксов: пришли - проверяем каждый и сохраняем отдельным ключом (их и правят в «Сейфе») */
      if (Array.isArray(ab.packs) && ab.packs.length) {
        const list = [];
        for (const raw of ab.packs.slice(0, 30)) {
          const pk = normPack(raw);
          if (!pk) return json(res, 400, { error: 'Некорректный пакет: ' + JSON.stringify(raw).slice(0, 80) });
          list.push(pk);
        }
        db.prepare(`INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
          .run('packs', JSON.stringify({ packs: list }), now);
      }
      db.prepare(`INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
        .run('pricing', JSON.stringify({ margins: margins }), now);
      console.log('Сейф: коэффициенты обновлены - ' + JSON.stringify(margins));
      console.log('Сейф: обновлено - коэффициенты ' + JSON.stringify(margins));
      return json(res, 200, { ok: true, margins: margins, packs: packsList(), updatedAt: now });
    }
    /* ===== Состояние приложения: уведомления всем и режим «Технические работы» (срез 94) =====
       Публичный адрес (без пароля): его спрашивает приложение у всех - и у гостей тоже. */
    if (route === '/api/app-status' && method === 'GET') {
      const url = new URL(req.url, 'http://local');
      const since = Math.max(0, Math.floor(Number(url.searchParams.get('since') || 0) || 0));
      let notices = [];
      try {
        notices = db.prepare('SELECT id, text, kind, at FROM notices WHERE active=1 AND id>? ORDER BY id DESC LIMIT 30').all(since);
      } catch (e) { notices = []; }
      let maintenance = { on: false, text: '' };
      try {
        const row = db.prepare('SELECT value FROM settings WHERE key=?').get('maintenance');
        if (row && row.value) { const j = JSON.parse(row.value); maintenance = { on: !!j.on, text: String(j.text || '') }; }
      } catch (e) { /* нет записи - значит работы не объявлены */ }
      return json(res, 200, { maintenance: maintenance, notices: notices, now: new Date().toISOString() });
    }
    /* Отправить уведомление всем пользователям (только владелец из «Сейфа») */
    if (route === '/api/admin/notify' && method === 'POST') {
      let nb = {};
      try { nb = await readBody(req); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      if (String(nb.pass || '') !== ADMIN_PASS) { noteTry(ip); return json(res, 403, { error: 'Неверный пароль сейфа' }); }
      const text = String(nb.text || '').trim().slice(0, 1000);
      if (!text) return json(res, 400, { error: 'Пустое уведомление' });
      const kind = String(nb.kind || 'notice').slice(0, 20);
      const at = new Date().toISOString();
      const info = db.prepare('INSERT INTO notices (text, kind, at, active) VALUES (?,?,?,1)').run(text, kind, at);
      console.log('Сейф: уведомление всем - ' + text.slice(0, 60));
      return json(res, 200, { ok: true, id: Number(info.lastInsertRowid), at: at });
    }
    /* Объявить или снять «Технические работы» */
    if (route === '/api/admin/maintenance' && method === 'POST') {
      let mb = {};
      try { mb = await readBody(req); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      if (String(mb.pass || '') !== ADMIN_PASS) { noteTry(ip); return json(res, 403, { error: 'Неверный пароль сейфа' }); }
      const on = !!mb.on;
      const text = String(mb.text || '').trim().slice(0, 500);
      const value = JSON.stringify({ on: on, text: text });
      db.prepare('INSERT INTO settings (key, value, updated_at) VALUES (?,?,?) '
        + 'ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at')
        .run('maintenance', value, new Date().toISOString());
      console.log('Сейф: техработы ' + (on ? 'ВКЛ' : 'выкл') + (text ? (' - ' + text.slice(0, 60)) : ''));
      return json(res, 200, { ok: true, maintenance: { on: on, text: text } });
    }
    /* Список отправленных уведомлений (владельцу - видеть историю) */
    if (route === '/api/admin/notices' && method === 'GET') {
      const url = new URL(req.url, 'http://local');
      const pass = String(req.headers['x-admin-pass'] || url.searchParams.get('pass') || '');
      if (pass !== ADMIN_PASS) { noteTry(ip); return json(res, 403, { error: 'Неверный пароль сейфа' }); }
      let list = [];
      try { list = db.prepare('SELECT id, text, kind, at FROM notices ORDER BY id DESC LIMIT 50').all(); } catch (e) { list = []; }
      return json(res, 200, { notices: list });
    }
    if (route === '/api/admin/stats' && method === 'GET') {
      const url = new URL(req.url, 'http://local');
      const pass = String(req.headers['x-admin-pass'] || url.searchParams.get('pass') || '');
      if (pass !== ADMIN_PASS) { noteTry(ip); return json(res, 403, { error: 'Неверный пароль сейфа' }); }
      const all = (sql, ...a) => db.prepare(sql).all(...a);
      const one = (sql, ...a) => db.prepare(sql).get(...a);
      /* Фильтр по датам (срез 84): from/to в формате ГГГГ-ММ-ДД, применяется к расходу и операциям */
      const from = String(url.searchParams.get('from') || '').slice(0, 10);
      const to = String(url.searchParams.get('to') || '').slice(0, 10);
      const dateWhere = (from ? ' AND substr(s.at,1,10) >= ?' : '') + (to ? ' AND substr(s.at,1,10) <= ?' : '');
      const dateArgs = [];
      if (from) dateArgs.push(from);
      if (to) dateArgs.push(to);
      const today = new Date().toISOString().slice(0, 10);
      const users = one('SELECT COUNT(*) AS n FROM users').n;
      const newToday = one('SELECT COUNT(*) AS n FROM users WHERE substr(created_at,1,10) = ?', today).n;
      const activeToday = one('SELECT COUNT(DISTINCT user_id) AS n FROM sessions WHERE substr(last_seen,1,10) = ?', today).n;
      const ops = all('SELECT kind, COUNT(*) AS n, COALESCE(SUM(baks),0) AS baks FROM spend s WHERE 1=1' + dateWhere + ' GROUP BY kind ORDER BY n DESC', ...dateArgs);
      const pay = one("SELECT COUNT(*) AS n, COALESCE(SUM(price_rub),0) AS rub, COALESCE(SUM(baks),0) AS baks FROM payments WHERE status = 'paid'");
      const totalSpent = one('SELECT COALESCE(SUM(baks),0) AS baks FROM spend s WHERE 1=1' + dateWhere, ...dateArgs).baks;
      const top = all('SELECT u.email AS email, COALESCE(SUM(s.baks),0) AS baks, COUNT(s.id) AS ops, MAX(s.at) AS last '
        + 'FROM spend s JOIN users u ON u.id = s.user_id WHERE 1=1' + dateWhere
        + ' GROUP BY s.user_id ORDER BY baks DESC LIMIT 10', ...dateArgs);
      const recent = all('SELECT u.email AS email, s.kind AS kind, s.baks AS baks, s.at AS at '
        + 'FROM spend s JOIN users u ON u.id = s.user_id WHERE 1=1' + dateWhere
        + ' ORDER BY s.id DESC LIMIT 20', ...dateArgs);
      const price = db.prepare('SELECT value FROM settings WHERE key = ?').get('pricing');
      let margin = { default: 1.5, image: 1.5, video: 1.4, music: 1.5, text: 1.5, asr: 2, tts: 2 };
      if (price) {
        try {
          const v = JSON.parse(price.value) || {};
          if (v.margins && typeof v.margins === 'object') margin = Object.assign(margin, v.margins);
          else if (Number(v.margin) > 0) margin.default = Number(v.margin);
        } catch (e) { /* дефолт */ }
      }
      return json(res, 200, {
        сегодня: today, от: from, до: to, пользователей: users, новых_сегодня: newToday, активных_сегодня: activeToday,
        операций_всего: ops.reduce((n, o) => n + Number(o.n || 0), 0),
        операции: ops, платежи: { число: pay.n, рублей: pay.rub, баксов: pay.baks },
        расход_баксов: totalSpent, коэффициент: margin, топ: top, последние: recent,
      });
    }

    if (route === '/api/logout' && method === 'POST') {
      const raw = String(req.headers.authorization || '');
      const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(raw);
      if (m) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenKey(m[1]));
      return json(res, 200, { ok: true });
    }

    if (route === '/api/state') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });

      if (method === 'GET') {
        const rows = db.prepare('SELECT key, value, updated_at FROM state WHERE user_id = ?').all(me.id);
        const out = {};
        for (const r of rows) {
          try { out[r.key] = JSON.parse(r.value); } catch (e) { out[r.key] = null; }
        }
        /* старые копии могли сохранить токен - вырезаем и на чтении */
        if (out.app && typeof out.app === 'object') { delete out.app.cloudToken; delete out.app.cloudEmail; }
        return json(res, 200, { state: out, keys: rows.length });
      }

      if (method === 'PUT' || method === 'POST') {
        let body;
        try { body = await readBody(req); }
        catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
        const key = String(body.key || '').trim();
        if (!key || key.length > 64) return json(res, 400, { error: 'Недопустимое имя ключа' });
        /* Срез 163: баланс Баксов живёт ТОЛЬКО на сервере. Клиент присылает своё состояние,
           но поле baks в нём игнорируем и подставляем серверное - иначе баланс «возвращался». */
        if (key === 'app' && body.value && typeof body.value === 'object') {
          body.value.baks = baksOf(me.id);
          /* Токен входа в копии состояния не храним: иначе после «Выйти» он возвращался
             на устройство вместе со состоянием и сессия «не очищалась» (жалоба 30.10.2026). */
          delete body.value.cloudToken;
          delete body.value.cloudEmail;
        }
        const value = JSON.stringify(body.value === undefined ? null : body.value);
        if (value.length > MAX_VALUE) return json(res, 413, { error: 'Слишком большое значение' });
        db.prepare(`INSERT INTO state (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
          ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
          .run(me.id, key, value, new Date().toISOString());
        return json(res, 200, { ok: true, key });
      }
      return json(res, 405, { error: 'Метод не поддерживается' });
    }

    /* ---------- Оплата (срез 31, тестовый режим) ----------
       Приложение просит «купить пакет». Пока провайдер не подключён, работаем в тестовом режиме:
       платёж сразу считается оплаченным, а Баксы зачисляются в состояние человека.
       Когда владелец подключит ЮKassa: здесь будет возврат ссылки на оплату, а зачисление -
       по вебхуку от провайдера (после подтверждения оплаты). */
    if (route === '/api/pay/create' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      /* Цену и объём берём ТОЛЬКО из списка на сервере (клиент присылает лишь имя пакета). */
      const pack = findPack(body.pack);
      if (!pack) return json(res, 400, { error: 'Недопустимый пакет' });
      const price = Math.floor(Number(pack.price));
      const baks = Math.floor(Number(pack.baks));
      const now = new Date().toISOString();
      const provider = YK_ON ? 'yookassa' : (RB_ON ? 'robokassa' : 'test');
      const info = db.prepare(`INSERT INTO payments (user_id, created_at, pack, price_rub, baks, status, provider)
        VALUES (?, ?, ?, ?, ?, ?, ?)`)
        .run(me.id, now, String(body.pack || '').slice(0, 40), price, baks, (YK_ON || RB_ON) ? 'created' : 'paid', provider);
      const payId = Number(info.lastInsertRowid);
      if (YK_ON) {
        /* боевой режим ЮKassa: создаём платёж и отдаём ссылку на оплату; зачисление - по вебхуку */
        if (price < 1) {
          db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('error', payId);
          return json(res, 400, { error: 'Сумма платежа слишком мала' });
        }
        try {
          const packName = String(body.pack || '');
          const descr = ('Пакет Баксов «' + packName + '»').slice(0, 128);
          const out = await ykRequest('POST', '/v3/payments', {
            amount: { value: price.toFixed(2), currency: 'RUB' },
            capture: true,
            confirmation: { type: 'redirect', return_url: YK_RETURN_URL },
            description: descr,
            /* Чек для 54-ФЗ: самозанятым (НПД) ЮKassa требует чек с почтой покупателя.
               НДС нет (vat_code 1), предмет расчёта - услуга, оплата полная. */
            receipt: {
              customer: { email: me.email },
              items: [{
                description: descr,
                quantity: '1.00',
                amount: { value: price.toFixed(2), currency: 'RUB' },
                vat_code: 1,
                payment_subject: 'service',
                payment_mode: 'full_payment',
              }],
            },
            metadata: { payId: String(payId), userId: String(me.id) },
          }, 'iimaster-' + payId);
          const url = out.data && out.data.confirmation && out.data.confirmation.confirmation_url;
          if (!out.ok || !url) {
            db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('error', payId);
            const why = (out.data && (out.data.description || out.data.code)) || ('http ' + out.status);
            return json(res, 502, { error: 'Не удалось создать платёж: ' + String(why).slice(0, 180) });
          }
          return json(res, 200, { ok: true, paid: false, id: payId, payUrl: url, provider: 'yookassa' });
        } catch (e) {
          db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('error', payId);
          return json(res, 502, { error: 'Не удалось создать платёж: ' + String((e && e.message) || '').slice(0, 160) });
        }
      }
      if (RB_ON) {
        /* боевой режим: отдаём ссылку на оплату Робокассы; зачисление будет по ResultURL */
        const outSum = String(price);
        const sig = md5hex(RB_LOGIN + ':' + outSum + ':' + payId + ':' + RB_PASS1);
        const desc = encodeURIComponent('Пакет Баксов «' + String(body.pack || '') + '»');
        const payUrl = 'https://auth.robokassa.ru/Merchant/Index.aspx'
          + '?MerchantLogin=' + encodeURIComponent(RB_LOGIN)
          + '&OutSum=' + outSum + '&InvId=' + payId + '&Description=' + desc
          + '&SignatureValue=' + sig + '&Culture=ru';
        return json(res, 200, { ok: true, paid: false, id: payId, payUrl: payUrl, provider: 'robokassa' });
      }
      const baksNow = grantPurchase(me.id, baks, now);
      return json(res, 200, { ok: true, paid: true, id: payId,
        credited: baks, baks: baksNow, provider: 'test' });
    }
    /* ResultURL Робокассы: провайдер подтверждает оплату - зачисляем Баксы человеку.
       Подпись проверяется по паролю №2 (md5(OutSum:InvId:Pass2)). Ответ должен быть "OK<InvId>". */
    if (route === '/api/pay/robokassa/result' && method === 'POST') {
      const text = (res) => { res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }); return res.end(text); };
      let body;
      try { body = await readBody(req); } catch (e) { return text('bad'); }
      const q = new URLSearchParams(body.toString('utf8'));
      const outSum = q.get('OutSum') || '', invId = q.get('InvId') || '';
      const sig = String(q.get('SignatureValue') || '').toLowerCase();
      if (!RB_ON || !invId || sig !== md5hex(outSum + ':' + invId + ':' + RB_PASS2)) return text('bad sign');
      const pay = db.prepare('SELECT * FROM payments WHERE id = ?').get(Number(invId));
      if (pay && pay.status !== 'paid') {
        db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('paid', pay.id);
        grantPurchase(pay.user_id, pay.baks, new Date().toISOString());
      }
      return text('OK' + invId);
    }
    /* Вебхук ЮKassa: провайдер сообщает об оплате - зачисляем Баксы человеку.
       ЮKassa не подписывает уведомления, поэтому НЕ доверяем телу на слово: перезапрашиваем
       платёж по его id у API и убеждаемся, что статус "succeeded" и наш payId совпадает. */
    if (route === '/api/pay/yookassa/result' && method === 'POST') {
      if (!YK_ON) return json(res, 403, { error: 'Провайдер не подключён' });
      let body;
      try { body = await readBody(req); } catch (e) { return json(res, 400, { error: 'Плохой запрос' }); }
      const note = (body && typeof body === 'object') ? body : {};
      const obj = (note.object && typeof note.object === 'object') ? note.object : {};
      if (String(note.event || '') !== 'payment.succeeded') return json(res, 200, { ok: true });
      const ykId = String(obj.id || '');
      const payId = Number(obj.metadata && obj.metadata.payId);
      if (!ykId || !Number.isFinite(payId)) return json(res, 400, { error: 'Нет данных платежа' });
      let check = null;
      try { check = await ykRequest('GET', '/v3/payments/' + encodeURIComponent(ykId)); }
      catch (e) { return json(res, 502, { error: 'Проверка недоступна' }); }
      const verified = check.ok && check.data && check.data.status === 'succeeded'
        && Number(check.data.metadata && check.data.metadata.payId) === payId;
      if (!verified) return json(res, 400, { error: 'Проверка не пройдена' });
      const pay = db.prepare('SELECT * FROM payments WHERE id = ?').get(payId);
      if (!pay) return json(res, 400, { error: 'Платёж не найден' });
      if (pay.status !== 'paid') {
        db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('paid', pay.id);
        grantPurchase(pay.user_id, pay.baks, new Date().toISOString());
      }
      return json(res, 200, { ok: true });
    }
    if (route === '/api/pay/list' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const list = db.prepare(`SELECT id, created_at, pack, price_rub, baks, status, provider
        FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 20`).all(me.id);
      return json(res, 200, { payments: list });
    }

    /* Учёт и лимит трат. Приложение сообщает о каждом расходе; сервер считает его за день и
       отказывает, когда лимит исчерпан. Это защита денег владельца: даже если у человека
       «сломается» приложение, сервер не даст сжечь больше положенного. */
    if (route === '/api/spend' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const baks = Math.floor(Number(body.baks || 0));
      if (!Number.isFinite(baks) || baks < 0 || baks > 100000000) {
        return json(res, 400, { error: 'Недопустимая сумма расхода' });
      }
      const spent = spentTodayBaks(me.id);
      if (LIMIT_BAKS > 0 && spent + baks > LIMIT_BAKS) {
        return json(res, 429, {
          error: 'Дневной лимит расходов исчерпан',
          limitRub: LIMIT_RUB,
          spentBaks: spent,
          remainingBaks: Math.max(0, LIMIT_BAKS - spent),
        });
      }
      /* Не хватает Баксов - списание не проводим (баланс не уходит в минус, просьба 18.10.2026) */
      const было = baksOf(me.id);
      if (baks > 0 && было < baks) {
        return json(res, 402, {
          error: 'Не хватает Баксов',
          baks: было,
          need: baks - было,
          limitRub: LIMIT_RUB,
        });
      }
      db.prepare('INSERT INTO spend (user_id, day, at, baks, kind) VALUES (?, ?, ?, ?, ?)')
        .run(me.id, todayKey(), new Date().toISOString(), baks, String(body.kind || '').slice(0, 40));
      /* Общий баланс: списание идёт и по счёту аккаунта (state.app.baks) - один баланс на телефон, ПК и облако */
      const left = creditBaks(me.id, -baks, new Date().toISOString());
      const after = spent + baks;
      return json(res, 200, {
        ok: true,
        baks: left,
        limitRub: LIMIT_RUB,
        spentBaks: after,
        remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - after) : -1,
      });
    }

    /* ===== ОБЩИЙ КЛЮЧ: состояние и ответ модели за счёт владельца (15.10.2026) =====
       GET  /api/assistant      - включён ли общий доступ, какой моделью отвечаем, сколько стоит ответ
       POST /api/assistant/chat - ответ модели нашим ключом + списание Баксов + дневной лимит */
    if (route === '/api/assistant' && method === 'GET') {
      return json(res, 200, {
        ok: true, on: assistantOn(), model: assistantOn() ? MODEL_NAME : '',
        visionModel: assistantOn() ? MODEL_VISION : '', gpt: gptReady(), smartRub: SMART_RUB, tts: ttsReady(),
        priceBaks: ASSIST_BAKS, priceRub: ASSIST_RUB,
        limitRub: LIMIT_RUB,
      });
    }

    if (route === '/api/assistant/chat' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти в аккаунт' });
      if (!assistantOn()) return json(res, 503, { error: 'Общий доступ пока не включён' });
      let body;
      /* Тут могут быть картинки (base64), поэтому лимит выше обычного */
      try { body = await readBody(req, 8 * 1024 * 1024); }
      catch (e) {
        return json(res, e && e.message === 'too_large' ? 413 : 400,
          { error: e && e.message === 'too_large' ? 'Слишком большой запрос - пришлите картинку поменьше' : 'Не удалось прочитать запрос' });
      }
      const сырые = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
      let естьКартинки = false;
      const messages = [];
      for (const m of сырые) {
        if (!m) continue;
        const role = (m.role === 'assistant' || m.role === 'system') ? m.role : 'user';
        if (typeof m.content === 'string') {
          if (!m.content.trim()) continue;
          messages.push({ role, content: m.content.slice(0, 12000) });
          continue;
        }
        if (Array.isArray(m.content)) {
          /* Мульти-часть (текст + картинка) в формате OpenAI - передаём как есть, но чистим размеры */
          const parts = [];
          for (const p of m.content.slice(0, 4)) {
            if (!p) continue;
            if (p.type === 'text' && p.text) parts.push({ type: 'text', text: String(p.text).slice(0, 12000) });
            else if (p.type === 'image_url' && p.image_url && p.image_url.url) {
              const u = String(p.image_url.url);
              if (u.length <= 3 * 1024 * 1024) { parts.push({ type: 'image_url', image_url: { url: u } }); естьКартинки = true; }
            }
          }
          if (parts.length) messages.push({ role, content: parts });
        }
      }
      if (!messages.length) return json(res, 400, { error: 'Пустой запрос' });
      const spent = spentTodayBaks(me.id);
      if (LIMIT_BAKS > 0 && spent + ASSIST_BAKS > LIMIT_BAKS) {
        return json(res, 429, { error: 'Дневной лимит расходов исчерпан', limitRub: LIMIT_RUB,
          spentBaks: spent, remainingBaks: Math.max(0, LIMIT_BAKS - spent) });
      }
      /* Баксов не хватает - ответ не даём (баланс не должен уходить в минус, просьба 18.10.2026) */
      const баксов = baksOf(me.id);
      if (ASSIST_BAKS > 0 && баксов < ASSIST_BAKS) {
        return json(res, 402, { error: 'Не хватает Баксов на ответ', baks: баксов, need: ASSIST_BAKS - баксов });
      }
      const модель = естьКартинки ? MODEL_VISION : MODEL_NAME;
      /* ===== ПОТОК вместо ожидания целиком (просьба владельца 18.10.2026: «улучшить скорость») =====
         Первые слова приходят сразу, ответ «печатается» на глазах. Баксы списываем в конце,
         когда ответ действительно пришёл. Клиент получает тот же формат SSE, что и от модели,
         а последним событием - {__ii:'done', baks, charged}. */
      const хотятПоток = body.stream !== false;
      let up;
      try {
        up = await fetch(MODEL_BASE + '/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + MODEL_KEY, 'Accept-Language': 'ru-RU,ru' },
          body: JSON.stringify({ model: модель, messages, stream: хотятПоток, temperature: 0.7 }),
        });
      } catch (e) {
        return json(res, 502, { error: 'Модель не ответила: ' + String((e && e.message) || e) });
      }
      if (!up.ok) {
        let raw = ''; try { raw = await up.text(); } catch (e) {}
        let j = null; try { j = JSON.parse(raw); } catch (e) {}
        const code = j && ((j.error && j.error.code) || j.code);
        const нетСредств = (String(code) === '1113' || /insufficient balance|no resource package/i.test(raw));
        return json(res, 502, { error: 'Модель не ответила (код ' + up.status + (code ? ' / ' + code : '') + ')'
          + (нетСредств ? ': на нашем счёте сервиса нет средств - скажите владельцу' : '') });
      }
      /* --- не потоком: как раньше, одним JSON --- */
      if (!хотятПоток) {
        let text = '';
        try {
          const j = await up.json();
          const c = j && j.choices && j.choices[0];
          text = String((c && ((c.message && c.message.content) || c.text)) || '').trim();
        } catch (e) { return json(res, 502, { error: 'Модель вернула непонятный ответ' }); }
        if (!text) return json(res, 502, { error: 'Модель вернула пустой ответ' });
        let left = null;
        if (ASSIST_BAKS > 0) {
          db.prepare('INSERT INTO spend (user_id, day, at, baks, kind) VALUES (?, ?, ?, ?, ?)')
            .run(me.id, todayKey(), new Date().toISOString(), ASSIST_BAKS, 'assistant');
          left = creditBaks(me.id, -ASSIST_BAKS, new Date().toISOString());
        }
        return json(res, 200, { ok: true, text, model: модель, baks: left, chargedBaks: ASSIST_BAKS,
          spentBaks: spent + ASSIST_BAKS, remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - spent - ASSIST_BAKS) : -1 });
      }
      /* --- поток: отдаём моделиный SSE как есть и считаем текст для списания --- */
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
      });
      let текст = '';
      try {
        const reader = up.body.getReader();
        const dec = new TextDecoder();
        let buf = '';
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = dec.decode(value, { stream: true });
          try { res.write(chunk); } catch (e) { break; }
          buf += chunk;
          const lines = buf.split('\n'); buf = lines.pop();
          for (const line of lines) {
            const s = line.trim();
            if (!s.startsWith('data:')) continue;
            const payload = s.slice(5).trim();
            if (!payload || payload === '[DONE]') continue;
            try {
              const j = JSON.parse(payload);
              const c = j.choices && j.choices[0];
              const t = (c && c.delta && c.delta.content) || (c && c.message && c.message.content);
              if (t) текст += t;
            } catch (e) { /* служебные куски пропускаем */ }
          }
        }
      } catch (e) { /* обрыв - отдадим то, что успели */ }
      let left = baksOf(me.id);
      const списать = (текст.trim() && ASSIST_BAKS > 0) ? ASSIST_BAKS : 0;
      if (списать) {
        db.prepare('INSERT INTO spend (user_id, day, at, baks, kind) VALUES (?, ?, ?, ?, ?)')
          .run(me.id, todayKey(), new Date().toISOString(), списать, 'assistant');
        left = creditBaks(me.id, -списать, new Date().toISOString());
      }
      try { res.write('data: ' + JSON.stringify({ __ii: 'done', baks: left, charged: списать, model: модель }) + '\n\n'); res.end(); }
      catch (e) { try { res.end(); } catch (e2) {} }
      return;
    }

    /* ===== Маршруты генерации через наш ключ (19.10.2026) ===== */
    if (route === '/api/media/models' && method === 'GET') {
      const list = await gptModelsAll();
      if (!list) return json(res, 503, { error: 'Генерация пока не настроена' });
      return json(res, 200, { ok: true, models: list });
    }
    if (route === '/api/media/tasks' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти в аккаунт' });
      if (!gptReady()) return json(res, 503, { error: 'Генерация пока не настроена' });
      let body;
      try { body = await readBody(req, 1024 * 1024); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const model = String(body.model || '').trim();
      if (!model) return json(res, 400, { error: 'Не выбрана модель' });
      /* цена модели у GPTunnel × наценка из «Сейфа» */
      const цена = await gptPriceOf(model);
      const вид = /video|(^|-)vid|kling|hailuo|seedance|veo|sora/i.test(model) ? 'video' : (/music|suno|grom|mureka/i.test(model) ? 'music' : 'image');
      const руб = Math.max(1, Math.round((цена > 0 ? цена : (вид === 'video' ? 80 : вид === 'music' ? 8 : 20)) * marginFor(вид)));
      const бакс = Math.round(руб * BAKS_PER_RUB);
      const есть = baksOf(me.id);
      if (бакс > 0 && есть < бакс) return json(res, 402, { error: 'Не хватает Баксов', baks: есть, need: бакс });
      if (бакс > 0) chargeBaks(me.id, бакс, 'media:' + вид);
      let r, raw = '', j = null;
      try {
        r = await fetch(GPT_BASE + '/api/v2/media/tasks', {
          method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: GPT_KEY }, body: JSON.stringify(body),
        });
        raw = await r.text();
        try { j = JSON.parse(raw); } catch (e) { j = null; }
      } catch (e) {
        if (бакс > 0) creditBaks(me.id, бакс, new Date().toISOString());   /* вернуть, если не ушло */
        return json(res, 502, { error: 'Сервис генерации не ответил' });
      }
      if (!r.ok) {
        if (бакс > 0) creditBaks(me.id, бакс, new Date().toISOString());   /* возврат при ошибке */
        const msg = (j && (j.message || (j.error && j.error.message))) || ('код ' + r.status);
        return json(res, 502, { error: 'Сервис генерации: ' + String(msg).slice(0, 200) });
      }
      return json(res, 200, Object.assign({ ok: true, priceRub: руб, chargedBaks: бакс, baks: baksOf(me.id) }, j || {}));
    }
    if (method === 'GET' && /^\/api\/media\/tasks\/[^/]+$/.test(route)) {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти в аккаунт' });
      if (!gptReady()) return json(res, 503, { error: 'Генерация пока не настроена' });
      const id = route.split('/').pop();
      try {
        const r = await fetch(GPT_BASE + '/api/v2/media/tasks/' + encodeURIComponent(id), { headers: { Authorization: GPT_KEY } });
        const raw = await r.text();
        let j = null; try { j = JSON.parse(raw); } catch (e) { j = null; }
        return json(res, r.ok ? 200 : r.status, j || { error: 'Пустой ответ сервиса' });
      } catch (e) { return json(res, 502, { error: 'Сервис генерации не ответил' }); }
    }
    if (route === '/api/smart/chat' && method === 'POST') {
      return smartChat(req, res);
    }
    /* Озвучка: наш ключ Yandex SpeechKit, Баксы по длине текста */
    if (route === '/api/tts' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти в аккаунт' });
      if (!ttsReady()) return json(res, 503, { error: 'Озвучка пока не настроена' });
      let body;
      try { body = await readBody(req, 256 * 1024); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const text = String(body.text || '').slice(0, 4000).trim();
      if (!text) return json(res, 400, { error: 'Пустой текст' });
      const руб = Math.max(0.3, (text.length / 1000) * TTS_RUB_PER_1K) * marginFor('tts');
      const бакс = Math.round(руб * BAKS_PER_RUB);
      const есть = baksOf(me.id);
      if (бакс > 0 && есть < бакс) return json(res, 402, { error: 'Не хватает Баксов на озвучку', baks: есть, need: бакс });
      const form = new URLSearchParams({
        text: text, lang: 'ru-RU', voice: String(body.voice || 'alena').slice(0, 20),
        speed: String(body.rate || '1').slice(0, 4), format: 'mp3',
      });
      if (YA_FOLDER) form.set('folderId', YA_FOLDER);
      let r, buf = null;
      try {
        r = await fetch(TTS_BASE + '/speech/v1.0/tts:synthesize', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', Authorization: 'Api-Key ' + YA_TTS_KEY },
          body: form.toString(),
        });
        if (r.ok) buf = Buffer.from(await r.arrayBuffer());
      } catch (e) {
        return json(res, 502, { error: 'Yandex не ответил' });
      }
      if (!r.ok || !buf || !buf.length) {
        let raw = ''; try { raw = await r.text(); } catch (e) {}
        return json(res, 502, { error: 'Yandex не озвучил (код ' + r.status + ')' + (raw ? ': ' + raw.slice(0, 160) : '') });
      }
      if (бакс > 0) chargeBaks(me.id, бакс, 'tts');
      res.writeHead(200, { 'Content-Type': 'audio/mpeg', 'Content-Length': buf.length });
      res.end(buf);
      return;
    }

    if (route === '/api/usage' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const spent = spentTodayBaks(me.id);
      const events = db.prepare('SELECT at, baks, kind FROM spend WHERE user_id = ? ORDER BY id DESC LIMIT 20')
        .all(me.id);
      return json(res, 200, {
        limitRub: LIMIT_RUB,
        spentBaks: spent,
        remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - spent) : -1,
        today: todayKey(),
        events,
      });
    }

    /* Резервные копии: только по ключу. Сам файл копии - это база с аккаунтами, наружу без защиты
       его отдавать нельзя, поэтому без ключа отвечаем «нет». */
    if (route === '/api/backup/now' && method === 'POST') {
      const key = String(req.headers['x-backup-key'] || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const name = makeBackup('по запросу владельца');
      return json(res, name ? 200 : 500, { ok: !!name, file: name });
    }

    if (route === '/api/backup/list' && method === 'GET') {
      const key = String(url.searchParams.get('key') || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      return json(res, 200, { count: files.length, keep: BACKUP_KEEP, files });
    }

    if (route === '/api/backup/latest' && method === 'GET') {
      const key = String(url.searchParams.get('key') || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      if (!files.length) return json(res, 404, { error: 'Копий пока нет' });
      const name = files[files.length - 1];
      const data = fs.readFileSync(path.join(BACKUP_DIR, name));
      res.writeHead(200, {
        'content-type': 'application/octet-stream',
        'content-disposition': 'attachment; filename="' + name + '"',
        'content-length': data.length,
        'cache-control': 'no-store',
      });
      return res.end(data);
    }

    /* Скачать копию, войдя под своим аккаунтом. Нужно для файла-кнопки на компьютере владельца:
       так не требуется ни ключ, ни консоль - только почта и пароль, которые человек и так знает. */
    if (route === '/api/backup/with-account' && method === 'POST') {
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      const row = db.prepare('SELECT id, pass_salt, pass_hash FROM users WHERE email = ?').get(email);
      if (!row || !checkPassword(password, row.pass_salt, row.pass_hash)) {
        noteTry(ip);
        return json(res, 401, { error: 'Почта или пароль не подошли' });
      }
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      if (!files.length) return json(res, 404, { error: 'Копий пока нет' });
      const name = files[files.length - 1];
      const data = fs.readFileSync(path.join(BACKUP_DIR, name));
      res.writeHead(200, {
        'content-type': 'application/octet-stream',
        'content-disposition': 'attachment; filename="' + name + '"',
        'content-length': data.length,
        'cache-control': 'no-store',
      });
      return res.end(data);
    }

    /* /proxy/<путь> → <X-Api-Base>/<путь>, только для разрешённых адресов сервисов */
    if (route.startsWith('/proxy/')) {
      const base = String(req.headers['x-api-base'] || '').replace(/\/+$/, '');
      if (!base || !ALLOW.some((re) => re.test(base + '/'))) {
        return json(res, 403, { error: 'Адрес не разрешён для прокси: ' + base });
      }
      return proxyRequest(req, res, base + route.slice('/proxy'.length));
    }

    /* Сохранение файлов на диск - это возможность настольной версии, в облаке её нет.
       Отвечаем понятным текстом, чтобы приложение показало человеку причину, а не «сломалось». */
    if (route.startsWith('/tools/')) {
      return json(res, 501, {
        error: 'В облачной версии файлы на диск не сохраняются. Скачайте результат из чата '
          + 'или пользуйтесь приложением на компьютере.',
      });
    }

    if (method === 'GET') return serveStatic(res, route, req.headers.host);

    json(res, 404, { error: 'Не найдено' });
  } catch (e) {
    console.log('Ошибка обработки запроса: ' + (e && e.message ? e.message : e));
    if (!res.headersSent) json(res, 500, { error: 'Внутренняя ошибка' });
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log('Облачный сервер «ИИ Мастер»: http://127.0.0.1:' + PORT + '/');
  console.log('Данные: ' + DATA_DIR);
  console.log('Резервные копии: ' + BACKUP_DIR + ' (храним последние ' + BACKUP_KEEP + ')');
  console.log('Ключ для скачивания копий: ' + BACKUP_KEY + '  (и в файле ' + KEY_FILE + ')');
  console.log('Лимит трат: ' + (LIMIT_RUB > 0 ? LIMIT_RUB + ' руб/день на человека' : 'без ограничения')
    + ' (менять: echo 300 > ' + path.join(path.dirname(DATA_DIR), 'limit.txt') + ')');
  setTimeout(backupTick, 5000);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
