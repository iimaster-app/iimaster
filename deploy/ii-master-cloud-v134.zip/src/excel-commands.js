'use strict';

/**
 * Управление Excel из чата (этап 11, 30.10.2026) — разбор команды.
 *
 * Задача шага: превратить обычную фразу («убери дубли», «построй дашборд за год»)
 * в понятное действие над открытой книгой. Никакой имитации: функция только ПОНИМАЕТ текст,
 * выполнение — отдельно, в интерфейсе Excel.
 *
 * Правила разбора:
 *   - ё = е, регистр не важен, лишние пробелы и знаки не мешают;
 *   - отрицания («не убирай», «не надо») блокируют действие — «не» важнее ключевого слова;
 *   - если фраза про Excel, но действие непонятно — action = null и вопрос человеку.
 */
(function (root) {
  const norm = (s) => String(s === undefined || s === null ? '' : s)
    .toLowerCase().replace(/ё/g, 'е').replace(/[«»"'`]/g, '').replace(/\s+/g, ' ').trim();

  /* Порядок важен: более конкретные правила выше. */
  const RULES = [
    { action: 'dashboard', re: /(дашборд|dashboard|панель управлени|kpi|кпи)/ },
    { action: 'chart', re: /(диаграмм|график|chart|нарисуй граф)/ },
    { action: 'analysis', re: /(проанализ|анализ|найди ошибк|найди проблем|что не так|выброс|аномали|дубликат[а-я]* найди)/ },
    { action: 'dedupe', re: /(убери дубл|убери повтор|удали дубл|удали повтор|remove dupl|без дубл)/ },
    { action: 'dropEmpty', re: /(убери пуст|удали пуст|пустые строки)/ },
    { action: 'group', re: /(свод|сгруппир|группир|итог по|просуммир по|сумма по)/ },
    { action: 'union', re: /(объедини|соедини|склей|сведи вмест|merge)/ },
    { action: 'sortDesc', re: /(сортир[а-я]* по убыван|по убыван|сорт.* убыв)/ },
    { action: 'sortAsc', re: /(сортир[а-я]* по возраст|по возраст|сорт.* возр)/ },
    { action: 'macro', re: /(макрос|vba|автоматизируй|повтори эти действ)/ },
    { action: 'open', re: /(открой (файл|таблиц|книг)|загрузи таблиц)/ },
  ];
  const NEG = /(не |нельзя|не надо|не нужно|отмен|стоп|погоди)/;
  const EXCELISH = /(excel|эксел|таблиц|лист|книг|ячейк|строк|столб|диаграмм|график|дашборд|свод|макрос)/;

  function parseCommand(text) {
    const s = norm(text);
    if (!s) return { ok: false, action: null, error: 'Пустая команда' };
    /* Отрицание в начале фразы — не выполняем, даже если ключевое слово есть */
    if (NEG.test(s) && /^(не|не надо|не нужно|стоп|отмен)/.test(s)) {
      return { ok: false, action: null, blocked: true, error: 'Вы просите НЕ делать — ничего не выполняю.' };
    }
    for (const r of RULES) {
      if (r.re.test(s)) {
        const out = { ok: true, action: r.action, text: text };
        /* вытащим год/период, если он назван словами */
        const m = /(\d{1,2})\s*(мес|месяц|период)/.exec(s);
        if (m) out.points = Number(m[1]);
        const y = /за\s+(\d{4})\s*(год|г)/.exec(s);
        if (y) out.year = Number(y[1]);
        if (r.action === 'union') out.args = { files: true };
        /* из фразы «по колонке 2» берём номер колонки */
        const c = /колонк[а-я]*\s*(\d{1,2})/.exec(s);
        if (c) out.col = Number(c[1]) - 1;
        return out;
      }
    }
    if (EXCELISH.test(s)) return { ok: false, action: null, needClarify: true, error: 'Похоже на задачу по таблице, но действие не понял. Что сделать: убрать дубли, свод, диаграмму, дашборд?' };
    return { ok: false, action: null, notExcel: true, error: 'Это не похоже на команду для Excel.' };
  }

  const TITLES = {
    dashboard: 'соберу дашборд', chart: 'построю диаграмму', analysis: 'проверю таблицу',
    dedupe: 'уберу дубликаты', dropEmpty: 'уберу пустые строки', group: 'сделаю свод',
    union: 'объединю таблицы', sortDesc: 'отсортирую по убыванию', sortAsc: 'отсортирую по возрастанию',
    macro: 'запущу макрос', open: 'открою файл',
  };
  function describe(cmd) {
    if (!cmd || !cmd.ok) return cmd && cmd.error ? cmd.error : 'Команда не распознана';
    return 'Понял: ' + (TITLES[cmd.action] || cmd.action)
      + (cmd.points ? ' · период: ' + cmd.points : '')
      + (cmd.col !== undefined ? ' · колонка ' + (cmd.col + 1) : '') + '.';
  }

  const api = { parseCommand, describe, TITLES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelCommands = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
