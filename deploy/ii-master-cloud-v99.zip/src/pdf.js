'use strict';

/**
 * Сборщик настоящего PDF с вшитым шрифтом (кириллица) — БЕЗ внешних библиотек.
 *   В браузере: window.PDFMAKE.buildPdf({ text, font: Uint8Array, ... })
 *   В Node:      require('src/pdf.js').buildPdf({...})
 *
 * Почему свой: pdf-lib в браузерной сборке не принимает пользовательский шрифт без fontkit,
 * а для русского текста шрифт нужно ВШИТЬ в файл. Здесь мы:
 *   1) разбираем TrueType (cmap, hmtx, head, hhea, maxp),
 *   2) кладём весь шрифт потоком /FontFile2,
 *   3) пишем текст через составной шрифт Type0/Identity-H (2 байта на символ = номер глифа),
 *   4) добавляем /ToUnicode, чтобы текст можно было копировать и искать,
 *   5) выводим страницы постранично с переносом по словам.
 */

function u8(arr) { return new Uint8Array(arr); }
function u16be(v) { return [(v >> 8) & 255, v & 255]; }
function u32be(v) { return [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]; }
function ascii(s) { const a = []; for (let i = 0; i < s.length; i++) a.push(s.charCodeAt(i) & 255); return a; }
function latin1(bytes) { let s = ''; for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return s; }

/* ---------- разбор TrueType ---------- */
function parseTtf(buf) {
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const numTables = dv.getUint16(4);
  const tables = {};
  for (let i = 0; i < numTables; i++) {
    const off = 12 + i * 16;
    const tag = latin1(buf.subarray(off, off + 4));
    tables[tag] = { offset: dv.getUint32(off + 8), length: dv.getUint32(off + 12) };
  }
  const need = ['head', 'hhea', 'hmtx', 'cmap', 'maxp'];
  for (const t of need) if (!tables[t]) throw new Error('в шрифте нет таблицы ' + t);
  const head = tables.head.offset;
  const unitsPerEm = dv.getUint16(head + 18) || 2048;
  const indexToLoc = dv.getInt16(head + 50);
  const maxp = tables.maxp.offset;
  const numGlyphs = dv.getUint16(maxp + 4);
  const hhea = tables.hhea.offset;
  const numberOfHMetrics = dv.getUint16(hhea + 34);
  const ascent = dv.getInt16(hhea + 4);
  const descent = dv.getInt16(hhea + 6);
  const bbox = [dv.getInt16(head + 36), dv.getInt16(head + 38), dv.getInt16(head + 40), dv.getInt16(head + 42)];
  /* cmap: ищем подтаблицу формата 4 (Unicode BMP) */
  const cmap = tables.cmap.offset;
  const nSub = dv.getUint16(cmap + 2);
  let best = 0;
  for (let i = 0; i < nSub; i++) {
    const rec = cmap + 4 + i * 8;
    const platform = dv.getUint16(rec);
    const encoding = dv.getUint16(rec + 2);
    const sub = cmap + dv.getUint32(rec + 4);
    if (dv.getUint16(sub) !== 4) continue;
    const score = (platform === 3 && encoding === 1) ? 3 : (platform === 0 ? 2 : 1);
    if (score > best) { best = score; var chosen = sub; }
  }
  if (!chosen) throw new Error('в шрифте нет Unicode-таблицы cmap формата 4');
  const segX2 = dv.getUint16(chosen + 6);
  const segCount = segX2 / 2;
  const endBase = chosen + 14;
  const startBase = endBase + segX2 + 2;
  const deltaBase = startBase + segX2;
  const rangeBase = deltaBase + segX2;
  function glyphOf(code) {
    if (code > 0xFFFF) return 0;
    for (let s = 0; s < segCount; s++) {
      const end = dv.getUint16(endBase + s * 2);
      if (code > end) continue;
      const start = dv.getUint16(startBase + s * 2);
      if (code < start) return 0;
      const delta = dv.getInt16(deltaBase + s * 2);
      const ro = dv.getUint16(rangeBase + s * 2);
      if (ro === 0) return (code + delta) & 0xFFFF;
      const gi = rangeBase + s * 2 + ro + (code - start) * 2;
      if (gi + 1 >= buf.length) return 0;
      const g = dv.getUint16(gi);
      return g === 0 ? 0 : (g + delta) & 0xFFFF;
    }
    return 0;
  }
  /* ширины: hmtx (последние глифы повторяют последнюю запись) */
  const hmtx = tables.hmtx.offset;
  function advanceOf(gid) {
    const i = Math.min(gid, numberOfHMetrics - 1);
    if (hmtx + i * 4 + 1 >= buf.length) return unitsPerEm / 2;
    return dv.getUint16(hmtx + i * 4);
  }
  return { unitsPerEm, numGlyphs, indexToLoc, ascent, descent, bbox, glyphOf, advanceOf, fontBytes: buf.length };
}

/* ---------- помощники PDF ---------- */
function pdfString(s) { return '(' + String(s).replace(/([\\()])/g, '\\$1') + ')'; }
function hexOf(gids) {
  let s = '';
  gids.forEach((g) => { s += g.toString(16).padStart(4, '0').toUpperCase(); });
  return s;
}
function toUnicodeCMap(map) {
  /* beginbfchar принимает не больше 100 записей на блок — иначе копирование текста ломается */
  const lines = [];
  map.forEach((uni, gid) => {
    lines.push('<' + gid.toString(16).toUpperCase().padStart(4, '0') + '> <'
      + uni.toString(16).toUpperCase().padStart(4, '0') + '>');
  });
  let blocks = '';
  for (let i = 0; i < lines.length; i += 100) {
    const part = lines.slice(i, i + 100);
    blocks += part.length + ' beginbfchar\n' + part.join('\n') + '\nendbfchar\n';
  }
  return '/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n'
    + '/CIDSystemInfo <</Registry (Adobe) /Ordering (UCS) /Supplement 0>> def\n'
    + '/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n'
    + '1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n'
    + blocks
    + 'endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend';
}

/* ---------- сборка PDF ---------- */
function buildPdf(opts) {
  const o = opts || {};
  const fontBytes = o.font ? (o.font instanceof Uint8Array ? o.font : u8(o.font)) : null;
  if (!fontBytes) throw new Error('нужен шрифт (TTF) для вшивания');
  const f = parseTtf(fontBytes);
  const text = String(o.text || '');
  const pageW = o.pageW || 595.28;
  const pageH = o.pageH || 841.89;
  const margin = o.margin || 56;
  const maxW = pageW - margin * 2;

  /* глифы и их ширины: собираем по мере вёрстки */
  const used = new Map();          /* gid -> юникод (первый встреченный) */
  const gidOf = (ch) => {
    const code = ch.codePointAt(0);
    const gid = f.glyphOf(code);
    if (gid) { if (!used.has(gid)) used.set(gid, code); return gid; }
    return 0;
  };
  const widthOf = (str, size) => {
    let w = 0;
    for (const ch of str) w += f.advanceOf(gidOf(ch));
    return w * size / f.unitsPerEm;
  };
  const wrap = (str, size) => {
    const out = []; let cur = '';
    String(str).split(/\s+/).forEach((w) => {
      const t = cur ? cur + ' ' + w : w;
      if (widthOf(t, size) > maxW && cur) { out.push(cur); cur = w; } else cur = t;
    });
    if (cur) out.push(cur);
    return out.length ? out : [''];
  };

  const pages = [];
  let cur = null, y = 0;
  const newPage = () => { cur = []; pages.push(cur); y = pageH - margin; };
  const put = (str, size) => {
    if (!str.trim()) { y -= size * 0.7; return; }
    if (y < margin + size * 1.4) newPage();
    cur.push({ s: str, size, y });
    y -= size * 1.45;
  };
  newPage();
  text.replace(/\r/g, '').split('\n').forEach((raw) => {
    const t = raw.replace(/\*\*/g, '');
    if (!t.trim()) { y -= 7; return; }
    let size = 11;
    if (/^#\s+/.test(t)) size = 19;
    else if (/^##\s+/.test(t)) size = 15;
    else if (/^###\s+/.test(t)) size = 13;
    const body = t.replace(/^#{1,3}\s+/, '').replace(/^\s*[-•]\s+/, '• ');
    wrap(body, size).forEach((line) => put(line, size));
  });

  /* содержимое страниц */
  const contents = pages.map((lines) => {
    let s = '';
    lines.forEach((l) => {
      const gids = [];
      for (const ch of l.s) gids.push(gidOf(ch));
      s += 'BT /F1 ' + l.size + ' Tf 1 0 0 1 ' + margin.toFixed(2) + ' ' + l.y.toFixed(2) + ' Tm <' + hexOf(gids) + '> Tj ET\n';
    });
    return s;
  });

  /* объекты */
  const objs = [];
  const add = (body) => { objs.push(body); return objs.length; };
  const fontName = 'DejaVuSans';
  const W = [...used.keys()].sort((a, b) => a - b).map((gid) => gid + ' [' + Math.round(f.advanceOf(gid) * 1000 / f.unitsPerEm) + ']').join(' ');
  const scale = (v) => Math.round(v * 1000 / f.unitsPerEm);
  const fontFileObj = add({ stream: fontBytes, extra: '/Length1 ' + fontBytes.length });
  const descObj = add({ text: '<</Type /FontDescriptor /FontName /' + fontName + ' /Flags 4 '
    + '/FontBBox [' + f.bbox.map(scale).join(' ') + '] /ItalicAngle 0 /Ascent ' + scale(f.ascent)
    + ' /Descent ' + scale(f.descent) + ' /CapHeight ' + scale(f.ascent) + ' /StemV 80 '
    + '/FontFile2 ' + fontFileObj + ' 0 R>>' });
  const cidObj = add({ text: '<</Type /Font /Subtype /CIDFontType2 /BaseFont /' + fontName
    + ' /CIDSystemInfo <</Registry (Adobe) /Ordering (Identity) /Supplement 0>> '
    + '/FontDescriptor ' + descObj + ' 0 R /CIDToGIDMap /Identity /DW 1000 /W [' + W + ']>>' });
  const toUniObj = add({ stream: u8(ascii(toUnicodeCMap(used))), extra: '' });
  const type0Obj = add({ text: '<</Type /Font /Subtype /Type0 /BaseFont /' + fontName
    + ' /Encoding /Identity-H /DescendantFonts [' + cidObj + ' 0 R] /ToUnicode ' + toUniObj + ' 0 R>>' });
  const contentObjs = contents.map((c) => add({ stream: u8(ascii(c)), extra: '' }));
  /* страницы и дерево */
  const pageIds = [];
  contentObjs.forEach((co, i) => {
    pageIds.push(add({ text: '<</Type /Page /Parent PAGES 0 R /MediaBox [0 0 ' + pageW.toFixed(2) + ' ' + pageH.toFixed(2)
      + '] /Resources <</Font <</F1 ' + type0Obj + ' 0 R>>>> /Contents ' + co + ' 0 R>>' }));
  });
  const pagesObj = add({ text: '<</Type /Pages /Kids [' + pageIds.map((id) => id + ' 0 R').join(' ') + '] /Count ' + pageIds.length + '>>' });
  const catObj = add({ text: '<</Type /Catalog /Pages ' + pagesObj + ' 0 R>>' });
  /* подставляем номер страниц в ссылки */
  objs.forEach((ob) => { if (ob.text) ob.text = ob.text.replace(/PAGES 0 R/g, pagesObj + ' 0 R'); });

  /* собираем файл */
  const chunks = [];
  const push = (a) => chunks.push(a instanceof Uint8Array ? a : u8(a));
  push(ascii('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'));
  const offsets = [0];
  objs.forEach((ob, i) => {
    offsets.push(chunks.reduce((n, c) => n + c.length, 0));
    if (ob.stream) {
      push(ascii((i + 1) + ' 0 obj <</Length ' + ob.stream.length + ' ' + (ob.extra || '') + '>>\nstream\n'));
      push(ob.stream);
      push(ascii('\nendstream\nendobj\n'));
    } else {
      push(ascii((i + 1) + ' 0 obj ' + ob.text + '\nendobj\n'));
    }
  });
  const xrefPos = chunks.reduce((n, c) => n + c.length, 0);
  let xref = 'xref\n0 ' + (objs.length + 1) + '\n0000000000 65535 f \n';
  for (let i = 1; i <= objs.length; i++) xref += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  push(ascii(xref));
  push(ascii('trailer <</Size ' + (objs.length + 1) + ' /Root ' + catObj + ' 0 R>>\nstartxref\n' + xrefPos + '\n%%EOF\n'));

  const total = chunks.reduce((n, c) => n + c.length, 0);
  const out = new Uint8Array(total);
  let pos = 0;
  chunks.forEach((c) => { out.set(c, pos); pos += c.length; });
  return out;
}

if (typeof module !== 'undefined' && module.exports) module.exports = { buildPdf, parseTtf };
if (typeof window !== 'undefined') window.PDFMAKE = { buildPdf, parseTtf };
