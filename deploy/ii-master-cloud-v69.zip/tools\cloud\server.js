'use strict';

/**
 * Облачный сервер «ИИ Мастер» - пилот, срез 27 (01.10.2026).
 *
 * Задача среза: приложение должно открываться с любого телефона, а данные (диалоги, агенты,
 * настройки, Баксы) жить на сервере, а не в браузере. Это первый шаг: сервер + база + аккаунты.
 * Экран входа в самом приложении - следующий шаг (срез 28).
 *
 * Решения:
 *  - База - встроенная в Node `node:sqlite` (ничего не компилируется, на сервере не нужны библиотеки).
 *  - Пароли - только в виде хэша scrypt со своей солью (`node:crypto`), открытый пароль не хранится.
 *  - Токены сессии - случайные 32 байта; в базе лежит только их SHA-256 (утечка базы не даёт войти).
 *  - SQL - только параметризованный (никаких склеек строк).
 *  - Данные строго разделены по пользователю: любой запрос к состоянию идёт через его user_id.
 *
 * Запуск:  node tools/cloud/server.js          (порт 8790)
 *          CLOUD_PORT=8080 CLOUD_DATA=/opt/ii-master/data node tools/cloud/server.js
 */

const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

/* У api.z.ai есть и IPv4, и IPv6. Если у провайдера IPv6 не работает, запрос уходит в «мёртвую»
   сеть и падает. Ставим приоритет IPv4 - как в локальном сервере (tools/serve.js). */
try { dns.setDefaultResultOrder('ipv4first'); } catch (e) { /* старая версия Node */ }

const ROOT = path.resolve(__dirname, '..', '..');
const DATA_DIR = process.env.CLOUD_DATA ? path.resolve(process.env.CLOUD_DATA) : path.join(ROOT, 'data');
const PORT = Number(process.env.CLOUD_PORT || 8790);
const MAX_BODY = 1024 * 1024;          /* 1 МБ на запрос - состояние, а не файлы */
const MAX_VALUE = 200 * 1024;          /* 200 КБ на одно значение состояния */
const MIN_PASS = 8;

/* Лимит трат на человека в день, в рублях. Баксы считаем по курсу приложения.
   Владелец меняет переменной CLOUD_LIMIT_RUB при запуске службы; 0 - без ограничения. */
/* Лимит трат в рублях на человека в день. Берём из простого файла limit.txt (там только число)
   или из переменной. Владелец меняет короткой командой БЕЗ подчёркиваний:
   echo 300 > /opt/ii-master/limit.txt   (потом systemctl restart ii-master) */
const LIMIT_RUB = (function () {
  if (process.env.CLOUD_LIMIT_RUB) return Number(process.env.CLOUD_LIMIT_RUB);
  try {
    const n = Number(fs.readFileSync(path.join(path.dirname(DATA_DIR), 'limit.txt'), 'utf8').trim());
    if (Number.isFinite(n) && n >= 0) return n;
  } catch (e) { /* файла нет - значение по умолчанию */ }
  return 100;
})();
const BAKS_PER_RUB = 11666.67;
/* Приветственный бонус: даётся ОДИН раз на аккаунт (баланс общий для облака, ПК и телефона) */
const WELCOME_BAKS = Math.max(0, Math.floor(Number(process.env.CLOUD_WELCOME_BAKS || 1000000)));
const LIMIT_BAKS = LIMIT_RUB > 0 ? Math.floor(LIMIT_RUB * BAKS_PER_RUB) : 0;
function todayKey() { return new Date().toISOString().slice(0, 10); }
function spentTodayBaks(userId) {
  return db.prepare('SELECT COALESCE(SUM(baks), 0) AS s FROM spend WHERE user_id = ? AND day = ?')
    .get(userId, todayKey()).s;
}

/* ---------- резервные копии (срез 32) ----------
   Правило владельца: три копии на трёх разных носителях (оригинал на сервере + внешний диск +
   флэшка). Здесь делается первая часть: сервер сам раз в сутки снимает копию базы и хранит
   последние N. Копия снимается командой VACUUM INTO - это безопасно даже во время работы
   (обычное копирование файла может поймать базу «на полуслове»).
   Забрать копию на компьютер владельца можно по ключу: /api/backup/latest?key=… */
const BACKUP_DIR = process.env.CLOUD_BACKUP_DIR || path.join(path.dirname(DATA_DIR), 'backups');
const BACKUP_KEEP = Number(process.env.CLOUD_BACKUP_KEEP || 14);
const KEY_FILE = path.join(path.dirname(DATA_DIR), 'key.txt');
/* Ключ для скачивания копий. Владельцу НЕ нужно ничего придумывать и вводить команды с
   подчёркиваниями: сервер сам создаёт ключ при первом запуске и кладёт его в файл key.txt.
   Прочитать: cat /opt/ii-master/key.txt */
const BACKUP_KEY = (function () {
  const fromEnv = String(process.env.CLOUD_BACKUP_KEY || '');
  if (fromEnv) return fromEnv;
  try {
    const saved = fs.readFileSync(KEY_FILE, 'utf8').trim();
    if (saved) return saved;
  } catch (e) { /* файла ещё нет */ }
  const fresh = crypto.randomBytes(12).toString('hex');
  try { fs.writeFileSync(KEY_FILE, fresh, 'utf8'); } catch (e) { /* не смогли сохранить - покажем в консоли */ }
  return fresh;
})();
fs.mkdirSync(BACKUP_DIR, { recursive: true });

function makeBackup(reason) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(BACKUP_DIR, 'cloud-' + stamp + '.db');
  try {
    db.exec("VACUUM INTO '" + file.replace(/'/g, "''") + "'");
    const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
    for (const old of files.slice(0, Math.max(0, files.length - BACKUP_KEEP))) {
      try { fs.unlinkSync(path.join(BACKUP_DIR, old)); } catch (e) { /* не критично */ }
    }
    console.log('[резерв] копия готова: ' + path.basename(file) + ' (' + reason + ')');
    return path.basename(file);
  } catch (e) {
    console.log('[резерв] НЕ удалось сделать копию: ' + (e && e.message ? e.message : e));
    return null;
  }
}

/* Проверяем раз в час: если за сегодня копии ещё нет - делаем. Так копия появится даже после
   перезагрузки сервера, и не нужен внешний планировщик. */
function backupTick() {
  try {
    const day = todayKey();
    const has = fs.readdirSync(BACKUP_DIR).some((f) => f.indexOf(day) !== -1);
    if (!has) makeBackup('по расписанию');
  } catch (e) { /* каталог недоступен - уже сообщили при создании копии */ }
}
setInterval(backupTick, 3600000);

fs.mkdirSync(DATA_DIR, { recursive: true });

/* Robokassa (срез 31, шаг 3). Пока переменные пусты - работает тестовый режим.
   Когда владелец впишет данные в /opt/ii-master/pay.env и перезапустит службу - включится
   боевой приём платежей (ссылка на оплату + зачисление по ResultURL). */
const RB_LOGIN = String(process.env.ROBOKASSA_LOGIN || '').trim();
const RB_PASS1 = String(process.env.ROBOKASSA_PASS1 || '').trim();
const RB_PASS2 = String(process.env.ROBOKASSA_PASS2 || '').trim();
const RB_ON = !!(RB_LOGIN && RB_PASS1 && RB_PASS2);
const md5hex = (s) => crypto.createHash('md5').update(String(s)).digest('hex');

/* ЮKassa (срез 31, шаг 4). Владелец - самозанятая (НПД), поэтому выбран провайдер, который
   подключает НПД штатно: без ИП, без кассы, чеки - через «Мой налог». Пока переменные пусты -
   работает тестовый режим. Когда владелец впишет данные в /opt/ii-master/pay.env и перезапустит
   службу - включится боевой приём платежей (ссылка на оплату + зачисление по вебхуку).
   Ключи живут только в pay.env: в коде и логах их нет. */
const YK_SHOP_ID = String(process.env.YOOKASSA_SHOP_ID || '').trim();
const YK_SECRET = String(process.env.YOOKASSA_SECRET_KEY || '').trim();
const YK_API = String(process.env.YOOKASSA_API || 'https://api.yookassa.ru').replace(/\/+$/, '');
const YK_RETURN_URL = String(process.env.YOOKASSA_RETURN_URL || 'https://app.ii-master.ru/').trim();

/* ===== Вход через Яндекс/Google (срез 38) =====
   Секреты берём ТОЛЬКО из окружения - файл /opt/ii-master/oauth.env (в репозиторий не попадают).
   Адрес возврата строится из OAUTH_BASE (по умолчанию живой домен приложения). */
const OAUTH_BASE = String(process.env.OAUTH_BASE || 'https://app.ii-master.ru').replace(/\/+$/, '');
const YA_ID = String(process.env.YANDEX_CLIENT_ID || '').trim();
const YA_SECRET = String(process.env.YANDEX_CLIENT_SECRET || '').trim();
const GO_ID = String(process.env.GOOGLE_CLIENT_ID || '').trim();
const GO_SECRET = String(process.env.GOOGLE_CLIENT_SECRET || '').trim();
const oauthStates = new Map();     /* state -> время создания (защита от подмены, живёт 10 минут) */
const YK_ON = !!(YK_SHOP_ID && YK_SECRET);

/* Один запрос к API ЮKassa. Авторизация - Basic (shopId:секретный ключ).
   Возвращаем { ok, status, data }, где ok = успешный HTTP-ответ (2xx). */
async function ykRequest(method, pathname, body, idempotenceKey) {
  const auth = 'Basic ' + Buffer.from(YK_SHOP_ID + ':' + YK_SECRET).toString('base64');
  const headers = { authorization: auth, 'content-type': 'application/json' };
  if (idempotenceKey) headers['idempotence-key'] = idempotenceKey;
  const res = await fetch(YK_API + pathname, {
    method: method,
    headers: headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data = null;
  try { data = await res.json(); } catch (e) { data = null; }
  return { ok: res.ok, status: res.status, data: data };
}

const db = new DatabaseSync(path.join(DATA_DIR, 'cloud.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');
db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  pass_salt TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  last_seen TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS state (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, key)
)`);
/* Учёт расходов: одна строка на каждую трату человека. Нужен, чтобы лимит считался на сервере,
   а не «на глазок» в браузере (срез 29). */
db.exec(`CREATE TABLE IF NOT EXISTS spend (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  at TEXT NOT NULL,
  baks INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT ''
)`);
/* Платежи (срез 31): пополнение Баксов. Тестовый режим зачисляет сразу; боевой (ЮKassa) будет
   ждать подтверждения от провайдера. Таблица отдельная - для истории покупок. */
db.exec(`CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  pack TEXT NOT NULL DEFAULT '',
  price_rub INTEGER NOT NULL,
  baks INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'created',
  provider TEXT NOT NULL DEFAULT 'test'
)`);

/* Реферальная программа: код у каждого пользователя, учёт переходов и заработка.
   users.ref_code - личный код; users.ref_by - кто пригласил (id пригласившего). */
try { db.exec('ALTER TABLE users ADD COLUMN ref_code TEXT'); } catch (e) { /* уже есть */ }
try { db.exec('ALTER TABLE users ADD COLUMN ref_by INTEGER'); } catch (e) { /* уже есть */ }
db.exec(`CREATE TABLE IF NOT EXISTS ref_clicks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL,
  at TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS ref_earn (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  at TEXT NOT NULL
)`);

/* Начисление Баксов человеку: прибавляем к его состоянию 'app'. Одна точка на все способы
   оплаты (тестовый режим, Робокасса, ЮKassa) - чтобы зачисление нигде не расходилось. */
function creditBaks(userId, baks, at) {
  const row = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(userId, 'app');
  let st = {};
  if (row) { try { st = JSON.parse(row.value) || {}; } catch (e) { st = {}; } }
  st.baks = Math.max(0, Math.floor(Number(st.baks || 0))) + baks;
  db.prepare(`INSERT INTO state (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
    ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
    .run(userId, 'app', JSON.stringify(st), at || new Date().toISOString());
  return st.baks;
}

/* ---------- реферальная программа ---------- */
const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   /* без похожих 0/O и 1/I */
function genRefCode() {
  let s = '';
  for (let i = 0; i < 10; i++) s += REF_ALPHABET[crypto.randomInt(REF_ALPHABET.length)];
  return s;
}
/* Личный код пользователя (создаём при первом обращении, если его ещё нет) */
function ensureRefCode(userId) {
  const row = db.prepare('SELECT ref_code FROM users WHERE id = ?').get(userId);
  if (!row) return '';
  if (row.ref_code) return row.ref_code;
  for (let i = 0; i < 20; i++) {
    const code = genRefCode();
    if (!db.prepare('SELECT id FROM users WHERE ref_code = ?').get(code)) {
      db.prepare('UPDATE users SET ref_code = ? WHERE id = ?').run(code, userId);
      return code;
    }
  }
  return '';
}
/* Покупка Баксов: начисляем покупателю и, если его кто-то пригласил, 10% - пригласившему. */
function grantPurchase(userId, baks, at) {
  const now = at || new Date().toISOString();
  const total = creditBaks(userId, baks, now);
  try {
    const u = db.prepare('SELECT ref_by FROM users WHERE id = ?').get(userId);
    if (u && u.ref_by && u.ref_by !== userId) {
      const bonus = Math.floor(Number(baks) * 0.10);
      if (bonus > 0) {
        creditBaks(u.ref_by, bonus, now);
        db.prepare('INSERT INTO ref_earn (referrer_id, amount, at) VALUES (?, ?, ?)').run(u.ref_by, bonus, now);
      }
    }
  } catch (e) { /* реферальный бонус не должен ломать зачисление */ }
  return total;
}
function refStats(userId) {
  const code = ensureRefCode(userId);
  const clicks = db.prepare('SELECT COUNT(*) AS n FROM ref_clicks WHERE code = ?').get(code).n;
  const regs = db.prepare('SELECT COUNT(*) AS n FROM users WHERE ref_by = ?').get(userId).n;
  const earned = db.prepare('SELECT COALESCE(SUM(amount), 0) AS s FROM ref_earn WHERE referrer_id = ?').get(userId).s;
  return { code, clicks, regs, earned };
}
function linkForCode(code) { return (OAUTH_BASE + '/?ref=' + encodeURIComponent(code)); }

/* ===== Бесплатный поиск в интернете (DuckDuckGo) - в облаке тоже =====
   Тот же приём, что в локальном сервере, но через fetch: сервер идёт в lite.duckduckgo.com
   и разбирает результаты. Ключей и оплаты нет; работает для облачной и мобильной версии. */
const UA_BROWSER = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/126 Safari/537.36';
function stripTags(s) {
  return String(s == null ? '' : s).replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&#0?39;|&apos;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCharCode(+n))
    .replace(/\s+/g, ' ').trim();
}
function ddgRealUrl(href) {
  let h = String(href || '');
  const m = h.match(/[?&]uddg=([^&]+)/);
  if (m) { try { h = decodeURIComponent(m[1]); } catch (e) {} }
  if (h.startsWith('//')) h = 'https:' + h;
  return h;
}
function parseDdg(html) {
  const snippets = [];
  const sn = /class=['"]result-snippet['"][^>]*>([\s\S]*?)<\/td>/gi;
  let ms;
  while ((ms = sn.exec(html))) snippets.push(stripTags(ms[1]));
  const out = [];
  const re = /<a\b[^>]*class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>/gi;
  let m, i = 0;
  while ((m = re.exec(html))) {
    const href = (m[0].match(/href=["']([^"']+)["']/i) || [])[1] || '';
    const url = ddgRealUrl(href);
    const title = stripTags(m[1]);
    if (!/^https?:\/\//i.test(url) || !title) continue;
    let host = '';
    try { host = new URL(url).hostname.replace(/^www\./, ''); } catch (e) {}
    out.push({ title, url, snippet: snippets[i] || '', host });
    i += 1;
  }
  return out.slice(0, 8);
}
/* ---- Цены Wildberries: открытый каталог (без ключей). Поиск даёт товары без цен,
   цену берём из карточки. Если сервис не отдал - честно сообщаем, ничего не выдумываем. ---- */
const WB_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36';
function wbPriceRub(pr) {
  const cands = [pr.salePriceU, pr.priceU, pr.salePrice, pr.price];
  for (const c of cands) { const n = Number(c); if (isFinite(n) && n > 0) return Math.round(n / 100); }
  const sz = Array.isArray(pr.sizes) && pr.sizes[0];
  const p = sz && (sz.price || (sz.sizes && sz.sizes[0]));
  const total = p && (p.total || p.product);
  const n2 = Number(total);
  return isFinite(n2) && n2 > 0 ? Math.round(n2 / 100) : null;
}
async function wbFetchJson(url) {
  try {
    const r = await fetch(url, { headers: { 'User-Agent': WB_UA, 'Accept': 'application/json',
      'Referer': 'https://www.wildberries.ru/', 'Origin': 'https://www.wildberries.ru' } });
    if (!r.ok) return { ok: false, status: r.status };
    return { ok: true, j: await r.json() };
  } catch (e) { return { ok: false, status: 0 }; }
}
async function wbPrices(q, limit) {
  const s = await wbFetchJson('https://search.wb.ru/exactmatch/ru/common/v4/search'
    + '?ab_testing=false&appType=1&curr=rub&dest=-1257786&query=' + encodeURIComponent(q)
    + '&resultset=catalog&sort=popular&spp=30&suppressSpellcheck=false');
  if (!s.ok) return { ok: false, error: 'Wildberries не ответил (код ' + (s.status || 'сеть') + ')' };
  const list = ((s.j && s.j.data && s.j.data.products) || []).slice(0, limit);
  if (!list.length) return { ok: false, error: 'Wildberries ничего не нашёл по запросу «' + q + '»' };
  const items = [];
  for (const p of list) {
    let price = wbPriceRub(p);
    if (price === null && p.id) {
      const c = await wbFetchJson('https://card.wb.ru/cards/v2/detail?appType=1&curr=rub&dest=-1257786&nm=' + p.id);
      const cp = c.ok && c.j && c.j.data && c.j.data.products && c.j.data.products[0];
      if (cp) price = wbPriceRub(cp);
    }
    items.push({ name: String(p.name || '').trim(), brand: String(p.brand || '').trim(),
      price: price, rating: Number(p.rating) || 0, feedbacks: Number(p.feedbacks) || 0,
      url: p.id ? ('https://www.wildberries.ru/catalog/' + p.id + '/detail.aspx') : '' });
  }
  const withPrice = items.filter((i) => i.price);
  withPrice.sort((a, b) => a.price - b.price);
  return { ok: true, source: 'wildberries', items: withPrice.length ? withPrice : items,
    note: withPrice.length ? '' : 'цены не отдались', date: new Date().toISOString().slice(0, 10) };
}

async function searchWeb(payload, res) {  const q = String((payload && payload.q) || '').trim();
  if (!q) return json(res, 400, { error: 'Пустой запрос' });
  try {
    const r = await fetch('https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(q), {
      headers: { 'User-Agent': UA_BROWSER, 'Accept': 'text/html,application/xhtml+xml', 'Accept-Language': 'ru,en;q=0.8' },
    });
    const results = parseDdg(await r.text());
    if (!results.length) {
      return json(res, 200, { ok: false, error: 'Поиск не дал результатов (сервис мог ограничить частые запросы). Повторите позже.' });
    }
    console.log('[поиск] облако: ' + results.length + ' результатов (DuckDuckGo)');
    return json(res, 200, { ok: true, results });
  } catch (e) {
    return json(res, 502, { error: 'Не удалось выполнить поиск: ' + (e && e.message ? e.message : e) });
  }
}

/* ---------- пароли и токены ---------- */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function checkPassword(password, salt, hash) {
  const calc = crypto.scryptSync(String(password), String(salt), 64);
  const saved = Buffer.from(String(hash), 'hex');
  return calc.length === saved.length && crypto.timingSafeEqual(calc, saved);
}
function tokenOf() { return crypto.randomBytes(32).toString('hex'); }
function tokenKey(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[a-zа-яё]{2,}$/i;

/* ---------- вход через Яндекс/Google ---------- */
/* Выдаём сессию (токен) пользователю - тот же механизм, что при обычном входе */
function newSession(userId) {
  const token = tokenOf();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
    .run(tokenKey(token), userId, now, now);
  return token;
}
/* Почта из соцпрофиля: есть такой аккаунт - входим в него (привязка по почте), нет - создаём.
   Пароль у соц-аккаунта случайный: вход по паролю для него не предусмотрен (только через соцсеть). */
function findOrCreateByEmail(email) {
  const mail = String(email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(mail)) return null;
  let row = db.prepare('SELECT id, email FROM users WHERE email = ?').get(mail);
  if (row) { ensureRefCode(row.id); return { user: row, isNew: false }; }
  const { salt, hash } = hashPassword(crypto.randomBytes(24).toString('hex'));
  const now = new Date().toISOString();
  db.prepare('INSERT INTO users (email, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?)')
    .run(mail, salt, hash, now);
  row = db.prepare('SELECT id, email FROM users WHERE email = ?').get(mail);
  ensureRefCode(row.id);
  return { user: row, isNew: true };
}
function redirect(res, to) {
  res.writeHead(302, { location: to, 'cache-control': 'no-store' });
  res.end();
}
function newOauthState() {
  const s = crypto.randomBytes(16).toString('hex');
  const limit = Date.now() - 10 * 60 * 1000;
  for (const [k, t] of oauthStates) if (t < limit) oauthStates.delete(k);
  oauthStates.set(s, Date.now());
  return s;
}
function checkOauthState(s) {
  const key = String(s || '');
  const t = oauthStates.get(key);
  if (!t) return false;
  oauthStates.delete(key);
  return Date.now() - t < 10 * 60 * 1000;
}

/* ---------- простые помощники ---------- */
function json(res, code, obj) {
  const body = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'Content-Type, Authorization',
    'access-control-allow-methods': 'GET, POST, PUT, OPTIONS',
  });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('too_large')); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => {
      try { resolve(parts.length ? JSON.parse(Buffer.concat(parts).toString('utf8')) : {}); }
      catch (e) { reject(new Error('bad_json')); }
    });
    req.on('error', reject);
  });
}
/* Кто это. Токен приходит в заголовке Authorization: Bearer <токен> */
function userOf(req) {
  const raw = String(req.headers.authorization || '');
  const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(raw);
  if (!m) return null;
  const row = db.prepare(
    'SELECT s.user_id AS id, u.email AS email, s.token_hash AS th FROM sessions s'
    + ' JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?'
  ).get(tokenKey(m[1]));
  if (!row) return null;
  db.prepare('UPDATE sessions SET last_seen = ? WHERE token_hash = ?')
    .run(new Date().toISOString(), row.th);
  return { id: row.id, email: row.email };
}

/* Ограничение попыток входа: не больше 20 неудач с одного адреса за 10 минут */
const tries = new Map();
function tooManyTries(ip) {
  const now = Date.now();
  const rec = tries.get(ip);
  if (!rec || now > rec.until) { tries.set(ip, { n: 0, until: now + 600000 }); return false; }
  return rec.n >= 20;
}
function noteTry(ip) {
  const rec = tries.get(ip) || { n: 0, until: Date.now() + 600000 };
  rec.n += 1;
  tries.set(ip, rec);
}

/* ---------- отдача приложения и прокси к моделям ----------
   Точно так же, как локальный tools/serve.js: браузер не может звать z.ai напрямую (CORS),
   поэтому приложение просит /proxy/<путь>, а сервер пересылает запрос выбранному сервису.
   Ключ сервиса остаётся у пользователя в настройках и уходит только выбранному сервису. */
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
};
const ALLOW = [
  /^https:\/\/api\.z\.ai\//,
  /^https:\/\/gptunnel\.ru\//,
  /^https:\/\/agenthere\.ru\//,
  /^https:\/\/llm\.api\.cloud\.yandex\.net\//,
  /^https:\/\/tts\.api\.cloud\.yandex\.net\//,
  /^https:\/\/api\.telegram\.org\//,
  /^https:\/\/openrouter\.ai\//,
  /^https:\/\/www\.cbr\.ru\//,
];
/* Признак для приложения: страницу отдал облачный сервер. Приложение по нему понимает, что
   нужно просить вход и хранить данные на сервере (см. блок «Облачный режим» в src/index.html). */
const CLOUD_FLAG = '<script>window.__cloudServer=true;</script>';
const IDLE_MS = 90000;
const MAX_BODY_UP = 4 * 1024 * 1024;

function upstream(u, req, res, body) {
  const mod = u.protocol === 'https:' ? https : http;
  const headers = Object.assign({}, req.headers);
  delete headers.host;
  delete headers['content-length'];
  delete headers['x-api-base'];
  if (body.length) headers['content-length'] = Buffer.byteLength(body);

  const p = mod.request({
    hostname: u.hostname,
    port: u.port || (u.protocol === 'https:' ? 443 : 80),
    path: u.pathname + u.search,
    method: req.method,
    headers,
  }, (up) => {
    const out = Object.assign({}, up.headers);
    delete out['transfer-encoding'];
    delete out.connection;
    res.writeHead(up.statusCode || 502, out);
    up.pipe(res);
  });
  p.on('socket', (s) => {
    s.setTimeout(IDLE_MS, () => p.destroy(Object.assign(new Error('таймаут связи'), { code: 'TIMEOUT' })));
  });
  p.on('error', (e) => {
    if (res.headersSent) { res.end(); return; }
    const code = (e && e.code) || '';
    console.log('[прокси] ошибка обращения к ' + u.hostname + ': ' + code);
    json(res, 502, {
      error: code === 'ENOTFOUND'
        ? 'Нет связи с сервисом: не удалось определить его адрес. Проверьте интернет на сервере.'
        : 'Не удалось связаться с сервисом: ' + (e && e.message ? e.message : e),
      code: code || 'unknown',
    });
  });
  p.end(body);
}

function proxyRequest(req, res, target) {
  let u;
  try { u = new URL(target); } catch (e) { json(res, 400, { error: 'Плохой адрес' }); return; }
  readRawBody(req).then((body) => upstream(u, req, res, body)).catch(() => {
    if (res.headersSent) { res.end(); return; }
    json(res, 413, { error: 'Запрос слишком большой' });
  });
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY_UP) { reject(new Error('too_large')); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}

function serveStatic(res, urlPath, host) {
  /* Загруженные пользователем файлы (для «дорисовки» фото): /u/<имя> - отдаём из папки данных */
  if (urlPath.indexOf('/u/') === 0) {
    const name = path.basename(decodeURIComponent(urlPath.slice(3)));
    const fullU = path.join(DATA_DIR, 'uploads', name);
    if (!name || !fullU.startsWith(path.join(DATA_DIR, 'uploads'))) { res.writeHead(403); res.end('Запрещено'); return; }
    fs.readFile(fullU, (e, d) => {
      if (e) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Не найдено'); return; }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(fullU).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'public, max-age=86400' });
      res.end(d);
    });
    return;
  }
  let file = urlPath;
  const h = String(host || '').toLowerCase();
  /* Один сервер обслуживает и приложение, и лендинг:
     app.ii-master.ru (и любой другой адрес) - приложение,
     ii-master.ru - лендинг. Так у сайта появляется рабочий HTTPS. */
  const isMain = h.indexOf('ii-master.ru') !== -1 && h.indexOf('app.') !== 0;
  if (file === '/' || file === '') file = isMain ? '/site/index.html' : '/src/index.html';
  if (file === '/manifest.webmanifest') file = '/src/manifest.webmanifest';
  if (file === '/sw.js') file = '/src/sw.js';
  if (isMain) {
    if (file.indexOf('/assets/') === 0) file = '/site' + file;
    if (file === '/privacy.html' || file === '/terms.html') file = '/site' + file;
  }
  const full = path.normalize(path.join(ROOT, file));
  if (!full.startsWith(ROOT)) { res.writeHead(403); res.end('Запрещено'); return; }
  fs.readFile(full, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Не найдено: ' + file);
      return;
    }
    const headers = { 'Content-Type': TYPES[path.extname(full).toLowerCase()] || 'application/octet-stream' };
    if (file === '/src/sw.js') headers['Service-Worker-Allowed'] = '/';
    if (/\.(html|webmanifest)$/i.test(file) || file === '/src/sw.js') {
      headers['Cache-Control'] = 'no-store, no-cache, must-revalidate';
    }
    if (file === '/src/index.html') {
      const html = data.toString('utf8').replace('<head>', '<head>' + CLOUD_FLAG);
      res.writeHead(200, headers);
      res.end(html);
      return;
    }
    res.writeHead(200, headers);
    res.end(data);
  });
}

/* ---------- маршруты ---------- */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const route = url.pathname;
  const method = req.method || 'GET';
  const ip = (req.socket && req.socket.remoteAddress) || 'local';

  try {
    /* CORS: чтобы приложение с любого устройства могло войти и синхронизироваться с облаком */
    if ((route.startsWith('/api/') || route.startsWith('/tools/')) && method === 'OPTIONS') {
      res.writeHead(204, {
        'access-control-allow-origin': '*',
        'access-control-allow-headers': 'Content-Type, Authorization',
        'access-control-allow-methods': 'GET, POST, PUT, OPTIONS',
        'access-control-max-age': '86400',
      });
      return res.end();
    }
    if (method === 'GET' && route === '/api/health') {
      const users = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
      return json(res, 200, { ok: true, build: 'cloud-v2', users, version: '0.1', data: DATA_DIR });
    }

    /* --- какие соцвходы настроены (для экрана входа) --- */
    if (method === 'GET' && route === '/api/auth/providers') {
      return json(res, 200, { yandex: !!(YA_ID && YA_SECRET), google: !!(GO_ID && GO_SECRET) });
    }

    /* --- реферальная программа --- */
    if (method === 'GET' && route === '/api/ref') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const st = refStats(me.id);
      return json(res, 200, { code: st.code, link: linkForCode(st.code), clicks: st.clicks, regs: st.regs, earned: st.earned });
    }
    if (method === 'POST' && route === '/api/ref/click') {
      let body = {};
      try { body = await readBody(req); } catch (e) { body = {}; }
      const code = String(body.code || '').trim().toUpperCase();
      if (!/^[A-Z2-9]{6,12}$/.test(code)) return json(res, 400, { error: 'Плохой код' });
      if (db.prepare('SELECT id FROM users WHERE ref_code = ?').get(code)) {
        db.prepare('INSERT INTO ref_clicks (code, at) VALUES (?, ?)').run(code, new Date().toISOString());
      }
      return json(res, 200, { ok: true });
    }

    /* Бесплатный поиск в интернете (DuckDuckGo) - для облачной и мобильной версии */
    if (method === 'POST' && route === '/tools/search') {
      let body = {};
      try { body = await readBody(req); } catch (e) { body = {}; }
      return searchWeb(body, res);
    }

    /* Загрузка картинки (для «дорисовки» фото): нужен вход. Файл кладём в данные, отдаём публичную ссылку.
       Читаем тело ВРУЧНУЮ и ВСЕГДА отвечаем: при превышении размера сообщаем об этом, а не рвём соединение
       (иначе у клиента «висит» загрузка — жалоба владельца 09.10.2026). */
    if (method === 'POST' && route === '/api/upload') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const raw = await new Promise((resolve) => {
        const parts = []; let size = 0; let done = false;
        const finish = (v) => { if (!done) { done = true; resolve(v); } };
        req.on('data', (c) => {
          size += c.length;
          if (size > 12 * 1024 * 1024) { finish({ tooLarge: true }); return; }
          parts.push(c);
        });
        req.on('end', () => finish({ buf: Buffer.concat(parts) }));
        req.on('error', () => finish({ bad: true }));
      });
      if (raw && raw.tooLarge) {
        json(res, 413, { error: 'Файл больше 12 МБ — уменьшите фото и попробуйте снова' });
        try { req.destroy(); } catch (e) {}
        return;
      }
      if (!raw || !raw.buf) return json(res, 400, { error: 'Не удалось прочитать файл' });
      let body = {};
      try { body = JSON.parse(raw.buf.toString('utf8') || '{}'); } catch (e) { return json(res, 400, { error: 'Не удалось прочитать файл' }); }
      const m = /^data:(image\/(?:png|jpeg|jpg|webp|gif));base64,([A-Za-z0-9+/=\s]+)$/.exec(String(body.dataUrl || ''));
      if (!m) return json(res, 400, { error: 'Поддерживаются картинки PNG, JPEG, WebP или GIF' });
      const buf = Buffer.from(m[2].replace(/\s+/g, ''), 'base64');
      if (!buf.length) return json(res, 400, { error: 'Пустой файл' });
      if (buf.length > 8 * 1024 * 1024) return json(res, 413, { error: 'Файл больше 8 МБ — уменьшите фото' });
      const ext = (m[1] === 'image/png') ? '.png' : (m[1] === 'image/webp') ? '.webp' : (m[1] === 'image/gif') ? '.gif' : '.jpg';
      const dir = path.join(DATA_DIR, 'uploads');
      fs.mkdirSync(dir, { recursive: true });
      const name = crypto.createHash('sha1').update(buf).digest('hex').slice(0, 24) + ext;
      fs.writeFileSync(path.join(dir, name), buf);
      const base = process.env.CLOUD_PUBLIC_URL || ('https://' + String(req.headers.host || 'app.ii-master.ru'));
      return json(res, 200, { ok: true, url: base.replace(/\/+$/, '') + '/u/' + name, size: buf.length });
    }


    /* Цены из открытого каталога Wildberries - сервер российский, поэтому шансов больше */
    if (method === 'POST' && route === '/tools/prices') {
      let body = {};
      try { body = await readBody(req); } catch (e) { body = {}; }
      const q = String(body.q || '').trim().slice(0, 120);
      if (!q) return json(res, 400, { error: 'Пустой запрос' });
      const limit = Math.min(10, Math.max(3, Number(body.limit) || 6));
      try {
        const out = await wbPrices(q, limit);
        return json(res, 200, out);
      } catch (e) {
        return json(res, 200, { ok: false, error: String((e && e.message) || e) });
      }
    }

    /* --- Яндекс --- */
    if (method === 'GET' && route === '/api/auth/yandex') {
      if (!(YA_ID && YA_SECRET)) return redirect(res, '/?oauth_error=yandex_off');
      const u = 'https://oauth.yandex.ru/authorize?response_type=code'
        + '&client_id=' + encodeURIComponent(YA_ID)
        + '&redirect_uri=' + encodeURIComponent(OAUTH_BASE + '/api/auth/yandex/callback')
        + '&state=' + newOauthState();
      return redirect(res, u);
    }
    if (method === 'GET' && route === '/api/auth/yandex/callback') {
      const q = new URL(req.url, 'http://localhost').searchParams;
      if (!checkOauthState(q.get('state'))) return redirect(res, '/?oauth_error=state');
      const code = q.get('code');
      if (!code) return redirect(res, '/?oauth_error=yandex_code');
      try {
        const form = new URLSearchParams({ grant_type: 'authorization_code', code: code,
          client_id: YA_ID, client_secret: YA_SECRET });
        const tr = await fetch('https://oauth.yandex.ru/token', {
          method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: form.toString(),
        });
        const tj = await tr.json().catch(() => ({}));
        const access = tj.access_token;
        if (!tr.ok || !access) { console.log('[oauth] yandex: не получили токен'); return redirect(res, '/?oauth_error=yandex_token'); }
        const ir = await fetch('https://login.yandex.ru/info?format=json', { headers: { Authorization: 'OAuth ' + access } });
        const ij = await ir.json().catch(() => ({}));
        const email = ij.default_email || (Array.isArray(ij.emails) && ij.emails[0]) || '';
        const r = findOrCreateByEmail(email);
        if (!r) { console.log('[oauth] yandex: почта не пришла'); return redirect(res, '/?oauth_error=yandex_email'); }
        const token = newSession(r.user.id);
        console.log('[oauth] yandex: ' + (r.isNew ? 'новый аккаунт' : 'вход в существующий') + ' (почта не логируется)');
        return redirect(res, '/?auth=' + token);
      } catch (e) {
        console.log('[oauth] yandex: сбой ' + e.message);
        return redirect(res, '/?oauth_error=yandex_fail');
      }
    }

    /* --- Google --- */
    if (method === 'GET' && route === '/api/auth/google') {
      if (!(GO_ID && GO_SECRET)) return redirect(res, '/?oauth_error=google_off');
      const u = 'https://accounts.google.com/o/oauth2/v2/auth?response_type=code'
        + '&client_id=' + encodeURIComponent(GO_ID)
        + '&redirect_uri=' + encodeURIComponent(OAUTH_BASE + '/api/auth/google/callback')
        + '&scope=' + encodeURIComponent('openid email profile')
        + '&access_type=online&prompt=select_account'
        + '&state=' + newOauthState();
      return redirect(res, u);
    }
    if (method === 'GET' && route === '/api/auth/google/callback') {
      const q = new URL(req.url, 'http://localhost').searchParams;
      if (!checkOauthState(q.get('state'))) return redirect(res, '/?oauth_error=state');
      const code = q.get('code');
      if (!code) return redirect(res, '/?oauth_error=google_code');
      try {
        const form = new URLSearchParams({ grant_type: 'authorization_code', code: code,
          client_id: GO_ID, client_secret: GO_SECRET, redirect_uri: OAUTH_BASE + '/api/auth/google/callback' });
        const tr = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: form.toString(),
        });
        const tj = await tr.json().catch(() => ({}));
        const access = tj.access_token;
        if (!tr.ok || !access) { console.log('[oauth] google: не получили токен'); return redirect(res, '/?oauth_error=google_token'); }
        const ir = await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: 'Bearer ' + access } });
        const ij = await ir.json().catch(() => ({}));
        const email = ij.email || '';
        const r = findOrCreateByEmail(email);
        if (!r) { console.log('[oauth] google: почта не пришла'); return redirect(res, '/?oauth_error=google_email'); }
        const token = newSession(r.user.id);
        console.log('[oauth] google: ' + (r.isNew ? 'новый аккаунт' : 'вход в существующий') + ' (почта не логируется)');
        return redirect(res, '/?auth=' + token);
      } catch (e) {
        console.log('[oauth] google: сбой ' + e.message);
        return redirect(res, '/?oauth_error=google_fail');
      }
    }

    if (method === 'POST' && (route === '/api/register' || route === '/api/login')) {
      if (tooManyTries(ip)) return json(res, 429, { error: 'Слишком много попыток. Попробуйте позже.' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      if (!EMAIL_RE.test(email)) return json(res, 400, { error: 'Проверьте адрес почты' });
      if (password.length < MIN_PASS) {
        return json(res, 400, { error: 'Пароль должен быть не короче ' + MIN_PASS + ' знаков' });
      }

      if (route === '/api/register') {
        if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
          return json(res, 409, { error: 'Такая почта уже зарегистрирована' });
        }
        const { salt, hash } = hashPassword(password);
        const now = new Date().toISOString();
        db.prepare('INSERT INTO users (email, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?)')
          .run(email, salt, hash, now);
        const user = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
        ensureRefCode(user.id);
        /* Приветственный бонус - ОДИН раз на аккаунт (почту): на телефоне, ПК и в облаке баланс общий */
        const baks = creditBaks(user.id, WELCOME_BAKS, now);
        const refCode = String(body.ref || '').trim().toUpperCase();
        if (refCode) {
          const ref = db.prepare('SELECT id FROM users WHERE ref_code = ?').get(refCode);
          if (ref && ref.id !== user.id) db.prepare('UPDATE users SET ref_by = ? WHERE id = ?').run(ref.id, user.id);
        }
        const token = tokenOf();
        db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
          .run(tokenKey(token), user.id, now, now);
        console.log('Зарегистрирован новый пользователь (всего: '
          + db.prepare('SELECT COUNT(*) AS n FROM users').get().n + ')');
        return json(res, 200, { token, user, baks });
      }

      const row = db.prepare('SELECT id, email, pass_salt, pass_hash FROM users WHERE email = ?').get(email);
      if (!row || !checkPassword(password, row.pass_salt, row.pass_hash)) {
        noteTry(ip);
        return json(res, 401, { error: 'Почта или пароль не подошли' });
      }
      const token = tokenOf();
      const now = new Date().toISOString();
      db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
        .run(tokenKey(token), row.id, now, now);
        const stRow = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(row.id, 'app');
        let baksNow = 0;
        if (stRow) { try { baksNow = Math.max(0, Math.floor(Number(JSON.parse(stRow.value).baks || 0))); } catch (e) { baksNow = 0; } }
        return json(res, 200, { token, user: { id: row.id, email: row.email }, baks: baksNow });
    }

    if (route === '/api/me' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const n = db.prepare('SELECT COUNT(*) AS n FROM state WHERE user_id = ?').get(me.id).n;
      const st = db.prepare('SELECT value FROM state WHERE user_id = ? AND key = ?').get(me.id, 'app');
      let baks = 0;
      if (st) { try { baks = Math.max(0, Math.floor(Number(JSON.parse(st.value).baks || 0))); } catch (e) { baks = 0; } }
      return json(res, 200, { user: me, keys: n, baks: baks });
    }

    if (route === '/api/logout' && method === 'POST') {
      const raw = String(req.headers.authorization || '');
      const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(raw);
      if (m) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenKey(m[1]));
      return json(res, 200, { ok: true });
    }

    if (route === '/api/state') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });

      if (method === 'GET') {
        const rows = db.prepare('SELECT key, value, updated_at FROM state WHERE user_id = ?').all(me.id);
        const out = {};
        for (const r of rows) {
          try { out[r.key] = JSON.parse(r.value); } catch (e) { out[r.key] = null; }
        }
        return json(res, 200, { state: out, keys: rows.length });
      }

      if (method === 'PUT' || method === 'POST') {
        let body;
        try { body = await readBody(req); }
        catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
        const key = String(body.key || '').trim();
        if (!key || key.length > 64) return json(res, 400, { error: 'Недопустимое имя ключа' });
        const value = JSON.stringify(body.value === undefined ? null : body.value);
        if (value.length > MAX_VALUE) return json(res, 413, { error: 'Слишком большое значение' });
        db.prepare(`INSERT INTO state (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
          ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
          .run(me.id, key, value, new Date().toISOString());
        return json(res, 200, { ok: true, key });
      }
      return json(res, 405, { error: 'Метод не поддерживается' });
    }

    /* ---------- Оплата (срез 31, тестовый режим) ----------
       Приложение просит «купить пакет». Пока провайдер не подключён, работаем в тестовом режиме:
       платёж сразу считается оплаченным, а Баксы зачисляются в состояние человека.
       Когда владелец подключит ЮKassa: здесь будет возврат ссылки на оплату, а зачисление -
       по вебхуку от провайдера (после подтверждения оплаты). */
    if (route === '/api/pay/create' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const price = Math.floor(Number(body.price || 0));
      const baks = Math.floor(Number(body.baks || 0));
      if (!(price >= 0 && price <= 100000) || !(baks > 0 && baks <= 1000000000)) {
        return json(res, 400, { error: 'Недопустимый пакет' });
      }
      const now = new Date().toISOString();
      const provider = YK_ON ? 'yookassa' : (RB_ON ? 'robokassa' : 'test');
      const info = db.prepare(`INSERT INTO payments (user_id, created_at, pack, price_rub, baks, status, provider)
        VALUES (?, ?, ?, ?, ?, ?, ?)`)
        .run(me.id, now, String(body.pack || '').slice(0, 40), price, baks, (YK_ON || RB_ON) ? 'created' : 'paid', provider);
      const payId = Number(info.lastInsertRowid);
      if (YK_ON) {
        /* боевой режим ЮKassa: создаём платёж и отдаём ссылку на оплату; зачисление - по вебхуку */
        if (price < 1) {
          db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('error', payId);
          return json(res, 400, { error: 'Сумма платежа слишком мала' });
        }
        try {
          const packName = String(body.pack || '');
          const descr = ('Пакет Баксов «' + packName + '»').slice(0, 128);
          const out = await ykRequest('POST', '/v3/payments', {
            amount: { value: price.toFixed(2), currency: 'RUB' },
            capture: true,
            confirmation: { type: 'redirect', return_url: YK_RETURN_URL },
            description: descr,
            /* Чек для 54-ФЗ: самозанятым (НПД) ЮKassa требует чек с почтой покупателя.
               НДС нет (vat_code 1), предмет расчёта - услуга, оплата полная. */
            receipt: {
              customer: { email: me.email },
              items: [{
                description: descr,
                quantity: '1.00',
                amount: { value: price.toFixed(2), currency: 'RUB' },
                vat_code: 1,
                payment_subject: 'service',
                payment_mode: 'full_payment',
              }],
            },
            metadata: { payId: String(payId), userId: String(me.id) },
          }, 'iimaster-' + payId);
          const url = out.data && out.data.confirmation && out.data.confirmation.confirmation_url;
          if (!out.ok || !url) {
            db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('error', payId);
            const why = (out.data && (out.data.description || out.data.code)) || ('http ' + out.status);
            return json(res, 502, { error: 'Не удалось создать платёж: ' + String(why).slice(0, 180) });
          }
          return json(res, 200, { ok: true, paid: false, id: payId, payUrl: url, provider: 'yookassa' });
        } catch (e) {
          db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('error', payId);
          return json(res, 502, { error: 'Не удалось создать платёж: ' + String((e && e.message) || '').slice(0, 160) });
        }
      }
      if (RB_ON) {
        /* боевой режим: отдаём ссылку на оплату Робокассы; зачисление будет по ResultURL */
        const outSum = String(price);
        const sig = md5hex(RB_LOGIN + ':' + outSum + ':' + payId + ':' + RB_PASS1);
        const desc = encodeURIComponent('Пакет Баксов «' + String(body.pack || '') + '»');
        const payUrl = 'https://auth.robokassa.ru/Merchant/Index.aspx'
          + '?MerchantLogin=' + encodeURIComponent(RB_LOGIN)
          + '&OutSum=' + outSum + '&InvId=' + payId + '&Description=' + desc
          + '&SignatureValue=' + sig + '&Culture=ru';
        return json(res, 200, { ok: true, paid: false, id: payId, payUrl: payUrl, provider: 'robokassa' });
      }
      const baksNow = grantPurchase(me.id, baks, now);
      return json(res, 200, { ok: true, paid: true, id: payId,
        credited: baks, baks: baksNow, provider: 'test' });
    }
    /* ResultURL Робокассы: провайдер подтверждает оплату - зачисляем Баксы человеку.
       Подпись проверяется по паролю №2 (md5(OutSum:InvId:Pass2)). Ответ должен быть "OK<InvId>". */
    if (route === '/api/pay/robokassa/result' && method === 'POST') {
      const text = (res) => { res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }); return res.end(text); };
      let body;
      try { body = await readBody(req); } catch (e) { return text('bad'); }
      const q = new URLSearchParams(body.toString('utf8'));
      const outSum = q.get('OutSum') || '', invId = q.get('InvId') || '';
      const sig = String(q.get('SignatureValue') || '').toLowerCase();
      if (!RB_ON || !invId || sig !== md5hex(outSum + ':' + invId + ':' + RB_PASS2)) return text('bad sign');
      const pay = db.prepare('SELECT * FROM payments WHERE id = ?').get(Number(invId));
      if (pay && pay.status !== 'paid') {
        db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('paid', pay.id);
        grantPurchase(pay.user_id, pay.baks, new Date().toISOString());
      }
      return text('OK' + invId);
    }
    /* Вебхук ЮKassa: провайдер сообщает об оплате - зачисляем Баксы человеку.
       ЮKassa не подписывает уведомления, поэтому НЕ доверяем телу на слово: перезапрашиваем
       платёж по его id у API и убеждаемся, что статус "succeeded" и наш payId совпадает. */
    if (route === '/api/pay/yookassa/result' && method === 'POST') {
      if (!YK_ON) return json(res, 403, { error: 'Провайдер не подключён' });
      let body;
      try { body = await readBody(req); } catch (e) { return json(res, 400, { error: 'Плохой запрос' }); }
      const note = (body && typeof body === 'object') ? body : {};
      const obj = (note.object && typeof note.object === 'object') ? note.object : {};
      if (String(note.event || '') !== 'payment.succeeded') return json(res, 200, { ok: true });
      const ykId = String(obj.id || '');
      const payId = Number(obj.metadata && obj.metadata.payId);
      if (!ykId || !Number.isFinite(payId)) return json(res, 400, { error: 'Нет данных платежа' });
      let check = null;
      try { check = await ykRequest('GET', '/v3/payments/' + encodeURIComponent(ykId)); }
      catch (e) { return json(res, 502, { error: 'Проверка недоступна' }); }
      const verified = check.ok && check.data && check.data.status === 'succeeded'
        && Number(check.data.metadata && check.data.metadata.payId) === payId;
      if (!verified) return json(res, 400, { error: 'Проверка не пройдена' });
      const pay = db.prepare('SELECT * FROM payments WHERE id = ?').get(payId);
      if (!pay) return json(res, 400, { error: 'Платёж не найден' });
      if (pay.status !== 'paid') {
        db.prepare('UPDATE payments SET status = ? WHERE id = ?').run('paid', pay.id);
        grantPurchase(pay.user_id, pay.baks, new Date().toISOString());
      }
      return json(res, 200, { ok: true });
    }
    if (route === '/api/pay/list' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const list = db.prepare(`SELECT id, created_at, pack, price_rub, baks, status, provider
        FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 20`).all(me.id);
      return json(res, 200, { payments: list });
    }

    /* Учёт и лимит трат. Приложение сообщает о каждом расходе; сервер считает его за день и
       отказывает, когда лимит исчерпан. Это защита денег владельца: даже если у человека
       «сломается» приложение, сервер не даст сжечь больше положенного. */
    if (route === '/api/spend' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const baks = Math.floor(Number(body.baks || 0));
      if (!Number.isFinite(baks) || baks < 0 || baks > 100000000) {
        return json(res, 400, { error: 'Недопустимая сумма расхода' });
      }
      const spent = spentTodayBaks(me.id);
      if (LIMIT_BAKS > 0 && spent + baks > LIMIT_BAKS) {
        return json(res, 429, {
          error: 'Дневной лимит расходов исчерпан',
          limitRub: LIMIT_RUB,
          spentBaks: spent,
          remainingBaks: Math.max(0, LIMIT_BAKS - spent),
        });
      }
      db.prepare('INSERT INTO spend (user_id, day, at, baks, kind) VALUES (?, ?, ?, ?, ?)')
        .run(me.id, todayKey(), new Date().toISOString(), baks, String(body.kind || '').slice(0, 40));
      /* Общий баланс: списание идёт и по счёту аккаунта (state.app.baks) - один баланс на телефон, ПК и облако */
      const left = creditBaks(me.id, -baks, new Date().toISOString());
      const after = spent + baks;
      return json(res, 200, {
        ok: true,
        baks: left,
        limitRub: LIMIT_RUB,
        spentBaks: after,
        remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - after) : -1,
      });
    }

    if (route === '/api/usage' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const spent = spentTodayBaks(me.id);
      const events = db.prepare('SELECT at, baks, kind FROM spend WHERE user_id = ? ORDER BY id DESC LIMIT 20')
        .all(me.id);
      return json(res, 200, {
        limitRub: LIMIT_RUB,
        spentBaks: spent,
        remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - spent) : -1,
        today: todayKey(),
        events,
      });
    }

    /* Резервные копии: только по ключу. Сам файл копии - это база с аккаунтами, наружу без защиты
       его отдавать нельзя, поэтому без ключа отвечаем «нет». */
    if (route === '/api/backup/now' && method === 'POST') {
      const key = String(req.headers['x-backup-key'] || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const name = makeBackup('по запросу владельца');
      return json(res, name ? 200 : 500, { ok: !!name, file: name });
    }

    if (route === '/api/backup/list' && method === 'GET') {
      const key = String(url.searchParams.get('key') || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      return json(res, 200, { count: files.length, keep: BACKUP_KEEP, files });
    }

    if (route === '/api/backup/latest' && method === 'GET') {
      const key = String(url.searchParams.get('key') || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      if (!files.length) return json(res, 404, { error: 'Копий пока нет' });
      const name = files[files.length - 1];
      const data = fs.readFileSync(path.join(BACKUP_DIR, name));
      res.writeHead(200, {
        'content-type': 'application/octet-stream',
        'content-disposition': 'attachment; filename="' + name + '"',
        'content-length': data.length,
        'cache-control': 'no-store',
      });
      return res.end(data);
    }

    /* Скачать копию, войдя под своим аккаунтом. Нужно для файла-кнопки на компьютере владельца:
       так не требуется ни ключ, ни консоль - только почта и пароль, которые человек и так знает. */
    if (route === '/api/backup/with-account' && method === 'POST') {
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      const row = db.prepare('SELECT id, pass_salt, pass_hash FROM users WHERE email = ?').get(email);
      if (!row || !checkPassword(password, row.pass_salt, row.pass_hash)) {
        noteTry(ip);
        return json(res, 401, { error: 'Почта или пароль не подошли' });
      }
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      if (!files.length) return json(res, 404, { error: 'Копий пока нет' });
      const name = files[files.length - 1];
      const data = fs.readFileSync(path.join(BACKUP_DIR, name));
      res.writeHead(200, {
        'content-type': 'application/octet-stream',
        'content-disposition': 'attachment; filename="' + name + '"',
        'content-length': data.length,
        'cache-control': 'no-store',
      });
      return res.end(data);
    }

    /* /proxy/<путь> → <X-Api-Base>/<путь>, только для разрешённых адресов сервисов */
    if (route.startsWith('/proxy/')) {
      const base = String(req.headers['x-api-base'] || '').replace(/\/+$/, '');
      if (!base || !ALLOW.some((re) => re.test(base + '/'))) {
        return json(res, 403, { error: 'Адрес не разрешён для прокси: ' + base });
      }
      return proxyRequest(req, res, base + route.slice('/proxy'.length));
    }

    /* Сохранение файлов на диск - это возможность настольной версии, в облаке её нет.
       Отвечаем понятным текстом, чтобы приложение показало человеку причину, а не «сломалось». */
    if (route.startsWith('/tools/')) {
      return json(res, 501, {
        error: 'В облачной версии файлы на диск не сохраняются. Скачайте результат из чата '
          + 'или пользуйтесь приложением на компьютере.',
      });
    }

    if (method === 'GET') return serveStatic(res, route, req.headers.host);

    json(res, 404, { error: 'Не найдено' });
  } catch (e) {
    console.log('Ошибка обработки запроса: ' + (e && e.message ? e.message : e));
    if (!res.headersSent) json(res, 500, { error: 'Внутренняя ошибка' });
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log('Облачный сервер «ИИ Мастер»: http://127.0.0.1:' + PORT + '/');
  console.log('Данные: ' + DATA_DIR);
  console.log('Резервные копии: ' + BACKUP_DIR + ' (храним последние ' + BACKUP_KEEP + ')');
  console.log('Ключ для скачивания копий: ' + BACKUP_KEY + '  (и в файле ' + KEY_FILE + ')');
  console.log('Лимит трат: ' + (LIMIT_RUB > 0 ? LIMIT_RUB + ' руб/день на человека' : 'без ограничения')
    + ' (менять: echo 300 > ' + path.join(path.dirname(DATA_DIR), 'limit.txt') + ')');
  setTimeout(backupTick, 5000);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
