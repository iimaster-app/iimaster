'use strict';

/**
 * Service worker «МАСТЕРСКОЙ ИИ» (PWA, срез 8).
 * Задача: приложение открывается даже без интернета — оболочка (страница, значки, шрифты)
 * лежит в кэше, а данные пользователя и так хранятся на устройстве (localStorage).
 *
 * ВАЖНО: запросы к моделям (/proxy/...) и сохранение файлов (/tools/...) НИКОГДА не кэшируем —
 * иначе в кэш могли бы попасть ответы с ключом и устаревшие данные.
 */

/* Имя кэша меняем при каждом изменении оболочки: при смене имени старый кэш удаляется
   в activate. ГРАБЛЯ 13.10.2026: имя не менялось, и в установленном приложении остался
   старый src/xlsx.js (без функции zip) — .docx молча не собирался, приложение отдавало HTML. */
const CACHE = 'masterskaya-ai-v3';
/* Код (страница, сборщики, манифест) НИКОГДА не берём из кэша первым: иначе после обновления
   приложение продолжает работать на старых файлах. Только сеть, а кэш — запасной путь без интернета. */
const КОД = /(?:\.html|\.js|\.webmanifest)$/i;
const SHELL = [
  '/',
  '/src/index.html',
  '/src/xlsx.js',
  '/src/xlsxread.js',
  '/src/pptx.js',
  '/manifest.webmanifest',
  '/assets/icons/pwa-icon.png',
  '/assets/icons/robot-avatar.png',
  '/assets/icons/dollar.png',
  '/assets/icons/bell.png',
  '/assets/icons/user.png',
  '/assets/icons/clip.png',
  '/assets/icons/m-music.png',
  '/assets/icons/m-voice.png',
  '/assets/icons/m-safe.png',
  '/assets/icons/mic.png',
  /* шрифты из «Настройки → Приложение → Шрифт» (кириллица + латиница, 400/700) */
  '/assets/fonts/roboto-cyrillic-400-normal.woff2',
  '/assets/fonts/roboto-cyrillic-700-normal.woff2',
  '/assets/fonts/roboto-latin-400-normal.woff2',
  '/assets/fonts/roboto-latin-700-normal.woff2',
  '/assets/fonts/montserrat-cyrillic-400-normal.woff2',
  '/assets/fonts/montserrat-cyrillic-700-normal.woff2',
  '/assets/fonts/montserrat-latin-400-normal.woff2',
  '/assets/fonts/montserrat-latin-700-normal.woff2',
  '/assets/fonts/pt-sans-cyrillic-400-normal.woff2',
  '/assets/fonts/pt-sans-cyrillic-700-normal.woff2',
  '/assets/fonts/pt-sans-latin-400-normal.woff2',
  '/assets/fonts/pt-sans-latin-700-normal.woff2',
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    /* складываем оболочку по одному файлу: если чего-то нет, установка не сломается */
    await Promise.all(SHELL.map((url) => cache.add(url).catch(() => {})));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  /* чужие адреса и «живые» запросы — только сеть, без кэша */
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/proxy/') || url.pathname.startsWith('/tools/')) return;
  if (req.method !== 'GET') return;

  /* открытие приложения: сначала сеть, при её отсутствии — кэш */
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        const cache = await caches.open(CACHE);
        cache.put('/src/index.html', fresh.clone());
        return fresh;
      } catch (e) {
        const cache = await caches.open(CACHE);
        return (await cache.match('/src/index.html')) || (await cache.match('/'))
          || new Response('Нет связи. Откройте приложение, когда появится интернет.', { status: 503 });
      }
    })());
    return;
  }

  /* статика: код — сначала сеть (чтобы обновление доходило), значки и шрифты — сначала кэш */
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const изКода = КОД.test(url.pathname) || url.pathname === '/';
    if (изКода) {
      try {
        const fresh = await fetch(req);
        if (fresh && fresh.status === 200 && fresh.type === 'basic') cache.put(req, fresh.clone());
        return fresh;
      } catch (e) {
        return (await cache.match(req)) || Response.error();
      }
    }
    const hit = await cache.match(req);
    if (hit) return hit;
    try {
      const fresh = await fetch(req);
      if (fresh && fresh.status === 200 && fresh.type === 'basic') cache.put(req, fresh.clone());
      return fresh;
    } catch (e) {
      return hit || Response.error();
    }
  })());
});
