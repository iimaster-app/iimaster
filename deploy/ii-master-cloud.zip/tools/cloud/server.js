'use strict';

/**
 * Облачный сервер «ИИ Мастер» — пилот, срез 27 (01.10.2026).
 *
 * Задача среза: приложение должно открываться с любого телефона, а данные (диалоги, агенты,
 * настройки, Баксы) жить на сервере, а не в браузере. Это первый шаг: сервер + база + аккаунты.
 * Экран входа в самом приложении — следующий шаг (срез 28).
 *
 * Решения:
 *  - База — встроенная в Node `node:sqlite` (ничего не компилируется, на сервере не нужны библиотеки).
 *  - Пароли — только в виде хэша scrypt со своей солью (`node:crypto`), открытый пароль не хранится.
 *  - Токены сессии — случайные 32 байта; в базе лежит только их SHA-256 (утечка базы не даёт войти).
 *  - SQL — только параметризованный (никаких склеек строк).
 *  - Данные строго разделены по пользователю: любой запрос к состоянию идёт через его user_id.
 *
 * Запуск:  node tools/cloud/server.js          (порт 8790)
 *          CLOUD_PORT=8080 CLOUD_DATA=/opt/ii-master/data node tools/cloud/server.js
 */

const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

/* У api.z.ai есть и IPv4, и IPv6. Если у провайдера IPv6 не работает, запрос уходит в «мёртвую»
   сеть и падает. Ставим приоритет IPv4 — как в локальном сервере (tools/serve.js). */
try { dns.setDefaultResultOrder('ipv4first'); } catch (e) { /* старая версия Node */ }

const ROOT = path.resolve(__dirname, '..', '..');
const DATA_DIR = process.env.CLOUD_DATA ? path.resolve(process.env.CLOUD_DATA) : path.join(ROOT, 'data');
const PORT = Number(process.env.CLOUD_PORT || 8790);
const MAX_BODY = 1024 * 1024;          /* 1 МБ на запрос — состояние, а не файлы */
const MAX_VALUE = 200 * 1024;          /* 200 КБ на одно значение состояния */
const MIN_PASS = 8;

/* Лимит трат на человека в день, в рублях. Баксы считаем по курсу приложения.
   Владелец меняет переменной CLOUD_LIMIT_RUB при запуске службы; 0 — без ограничения. */
/* Лимит трат в рублях на человека в день. Берём из простого файла limit.txt (там только число)
   или из переменной. Владелец меняет короткой командой БЕЗ подчёркиваний:
   echo 300 > /opt/ii-master/limit.txt   (потом systemctl restart ii-master) */
const LIMIT_RUB = (function () {
  if (process.env.CLOUD_LIMIT_RUB) return Number(process.env.CLOUD_LIMIT_RUB);
  try {
    const n = Number(fs.readFileSync(path.join(path.dirname(DATA_DIR), 'limit.txt'), 'utf8').trim());
    if (Number.isFinite(n) && n >= 0) return n;
  } catch (e) { /* файла нет — значение по умолчанию */ }
  return 100;
})();
const BAKS_PER_RUB = 11666.67;
const LIMIT_BAKS = LIMIT_RUB > 0 ? Math.floor(LIMIT_RUB * BAKS_PER_RUB) : 0;
function todayKey() { return new Date().toISOString().slice(0, 10); }
function spentTodayBaks(userId) {
  return db.prepare('SELECT COALESCE(SUM(baks), 0) AS s FROM spend WHERE user_id = ? AND day = ?')
    .get(userId, todayKey()).s;
}

/* ---------- резервные копии (срез 32) ----------
   Правило владельца: три копии на трёх разных носителях (оригинал на сервере + внешний диск +
   флэшка). Здесь делается первая часть: сервер сам раз в сутки снимает копию базы и хранит
   последние N. Копия снимается командой VACUUM INTO — это безопасно даже во время работы
   (обычное копирование файла может поймать базу «на полуслове»).
   Забрать копию на компьютер владельца можно по ключу: /api/backup/latest?key=… */
const BACKUP_DIR = process.env.CLOUD_BACKUP_DIR || path.join(path.dirname(DATA_DIR), 'backups');
const BACKUP_KEEP = Number(process.env.CLOUD_BACKUP_KEEP || 14);
const KEY_FILE = path.join(path.dirname(DATA_DIR), 'key.txt');
/* Ключ для скачивания копий. Владельцу НЕ нужно ничего придумывать и вводить команды с
   подчёркиваниями: сервер сам создаёт ключ при первом запуске и кладёт его в файл key.txt.
   Прочитать: cat /opt/ii-master/key.txt */
const BACKUP_KEY = (function () {
  const fromEnv = String(process.env.CLOUD_BACKUP_KEY || '');
  if (fromEnv) return fromEnv;
  try {
    const saved = fs.readFileSync(KEY_FILE, 'utf8').trim();
    if (saved) return saved;
  } catch (e) { /* файла ещё нет */ }
  const fresh = crypto.randomBytes(12).toString('hex');
  try { fs.writeFileSync(KEY_FILE, fresh, 'utf8'); } catch (e) { /* не смогли сохранить — покажем в консоли */ }
  return fresh;
})();
fs.mkdirSync(BACKUP_DIR, { recursive: true });

function makeBackup(reason) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(BACKUP_DIR, 'cloud-' + stamp + '.db');
  try {
    db.exec("VACUUM INTO '" + file.replace(/'/g, "''") + "'");
    const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
    for (const old of files.slice(0, Math.max(0, files.length - BACKUP_KEEP))) {
      try { fs.unlinkSync(path.join(BACKUP_DIR, old)); } catch (e) { /* не критично */ }
    }
    console.log('[резерв] копия готова: ' + path.basename(file) + ' (' + reason + ')');
    return path.basename(file);
  } catch (e) {
    console.log('[резерв] НЕ удалось сделать копию: ' + (e && e.message ? e.message : e));
    return null;
  }
}

/* Проверяем раз в час: если за сегодня копии ещё нет — делаем. Так копия появится даже после
   перезагрузки сервера, и не нужен внешний планировщик. */
function backupTick() {
  try {
    const day = todayKey();
    const has = fs.readdirSync(BACKUP_DIR).some((f) => f.indexOf(day) !== -1);
    if (!has) makeBackup('по расписанию');
  } catch (e) { /* каталог недоступен — уже сообщили при создании копии */ }
}
setInterval(backupTick, 3600000);

fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'cloud.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');
db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  pass_salt TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  last_seen TEXT NOT NULL
)`);
db.exec(`CREATE TABLE IF NOT EXISTS state (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, key)
)`);
/* Учёт расходов: одна строка на каждую трату человека. Нужен, чтобы лимит считался на сервере,
   а не «на глазок» в браузере (срез 29). */
db.exec(`CREATE TABLE IF NOT EXISTS spend (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  at TEXT NOT NULL,
  baks INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT ''
)`);

/* ---------- пароли и токены ---------- */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function checkPassword(password, salt, hash) {
  const calc = crypto.scryptSync(String(password), String(salt), 64);
  const saved = Buffer.from(String(hash), 'hex');
  return calc.length === saved.length && crypto.timingSafeEqual(calc, saved);
}
function tokenOf() { return crypto.randomBytes(32).toString('hex'); }
function tokenKey(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[a-zа-яё]{2,}$/i;

/* ---------- простые помощники ---------- */
function json(res, code, obj) {
  const body = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('too_large')); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => {
      try { resolve(parts.length ? JSON.parse(Buffer.concat(parts).toString('utf8')) : {}); }
      catch (e) { reject(new Error('bad_json')); }
    });
    req.on('error', reject);
  });
}
/* Кто это. Токен приходит в заголовке Authorization: Bearer <токен> */
function userOf(req) {
  const raw = String(req.headers.authorization || '');
  const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(raw);
  if (!m) return null;
  const row = db.prepare(
    'SELECT s.user_id AS id, u.email AS email, s.token_hash AS th FROM sessions s'
    + ' JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?'
  ).get(tokenKey(m[1]));
  if (!row) return null;
  db.prepare('UPDATE sessions SET last_seen = ? WHERE token_hash = ?')
    .run(new Date().toISOString(), row.th);
  return { id: row.id, email: row.email };
}

/* Ограничение попыток входа: не больше 20 неудач с одного адреса за 10 минут */
const tries = new Map();
function tooManyTries(ip) {
  const now = Date.now();
  const rec = tries.get(ip);
  if (!rec || now > rec.until) { tries.set(ip, { n: 0, until: now + 600000 }); return false; }
  return rec.n >= 20;
}
function noteTry(ip) {
  const rec = tries.get(ip) || { n: 0, until: Date.now() + 600000 };
  rec.n += 1;
  tries.set(ip, rec);
}

/* ---------- отдача приложения и прокси к моделям ----------
   Точно так же, как локальный tools/serve.js: браузер не может звать z.ai напрямую (CORS),
   поэтому приложение просит /proxy/<путь>, а сервер пересылает запрос выбранному сервису.
   Ключ сервиса остаётся у пользователя в настройках и уходит только выбранному сервису. */
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
};
const ALLOW = [
  /^https:\/\/api\.z\.ai\//,
  /^https:\/\/agenthere\.ru\//,
  /^https:\/\/llm\.api\.cloud\.yandex\.net\//,
  /^https:\/\/tts\.api\.cloud\.yandex\.net\//,
  /^https:\/\/api\.telegram\.org\//,
  /^https:\/\/openrouter\.ai\//,
];
/* Признак для приложения: страницу отдал облачный сервер. Приложение по нему понимает, что
   нужно просить вход и хранить данные на сервере (см. блок «Облачный режим» в src/index.html). */
const CLOUD_FLAG = '<script>window.__cloudServer=true;</script>';
const IDLE_MS = 90000;
const MAX_BODY_UP = 4 * 1024 * 1024;

function upstream(u, req, res, body) {
  const mod = u.protocol === 'https:' ? https : http;
  const headers = Object.assign({}, req.headers);
  delete headers.host;
  delete headers['content-length'];
  delete headers['x-api-base'];
  if (body.length) headers['content-length'] = Buffer.byteLength(body);

  const p = mod.request({
    hostname: u.hostname,
    port: u.port || (u.protocol === 'https:' ? 443 : 80),
    path: u.pathname + u.search,
    method: req.method,
    headers,
  }, (up) => {
    const out = Object.assign({}, up.headers);
    delete out['transfer-encoding'];
    delete out.connection;
    res.writeHead(up.statusCode || 502, out);
    up.pipe(res);
  });
  p.on('socket', (s) => {
    s.setTimeout(IDLE_MS, () => p.destroy(Object.assign(new Error('таймаут связи'), { code: 'TIMEOUT' })));
  });
  p.on('error', (e) => {
    if (res.headersSent) { res.end(); return; }
    const code = (e && e.code) || '';
    console.log('[прокси] ошибка обращения к ' + u.hostname + ': ' + code);
    json(res, 502, {
      error: code === 'ENOTFOUND'
        ? 'Нет связи с сервисом: не удалось определить его адрес. Проверьте интернет на сервере.'
        : 'Не удалось связаться с сервисом: ' + (e && e.message ? e.message : e),
      code: code || 'unknown',
    });
  });
  p.end(body);
}

function proxyRequest(req, res, target) {
  let u;
  try { u = new URL(target); } catch (e) { json(res, 400, { error: 'Плохой адрес' }); return; }
  readRawBody(req).then((body) => upstream(u, req, res, body)).catch(() => {
    if (res.headersSent) { res.end(); return; }
    json(res, 413, { error: 'Запрос слишком большой' });
  });
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const parts = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY_UP) { reject(new Error('too_large')); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}

function serveStatic(res, urlPath) {
  let file = urlPath;
  if (file === '/' || file === '') file = '/src/index.html';
  if (file === '/manifest.webmanifest') file = '/src/manifest.webmanifest';
  if (file === '/sw.js') file = '/src/sw.js';
  const full = path.normalize(path.join(ROOT, file));
  if (!full.startsWith(ROOT)) { res.writeHead(403); res.end('Запрещено'); return; }
  fs.readFile(full, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Не найдено: ' + file);
      return;
    }
    const headers = { 'Content-Type': TYPES[path.extname(full).toLowerCase()] || 'application/octet-stream' };
    if (file === '/src/sw.js') headers['Service-Worker-Allowed'] = '/';
    if (/\.(html|webmanifest)$/i.test(file) || file === '/src/sw.js') {
      headers['Cache-Control'] = 'no-store, no-cache, must-revalidate';
    }
    if (file === '/src/index.html') {
      const html = data.toString('utf8').replace('<head>', '<head>' + CLOUD_FLAG);
      res.writeHead(200, headers);
      res.end(html);
      return;
    }
    res.writeHead(200, headers);
    res.end(data);
  });
}

/* ---------- маршруты ---------- */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const route = url.pathname;
  const method = req.method || 'GET';
  const ip = (req.socket && req.socket.remoteAddress) || 'local';

  try {
    if (method === 'GET' && route === '/api/health') {
      const users = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
      return json(res, 200, { ok: true, users, version: '0.1', data: DATA_DIR });
    }

    if (method === 'POST' && (route === '/api/register' || route === '/api/login')) {
      if (tooManyTries(ip)) return json(res, 429, { error: 'Слишком много попыток. Попробуйте позже.' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      if (!EMAIL_RE.test(email)) return json(res, 400, { error: 'Проверьте адрес почты' });
      if (password.length < MIN_PASS) {
        return json(res, 400, { error: 'Пароль должен быть не короче ' + MIN_PASS + ' знаков' });
      }

      if (route === '/api/register') {
        if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
          return json(res, 409, { error: 'Такая почта уже зарегистрирована' });
        }
        const { salt, hash } = hashPassword(password);
        const now = new Date().toISOString();
        db.prepare('INSERT INTO users (email, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?)')
          .run(email, salt, hash, now);
        const user = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
        const token = tokenOf();
        db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
          .run(tokenKey(token), user.id, now, now);
        console.log('Зарегистрирован новый пользователь (всего: '
          + db.prepare('SELECT COUNT(*) AS n FROM users').get().n + ')');
        return json(res, 200, { token, user });
      }

      const row = db.prepare('SELECT id, email, pass_salt, pass_hash FROM users WHERE email = ?').get(email);
      if (!row || !checkPassword(password, row.pass_salt, row.pass_hash)) {
        noteTry(ip);
        return json(res, 401, { error: 'Почта или пароль не подошли' });
      }
      const token = tokenOf();
      const now = new Date().toISOString();
      db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)')
        .run(tokenKey(token), row.id, now, now);
      return json(res, 200, { token, user: { id: row.id, email: row.email } });
    }

    if (route === '/api/me' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const n = db.prepare('SELECT COUNT(*) AS n FROM state WHERE user_id = ?').get(me.id).n;
      return json(res, 200, { user: me, keys: n });
    }

    if (route === '/api/logout' && method === 'POST') {
      const raw = String(req.headers.authorization || '');
      const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(raw);
      if (m) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenKey(m[1]));
      return json(res, 200, { ok: true });
    }

    if (route === '/api/state') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });

      if (method === 'GET') {
        const rows = db.prepare('SELECT key, value, updated_at FROM state WHERE user_id = ?').all(me.id);
        const out = {};
        for (const r of rows) {
          try { out[r.key] = JSON.parse(r.value); } catch (e) { out[r.key] = null; }
        }
        return json(res, 200, { state: out, keys: rows.length });
      }

      if (method === 'PUT' || method === 'POST') {
        let body;
        try { body = await readBody(req); }
        catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
        const key = String(body.key || '').trim();
        if (!key || key.length > 64) return json(res, 400, { error: 'Недопустимое имя ключа' });
        const value = JSON.stringify(body.value === undefined ? null : body.value);
        if (value.length > MAX_VALUE) return json(res, 413, { error: 'Слишком большое значение' });
        db.prepare(`INSERT INTO state (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
          ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`)
          .run(me.id, key, value, new Date().toISOString());
        return json(res, 200, { ok: true, key });
      }
      return json(res, 405, { error: 'Метод не поддерживается' });
    }

    /* Учёт и лимит трат. Приложение сообщает о каждом расходе; сервер считает его за день и
       отказывает, когда лимит исчерпан. Это защита денег владельца: даже если у человека
       «сломается» приложение, сервер не даст сжечь больше положенного. */
    if (route === '/api/spend' && method === 'POST') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      let body;
      try { body = await readBody(req); }
      catch (e) { return json(res, 400, { error: 'Не удалось прочитать запрос' }); }
      const baks = Math.floor(Number(body.baks || 0));
      if (!Number.isFinite(baks) || baks < 0 || baks > 100000000) {
        return json(res, 400, { error: 'Недопустимая сумма расхода' });
      }
      const spent = spentTodayBaks(me.id);
      if (LIMIT_BAKS > 0 && spent + baks > LIMIT_BAKS) {
        return json(res, 429, {
          error: 'Дневной лимит расходов исчерпан',
          limitRub: LIMIT_RUB,
          spentBaks: spent,
          remainingBaks: Math.max(0, LIMIT_BAKS - spent),
        });
      }
      db.prepare('INSERT INTO spend (user_id, day, at, baks, kind) VALUES (?, ?, ?, ?, ?)')
        .run(me.id, todayKey(), new Date().toISOString(), baks, String(body.kind || '').slice(0, 40));
      const after = spent + baks;
      return json(res, 200, {
        ok: true,
        limitRub: LIMIT_RUB,
        spentBaks: after,
        remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - after) : -1,
      });
    }

    if (route === '/api/usage' && method === 'GET') {
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Нужно войти' });
      const spent = spentTodayBaks(me.id);
      const events = db.prepare('SELECT at, baks, kind FROM spend WHERE user_id = ? ORDER BY id DESC LIMIT 20')
        .all(me.id);
      return json(res, 200, {
        limitRub: LIMIT_RUB,
        spentBaks: spent,
        remainingBaks: LIMIT_BAKS ? Math.max(0, LIMIT_BAKS - spent) : -1,
        today: todayKey(),
        events,
      });
    }

    /* Резервные копии: только по ключу. Сам файл копии — это база с аккаунтами, наружу без защиты
       его отдавать нельзя, поэтому без ключа отвечаем «нет». */
    if (route === '/api/backup/now' && method === 'POST') {
      const key = String(req.headers['x-backup-key'] || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const name = makeBackup('по запросу владельца');
      return json(res, name ? 200 : 500, { ok: !!name, file: name });
    }

    if (route === '/api/backup/list' && method === 'GET') {
      const key = String(url.searchParams.get('key') || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      return json(res, 200, { count: files.length, keep: BACKUP_KEEP, files });
    }

    if (route === '/api/backup/latest' && method === 'GET') {
      const key = String(url.searchParams.get('key') || '');
      if (!BACKUP_KEY || key !== BACKUP_KEY) return json(res, 403, { error: 'Неверный ключ резервных копий' });
      const files = fs.readdirSync(BACKUP_DIR).filter((f) => /^cloud-.*\.db$/.test(f)).sort();
      if (!files.length) return json(res, 404, { error: 'Копий пока нет' });
      const name = files[files.length - 1];
      const data = fs.readFileSync(path.join(BACKUP_DIR, name));
      res.writeHead(200, {
        'content-type': 'application/octet-stream',
        'content-disposition': 'attachment; filename="' + name + '"',
        'content-length': data.length,
        'cache-control': 'no-store',
      });
      return res.end(data);
    }

    /* /proxy/<путь> → <X-Api-Base>/<путь>, только для разрешённых адресов сервисов */
    if (route.startsWith('/proxy/')) {
      const base = String(req.headers['x-api-base'] || '').replace(/\/+$/, '');
      if (!base || !ALLOW.some((re) => re.test(base + '/'))) {
        return json(res, 403, { error: 'Адрес не разрешён для прокси: ' + base });
      }
      return proxyRequest(req, res, base + route.slice('/proxy'.length));
    }

    /* Сохранение файлов на диск — это возможность настольной версии, в облаке её нет.
       Отвечаем понятным текстом, чтобы приложение показало человеку причину, а не «сломалось». */
    if (route.startsWith('/tools/')) {
      return json(res, 501, {
        error: 'В облачной версии файлы на диск не сохраняются. Скачайте результат из чата '
          + 'или пользуйтесь приложением на компьютере.',
      });
    }

    if (method === 'GET') return serveStatic(res, route);

    json(res, 404, { error: 'Не найдено' });
  } catch (e) {
    console.log('Ошибка обработки запроса: ' + (e && e.message ? e.message : e));
    if (!res.headersSent) json(res, 500, { error: 'Внутренняя ошибка' });
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log('Облачный сервер «ИИ Мастер»: http://127.0.0.1:' + PORT + '/');
  console.log('Данные: ' + DATA_DIR);
  console.log('Резервные копии: ' + BACKUP_DIR + ' (храним последние ' + BACKUP_KEEP + ')');
  console.log('Ключ для скачивания копий — в файле: ' + KEY_FILE);
  console.log('Лимит трат: ' + (LIMIT_RUB > 0 ? LIMIT_RUB + ' руб/день на человека' : 'без ограничения')
    + ' (менять: echo 300 > ' + path.join(path.dirname(DATA_DIR), 'limit.txt') + ')');
  setTimeout(backupTick, 5000);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
