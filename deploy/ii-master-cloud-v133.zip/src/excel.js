'use strict';

/**
 * Excel Engine (этап 2, 30.10.2026).
 *
 * Задача этапа: открывать НАСТОЯЩИЕ файлы Excel (xlsx, xls, csv, txt) и сохранять их обратно,
 * не теряя листы, формулы, объединённые ячейки и ширину столбцов.
 *
 * Почему так, а не «свой парсер»: разбор OOXML — это ZIP + XML + все тонкости Excel
 * (общие строки, стили, даты, ошибки). Пишем поверх SheetJS (Apache-2.0) — проверенного движка,
 * а не имитации. Свой старый сборщик таблиц (src/xlsx.js, window.XLSX) НЕ трогаем:
 * он умеет только создавать файл по данным, читать чужие не умеет.
 *
 * Что сохраняется при «открыть → сохранить»: имена и порядок листов, значения, формулы (как
 * формулы, а не как числа), объединённые ячейки, ширины столбцов, числовые форматы.
 * Что НЕ сохраняется (ограничение бесплатной версии SheetJS): цвета и шрифты оформления,
 * сводные таблицы, срезы, картинки. Это будет сказано пользователю прямо, без обещаний.
 *
 * API (window.ExcelEngine или module.exports):
 *   open(bytes, fileName)      -> книга
 *   create()                   -> пустая книга с одним листом
 *   sheetNames(book)           -> ['Лист1', …]
 *   getCell(book, sheet, addr) -> { v, f, z }
 *   setCell(book, sheet, addr, value, formula)  -> книга
 *   addSheet(book, name)
 *   renameSheet(book, from, to)
 *   deleteSheet(book, name)
 *   usedRange(book, sheet)     -> 'A1:C10'
 *   toAoa(book, sheet)         -> массив значений (для аналитики, графиков, ИИ)
 *   save(book)                 -> Uint8Array (.xlsx)
 */
(function (root) {
  const SJ = root.SheetJS || root.XLSX;      /* SheetJS подключается раньше, под своим именем */
  if (!SJ || !SJ.read) throw new Error('Excel Engine: не найден SheetJS (vendor/xlsx.full.min.js)');

  const EXT = /\.(xlsx|xlsm|xlsb|xls|csv|txt|tsv)$/i;

  function bookTypeOf(fileName) {
    const m = EXT.exec(String(fileName || ''));
    const e = m ? m[1].toLowerCase() : 'xlsx';
    if (e === 'csv' || e === 'txt' || e === 'tsv') return e === 'tsv' ? 'tsv' : (e === 'txt' ? 'txt' : 'csv');
    return 'xlsx';
  }

  /* Границы листа по фактическим ячейкам.
     Грабля 30.10.2026: у наших же файлов (старый сборщик src/xlsx.js) в <dimension> стоял
     неверный диапазон, и SheetJS при чтении ОБРЕЗАЛ данные до одной строки. Поэтому диапазон
     не берём на веру, а пересчитываем сами — и при открытии, и перед сохранением. */
  function fixRef(ws) {
    let minR = Infinity, minC = Infinity, maxR = -1, maxC = -1;
    for (const k of Object.keys(ws)) {
      if (k.charAt(0) === '!') continue;
      const d = SJ.utils.decode_cell(k);
      if (!d || d.r < 0 || d.c < 0) continue;
      if (d.r < minR) minR = d.r;
      if (d.c < minC) minC = d.c;
      if (d.r > maxR) maxR = d.r;
      if (d.c > maxC) maxC = d.c;
    }
    if (maxR < 0) { ws['!ref'] = 'A1:A1'; return ws; }
    ws['!ref'] = SJ.utils.encode_range({ s: { r: minR, c: minC }, e: { r: maxR, c: maxC } });
    return ws;
  }

  /* Открыть файл: bytes — ArrayBuffer, Uint8Array или File/Blob */
  async function open(bytes, fileName) {
    let data = bytes;
    if (data && typeof data.arrayBuffer === 'function') data = await data.arrayBuffer();   /* File/Blob */
    const name = String(fileName || (bytes && bytes.name) || 'книга.xlsx');
    const t = bookTypeOf(name);
    const readOpts = { type: 'array', cellFormula: true, cellNF: true, cellDates: true, cellText: false };
    let wb;
    if (t === 'csv' || t === 'txt' || t === 'tsv') {
      /* Текст читаем как CSV: разделитель Excel определяет сам, но для txt/tsv задаём явно */
      const text = new TextDecoder('utf-8').decode(new Uint8Array(data));
      wb = SJ.read(text, { type: 'string', raw: false, FS: t === 'tsv' ? '\t' : undefined });
    } else {
      wb = SJ.read(new Uint8Array(data), readOpts);
    }
    if (!wb || !wb.SheetNames || !wb.SheetNames.length) throw new Error('В файле нет ни одного листа');
    wb.SheetNames.forEach((n) => { if (wb.Sheets[n]) fixRef(wb.Sheets[n]); });
    return {
      fileName: name,
      type: t,
      wb: wb,                                  /* рабочая книга SheetJS — источник правды */
      openedAt: new Date().toISOString(),
    };
  }

  function create() {
    const wb = SJ.utils.book_new();
    SJ.utils.book_append_sheet(wb, SJ.utils.aoa_to_sheet([[]]), 'Лист1');
    return { fileName: 'Книга1.xlsx', type: 'xlsx', wb: wb, openedAt: new Date().toISOString() };
  }

  function sheetNames(book) { return (book && book.wb && book.wb.SheetNames) ? book.wb.SheetNames.slice() : []; }

  function sheetOf(book, name) {
    const wb = book && book.wb;
    if (!wb) throw new Error('Книга не открыта');
    const n = name || wb.SheetNames[0];
    const ws = wb.Sheets[n];
    if (!ws) throw new Error('Нет листа «' + n + '»');
    return ws;
  }

  /* Значение и формула одной ячейки. Адрес — как в Excel: A1, B7. */
  function getCell(book, sheet, addr) {
    const ws = sheetOf(book, sheet);
    const c = ws[String(addr).toUpperCase()];
    if (!c) return { v: '', f: '', z: '' };
    return { v: (c.w !== undefined ? c.w : c.v), raw: c.v, f: c.f || '', z: c.z || '', t: c.t || '' };
  }

  /* Записать значение и/или формулу. Формулу передаём БЕЗ ведущего «=». */
  function setCell(book, sheet, addr, value, formula) {
    const ws = sheetOf(book, sheet);
    const a = String(addr).toUpperCase().replace(/\$/g, '');
    if (formula) {
      /* v: 0 - кэшированное значение; Excel пересчитает при открытии (см. fullCalcOnLoad в save) */
      ws[a] = { t: 'n', f: String(formula).replace(/^=/, ''), v: 0 };
    } else if (value === null || value === undefined) {
      delete ws[a];
    } else if (typeof value === 'number' && isFinite(value)) {
      ws[a] = { t: 'n', v: value };
    } else if (typeof value === 'boolean') {
      ws[a] = { t: 'b', v: value };
    } else {
      ws[a] = { t: 's', v: String(value) };
    }
    extendRange(ws, a);
    return book;
  }

  function extendRange(ws, addr) {
    const d = SJ.utils.decode_cell(addr);
    const r = SJ.utils.decode_range(ws['!ref'] || 'A1:A1');
    let changed = false;
    if (d.r > r.e.r) { r.e.r = d.r; changed = true; }
    if (d.c > r.e.c) { r.e.c = d.c; changed = true; }
    if (d.r < r.s.r) { r.s.r = d.r; changed = true; }
    if (d.c < r.s.c) { r.s.c = d.c; changed = true; }
    if (changed) ws['!ref'] = SJ.utils.encode_range(r);
  }

  function addSheet(book, name) {
    const wb = book.wb;
    let n = String(name || 'Лист').trim() || 'Лист';
    let i = 2;
    while (wb.SheetNames.indexOf(n) >= 0) n = String(name) + i++;
    SJ.utils.book_append_sheet(wb, SJ.utils.aoa_to_sheet([[]]), n);
    return n;
  }

  function renameSheet(book, from, to) {
    const wb = book.wb;
    const n = String(to || '').trim();
    if (!n) throw new Error('Пустое имя листа');
    if (n.length > 31) throw new Error('Имя листа длиннее 31 знака');
    if (/[\\/?*\[\]:]/.test(n)) throw new Error('Имя листа не должно содержать \\ / ? * [ ] :');
    if (wb.SheetNames.indexOf(from) < 0) throw new Error('Нет листа «' + from + '»');
    if (from !== n && wb.SheetNames.indexOf(n) >= 0) throw new Error('Лист «' + n + '» уже есть');
    wb.Sheets[n] = wb.Sheets[from];
    delete wb.Sheets[from];
    wb.SheetNames[wb.SheetNames.indexOf(from)] = n;
    return n;
  }

  function deleteSheet(book, name) {
    const wb = book.wb;
    const i = wb.SheetNames.indexOf(name);
    if (i < 0) throw new Error('Нет листа «' + name + '»');
    if (wb.SheetNames.length === 1) throw new Error('Нельзя удалить единственный лист');
    wb.SheetNames.splice(i, 1);
    delete wb.Sheets[name];
    return sheetNames(book);
  }

  function usedRange(book, sheet) {
    const ws = sheetOf(book, sheet);
    return ws['!ref'] || 'A1:A1';
  }

  /* Значения листа массивом массивов — для аналитики, диаграмм и передачи в ИИ */
  function toAoa(book, sheet) {
    const ws = sheetOf(book, sheet);
    return SJ.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
  }

  function merges(book, sheet) {
    const ws = sheetOf(book, sheet);
    return (ws['!merges'] || []).map((m) => SJ.utils.encode_range(m));
  }

  function colWidths(book, sheet) {
    const ws = sheetOf(book, sheet);
    return (ws['!cols'] || []).map((c) => (c && c.wpx) || 0);
  }

  /* Сохранить книгу. Возвращает байты и имя файла — их отдают на скачивание. */
  function save(book, fileName) {
    const name = String(fileName || book.fileName || 'книга.xlsx');
    const t = bookTypeOf(name);
    const wb = book.wb;
    /* перед записью пересчитываем границы: иначе Excel/SheetJS могут не увидеть «хвостовые» ячейки */
    (wb.SheetNames || []).forEach((n) => { if (wb.Sheets[n]) fixRef(wb.Sheets[n]); });
    wb.Workbook = wb.Workbook || {};
    wb.Workbook.CalcPr = { fullCalcOnLoad: true };   /* Excel пересчитает формулы при открытии */
    const out = SJ.write(wb, {
      bookType: t === 'csv' ? 'csv' : (t === 'txt' ? 'txt' : 'xlsx'),
      type: 'array',
      bookSST: false,
      compression: true,
    });
    return { name: name, bytes: new Uint8Array(out) };
  }

  const api = { open, create, sheetNames, getCell, setCell, addSheet, renameSheet, deleteSheet, usedRange, toAoa, merges, colWidths, save, bookTypeOf };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelEngine = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
