'use strict';

/**
 * Диаграммы (этап 5, 30.10.2026). Без внешних библиотек: рисуем SVG сами.
 *
 * Почему так: Chart.js/ECharts — это ещё 200–600 КБ в сборку телефона и свои лицензии.
 * Нам нужны столбцы, линии, круг и комбинация — их честно можно нарисовать SVG-кодом,
 * который работает и в браузере, и на телефоне, и проверяется в Node без DOM.
 *
 * Что умеет:
 *   pickType(aoa)            -> 'line' | 'bar' | 'pie'  (выбор по форме данных)
 *   fromRange(aoa, catCol, valCol) -> {cats, vals}
 *   build(kind, series, opts)-> строка SVG
 *
 * Ограничения (честно): это диаграмма НА ЭКРАНЕ. В файл .xlsx диаграмма пока не пишется
 * (бесплатные библиотеки не умеют), поэтому сохраняем книгу без неё.
 */
(function (root) {
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function num(v) {
    if (isNum(v)) return v;
    const s = String(v === undefined || v === null ? '' : v).replace(/\s/g, '').replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : null;
  }

  /* Выбор вида диаграммы по форме таблицы:
     - одна текстовая колонка и одна числовая, строк мало (≤8) и суммы не про время — круговая;
     - в первой колонке похоже на даты/месяцы — линия (динамика);
     - иначе — столбцы. */
  function pickType(aoa) {
    const rows = (aoa || []).filter((r) => Array.isArray(r) && r.length);
    if (rows.length < 2) return 'bar';
    const body = rows.slice(1);
    const nums = body.filter((r) => num(r[1]) !== null).length;
    if (!nums) return 'bar';
    const first = String(body[0][0] || '');
    const looksDate = /^\d{4}[-./]|^\d{1,2}[./]\d{1,2}|янв|фев|мар|апр|ма[йя]|июн|июл|авг|сен|окт|ноя|дек|q[1-4]|квартал/i.test(first);
    if (looksDate) return 'line';
    if (nums <= 8 && nums === body.length) return 'pie';
    return 'bar';
  }

  /* Берём две колонки: подписи и числа. Строка заголовка отбрасывается. */
  function fromRange(aoa, catCol, valCol) {
    const rows = (aoa || []).slice();
    if (!rows.length) return { cats: [], vals: [], title: '' };
    const header = rows.shift() || [];
    const c = catCol === undefined ? 0 : catCol;
    const v = valCol === undefined ? 1 : valCol;
    const cats = [], vals = [];
    rows.forEach((r) => {
      if (!r) return;
      const n = num(r[v]);
      if (n === null) return;
      cats.push(String(r[c] === undefined || r[c] === '' ? '' : r[c]));
      vals.push(n);
    });
    return { cats: cats, vals: vals, title: String(header[v] === undefined ? '' : header[v]) };
  }

  const W = 640, H = 320, PAD = { l: 52, r: 16, t: 22, b: 46 };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt = (n) => (Math.abs(n) >= 1000 ? Math.round(n).toLocaleString('ru-RU') : String(Math.round(n * 100) / 100));

  function scale(vals) {
    let min = Math.min(0, Math.min.apply(null, vals));
    let max = Math.max.apply(null, vals.concat([0]));
    if (min === max) max = min + 1;
    const span = max - min;
    const y = (v) => PAD.t + (H - PAD.t - PAD.b) * (1 - (v - min) / span);
    return { min: min, max: max, y: y };
  }

  function axes(s, vals, cats) {
    const out = [];
    out.push('<line x1="' + PAD.l + '" y1="' + s.y(s.min) + '" x2="' + (W - PAD.r) + '" y2="' + s.y(s.min) + '" stroke="#4b3b7a"/>');
    for (let i = 0; i <= 4; i++) {
      const v = s.min + (s.max - s.min) * i / 4;
      const yy = s.y(v);
      out.push('<line x1="' + PAD.l + '" y1="' + yy + '" x2="' + (W - PAD.r) + '" y2="' + yy + '" stroke="#2b2346" stroke-dasharray="3 4"/>');
      out.push('<text x="' + (PAD.l - 6) + '" y="' + (yy + 4) + '" fill="#8f7fc0" font-size="10" text-anchor="end">' + esc(fmt(v)) + '</text>');
    }
    const step = Math.max(1, Math.ceil(cats.length / 12));
    cats.forEach((c, i) => {
      if (i % step) return;
      const x = PAD.l + (W - PAD.l - PAD.r) * (cats.length === 1 ? 0.5 : i / (cats.length - 1));
      out.push('<text x="' + x + '" y="' + (H - PAD.b + 16) + '" fill="#8f7fc0" font-size="10" text-anchor="middle">' + esc(String(c).slice(0, 12)) + '</text>');
    });
    return out.join('');
  }

  function bar(series) {
    const vals = series.vals, cats = series.cats;
    if (!vals.length) return empty();
    const s = scale(vals);
    const bw = (W - PAD.l - PAD.r) / vals.length * 0.62;
    const stepX = (W - PAD.l - PAD.r) / vals.length;
    let out = axes(s, vals, cats);
    vals.forEach((v, i) => {
      const x = PAD.l + stepX * i + (stepX - bw) / 2;
      const y0 = s.y(0), y1 = s.y(v);
      out += '<rect x="' + x + '" y="' + Math.min(y0, y1) + '" width="' + bw + '" height="' + Math.abs(y0 - y1) + '" fill="#6b4bd6" rx="3"/>';
      if (vals.length <= 14) out += '<text x="' + (x + bw / 2) + '" y="' + (Math.min(y0, y1) - 5) + '" fill="#cfc4ff" font-size="10" text-anchor="middle">' + esc(fmt(v)) + '</text>';
    });
    return svg(out, series.title);
  }

  function line(series) {
    const vals = series.vals, cats = series.cats;
    if (!vals.length) return empty();
    const s = scale(vals);
    let out = axes(s, vals, cats);
    const stepX = (W - PAD.l - PAD.r) / Math.max(1, vals.length - 1);
    const pts = vals.map((v, i) => (PAD.l + stepX * i) + ',' + s.y(v));
    out += '<polyline fill="none" stroke="#8f6bff" stroke-width="2.5" points="' + pts.join(' ') + '"/>';
    vals.forEach((v, i) => {
      const x = PAD.l + stepX * i, y = s.y(v);
      out += '<circle cx="' + x + '" cy="' + y + '" r="3.4" fill="#b9a6f5"/>';
    });
    return svg(out, series.title);
  }

  function pie(series) {
    const vals = series.vals, cats = series.cats;
    const total = vals.reduce((a, b) => a + Math.abs(b), 0);
    if (!vals.length || !total) return empty();
    const cx = W / 2, cy = H / 2, r = Math.min(W, H) / 2 - 34;
    const colors = ['#6b4bd6', '#8f6bff', '#4bd6a5', '#d6b44b', '#d64b8f', '#4b9ad6', '#b9a6f5', '#8ef0c0'];
    let a0 = -Math.PI / 2, out = '';
    vals.forEach((v, i) => {
      const a1 = a0 + Math.PI * 2 * (Math.abs(v) / total);
      const x0 = cx + r * Math.cos(a0), y0 = cy + r * Math.sin(a0);
      const x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
      const large = (a1 - a0) > Math.PI ? 1 : 0;
      out += '<path d="M' + cx + ',' + cy + ' L' + x0 + ',' + y0 + ' A' + r + ',' + r + ' 0 ' + large + ' 1 ' + x1 + ',' + y1 + ' Z" fill="' + colors[i % colors.length] + '"/>';
      const mid = (a0 + a1) / 2;
      const lx = cx + (r + 14) * Math.cos(mid), ly = cy + (r + 14) * Math.sin(mid);
      out += '<text x="' + lx + '" y="' + ly + '" fill="#cfc4ff" font-size="10" text-anchor="middle">' + esc(String(cats[i] || '').slice(0, 10)) + '</text>';
      a0 = a1;
    });
    return svg(out, series.title);
  }

  function empty() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="100%"><text x="' + (W / 2) + '" y="' + (H / 2) + '" fill="#8f7fc0" font-size="13" text-anchor="middle">Нет числовых данных для диаграммы</text></svg>';
  }

  function svg(inner, title) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img">'
      + (title ? '<text x="' + PAD.l + '" y="14" fill="#efe9ff" font-size="12" font-weight="600">' + esc(title) + '</text>' : '')
      + inner + '</svg>';
  }

  function build(kind, series, opts) {
    const k = kind || 'bar';
    if (k === 'pie') return pie(series);
    if (k === 'line') return line(series);
    return bar(series);
  }

  const api = { pickType, fromRange, build, bar, line, pie };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelChart = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
