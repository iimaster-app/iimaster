'use strict';

/**
 * Макросы (этап 9, 30.10.2026).
 *
 * Что здесь есть: макрос как последовательность НАШИХ операций над листом —
 * фильтр, сортировка, удаление дублей, удаление пустых строк, группировка, объединение таблиц.
 * Макрос реально выполняется и пишет журнал: какой шаг, сколько строк было/стало.
 *
 * Чего здесь НЕТ и не будет притворяться: исполнения VBA. Движка VBA вне Excel не существует,
 * поэтому VBA только ГЕНЕРИРУЕТСЯ как текст для вставки в Excel (toVba), с явной пометкой.
 *
 * Всё чистыми функциями: проверяется в Node, работает в браузере и на телефоне.
 */
(function (root) {
  const Q = (root && root.ExcelQuery) || (typeof require === 'function' ? require('./excel-query.js') : null);

  /* Доступные операции. Аргумент col — номер колонки (0 — первая), как в наших листах. */
  const STEPS = [
    { id: 'dropEmpty', title: 'Убрать пустые строки', fields: [] },
    { id: 'dedupe', title: 'Убрать дубликаты строк', fields: [] },
    { id: 'filterGt', title: 'Оставить строки, где число больше', fields: ['col', 'value'] },
    { id: 'filterEq', title: 'Оставить строки с точным значением', fields: ['col', 'value'] },
    { id: 'sortDesc', title: 'Сортировать по убыванию', fields: ['col'] },
    { id: 'sortAsc', title: 'Сортировать по возрастанию', fields: ['col'] },
    { id: 'group', title: 'Свернуть по колонке (суммы и средние)', fields: ['col'] },
  ];

  function num(v) {
    if (typeof v === 'number' && isFinite(v)) return v;
    const n = Number(String(v === undefined || v === null ? '' : v).replace(/\s/g, '').replace(',', '.'));
    return isFinite(n) ? n : null;
  }

  function describe(step) {
    const s = step || {};
    const t = (STEPS.find((x) => x.id === s.id) || {}).title || s.id;
    if (s.id === 'filterGt') return t + ' ' + s.value + ' в колонке ' + (Number(s.col) + 1);
    if (s.id === 'filterEq') return t + ' «' + s.value + '» в колонке ' + (Number(s.col) + 1);
    if (s.id === 'sortDesc' || s.id === 'sortAsc' || s.id === 'group') return t + ' (колонка ' + (Number(s.col) + 1) + ')';
    return t;
  }

  /* Выполнить макрос. Возвращает {ok, aoa, log, error}. */
  function run(aoa, steps) {
    if (!Q) return { ok: false, error: 'Нет движка преобразований (excel-query.js)', aoa: aoa || [[]], log: [] };
    let data = (aoa || [[]]).map((r) => (Array.isArray(r) ? r.slice() : [r]));
    const log = [];
    const list = Array.isArray(steps) ? steps : [];
    if (!list.length) return { ok: false, error: 'Макрос пуст: добавьте хотя бы один шаг', aoa: data, log: [] };
    for (let i = 0; i < list.length; i++) {
      const s = list[i] || {};
      const before = Math.max(0, data.length - 1);
      try {
        if (s.id === 'dropEmpty') data = Q.dropEmptyRows(data);
        else if (s.id === 'dedupe') data = Q.dedupe(data);
        else if (s.id === 'filterGt') data = Q.filterRows(data, Number(s.col) || 0, (v) => { const n = num(v); return n !== null && n > Number(s.value || 0); });
        else if (s.id === 'filterEq') data = Q.filterRows(data, Number(s.col) || 0, (v) => String(v === undefined || v === null ? '' : v).trim().toLowerCase() === String(s.value === undefined ? '' : s.value).trim().toLowerCase());
        else if (s.id === 'sortDesc') data = Q.sortRows(data, Number(s.col) || 0, true);
        else if (s.id === 'sortAsc') data = Q.sortRows(data, Number(s.col) || 0, false);
        else if (s.id === 'group') data = Q.groupBy(data, Number(s.col) || 0);
        else { log.push({ step: i + 1, id: s.id || '?', ok: false, info: 'Неизвестный шаг — пропущен' }); continue; }
        const after = Math.max(0, data.length - 1);
        log.push({ step: i + 1, id: s.id, ok: true, before: before, after: after, info: describe(s) + ': строк ' + before + ' → ' + after });
      } catch (e) {
        return { ok: false, error: 'Шаг ' + (i + 1) + ' («' + describe(s) + '») не выполнен: ' + ((e && e.message) || e), aoa: data, log: log };
      }
    }
    return { ok: true, aoa: data, log: log };
  }

  /* VBA — только ТЕКСТ для Excel. Никакого исполнения. */
  function comment(n, text) { return "    ' шаг " + n + ': ' + text; }
  function toVba(steps, sheetName) {
    const list = Array.isArray(steps) ? steps : [];
    const ws = String(sheetName || 'Лист1').replace(/"/g, '""');
    const L = [];
    L.push("' ===== ВНИМАНИЕ: это ТЕКСТ для Excel, внутри «ИИ Мастер» он НЕ выполняется =====");
    L.push("' Сгенерировано приложением «ИИ Мастер». Вставьте в Excel: Alt+F11 -> Module -> вставить.");
    L.push("' Макрос повторяет шаги, которые уже выполнены в приложении над листом «" + ws + "».");
    L.push('Sub МакросИИМастер()');
    L.push('    Dim ws As Worksheet');
    L.push('    Set ws = ThisWorkbook.Worksheets("' + ws + '")');
    L.push('    Application.ScreenUpdating = False');
    list.forEach((s, i) => {
      const col = Number(s && s.col) || 0;
      const letter = colLetter(col);
      const n = i + 1;
      if (!s) return;
      if (s.id === 'dropEmpty') {
        L.push(comment(n, 'убрать пустые строки'));
        L.push('    ws.Range("A1").CurrentRegion.SpecialCells(xlCellTypeBlanks).EntireRow.Delete');
      } else if (s.id === 'dedupe') {
        L.push(comment(n, 'убрать дубликаты'));
        L.push('    ws.Range("A1").CurrentRegion.RemoveDuplicates Columns:=1, Header:=xlYes');
      } else if (s.id === 'filterGt') {
        L.push(comment(n, 'оставить строки, где ' + letter + ' > ' + s.value));
        L.push('    ws.Range("A1").CurrentRegion.AutoFilter Field:=' + (col + 1) + ', Criteria1:=">" & ' + Number(s.value || 0));
      } else if (s.id === 'filterEq') {
        L.push(comment(n, 'оставить строки со значением ' + s.value));
        L.push('    ws.Range("A1").CurrentRegion.AutoFilter Field:=' + (col + 1) + ', Criteria1:="' + String(s.value === undefined ? '' : s.value).replace(/"/g, '""') + '"');
      } else if (s.id === 'sortDesc' || s.id === 'sortAsc') {
        const ord = s.id === 'sortDesc' ? 'xlDescending' : 'xlAscending';
        L.push(comment(n, 'сортировка ' + letter));
        L.push('    ws.Range("A1").CurrentRegion.Sort Key1:=ws.Range("' + letter + '2"), Order1:=' + ord + ', Header:=xlYes');
      } else if (s.id === 'group') {
        L.push(comment(n, 'свод по колонке ' + letter));
        L.push("    ' встроенный свод в VBA громоздкий: сделайте сводную таблицу на листе");
        L.push("    ' или выполните этот шаг в приложении и вставьте готовый результат.");
      }
    });
    L.push('    Application.ScreenUpdating = True');
    L.push('End Sub');
    return L.join('\n');
  }

  function colLetter(i) {
    let s = '', n = Number(i) || 0;
    do { s = String.fromCharCode(65 + (n % 26)) + s; n = Math.floor(n / 26) - 1; } while (n >= 0);
    return s;
  }

  /* Сохранение/чтение макроса как текста (JSON) — для «повторного использования» */
  function toJson(name, steps) {
    return JSON.stringify({ app: 'ii-master', kind: 'excel-macro', name: String(name || 'Макрос'), steps: steps || [] }, null, 1);
  }
  function fromJson(text) {
    let j = null;
    try { j = JSON.parse(text); } catch (e) { return { ok: false, error: 'Это не файл макроса (не удалось разобрать JSON)' }; }
    if (!j || j.kind !== 'excel-macro' || !Array.isArray(j.steps)) return { ok: false, error: 'В файле нет описания макроса' };
    return { ok: true, name: String(j.name || 'Макрос'), steps: j.steps };
  }

  const api = { STEPS, run, toVba, toJson, fromJson, describe };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelMacro = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
