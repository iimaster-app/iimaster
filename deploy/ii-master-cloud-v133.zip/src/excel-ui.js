'use strict';

/**
 * Экран Excel (этап 3, 30.10.2026).
 *
 * Что делает: открывает настоящий файл, показывает сетку с листами, даёт править ячейки
 * и сохранять книгу. Работает на движке из этапа 2 (src/excel.js + SheetJS).
 *
 * Чего ещё НЕТ (честно, чтобы не искать): формул в интерфейсе (движок их читает и хранит,
 * но ввода формулы с пересчётом пока нет), диаграмм, дашбордов, Power Query, макросов.
 * Всё это - следующие этапы.
 */
(function (root) {
  const E = () => root.ExcelEngine;
  let book = null;
  let cur = null;         /* текущий лист */
  let curDashPoints = 12; /* сколько периодов показывать на дашборде */
  let dirty = false;

  const style = document.createElement('style');
  style.textContent = `
  #xlView{position:fixed;inset:0;z-index:9000;background:#0d0819;display:none;flex-direction:column;
    font:13px/1.35 system-ui,sans-serif;color:#efe9ff}
  #xlView.on{display:flex}
  .xlTop{display:flex;align-items:center;gap:8px;padding:calc(10px + env(safe-area-inset-top,0px)) 12px 10px;
    border-bottom:1px solid #2b2346;flex:none;flex-wrap:wrap}
  .xlName{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:40vw}
  .xlBtn{padding:7px 11px;border-radius:10px;border:1px solid #5a3fa0;background:#1b1430;color:#efe9ff;
    cursor:pointer;font:600 12.5px system-ui,sans-serif}
  .xlBtn:active{transform:translateY(1px)}
  .xlBtn.p{background:#6b4bd6;border-color:#6b4bd6}
  .xlX{margin-left:auto;border:0;background:none;color:#b9a6f5;font-size:22px;cursor:pointer;padding:0 4px}
  .xlTabs{display:flex;gap:6px;overflow-x:auto;padding:8px 12px;border-bottom:1px solid #2b2346;flex:none}
  .xlTab{padding:5px 11px;border-radius:9px;background:#171027;border:1px solid #33285a;cursor:pointer;white-space:nowrap}
  .xlTab.on{background:#6b4bd6;border-color:#6b4bd6;color:#fff}
  .xlGrid{flex:1;overflow:auto;padding:0 0 20px}
  .xlGrid table{border-collapse:collapse;font-size:12.5px}
  .xlGrid th,.xlGrid td{border:1px solid #2b2346;padding:4px 8px;min-width:78px;max-width:320px;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:26px}
  .xlGrid th{background:#171027;color:#b9a6f5;position:sticky;top:0;z-index:2;font-weight:600}
  .xlGrid td[contenteditable="true"]{outline:2px solid #6b4bd6;background:#1b1430;white-space:pre-wrap}
  .xlGrid td.num{color:#8ef0c0}
  .xlEmpty{padding:26px;color:#b9a6f5;text-align:center;line-height:1.6}
  .xlMsg{padding:6px 12px;color:#b9a6f5;font-size:12px;flex:none;min-height:18px}
  `;
  document.head.appendChild(style);

  function el(id) { return document.getElementById(id); }
  function esc(s) { return String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function msg(t) { const m = el('xlMsg'); if (m) m.textContent = t || ''; }

  function mount() {
    if (el('xlView')) return;
    const v = document.createElement('div');
    v.id = 'xlView';
    v.innerHTML = `
      <div class="xlTop">
        <span class="xlName" id="xlName">Таблица</span>
        <button class="xlBtn" id="xlOpen">Открыть</button>
        <button class="xlBtn p" id="xlSave">Сохранить</button>
        <button class="xlBtn" id="xlAdd">+ Лист</button>
        <button class="xlBtn" id="xlNew">Новая книга</button>
        <button class="xlBtn" id="xlChart">Диаграмма</button>
        <button class="xlBtn" id="xlDash">Дашборд</button>
        <button class="xlBtn" id="xlAnal">Анализ</button>
        <button class="xlBtn" id="xlDedup">Дубли</button>
        <button class="xlBtn" id="xlGroup">Группировать</button>
        <button class="xlBtn" id="xlUnion">Объединить</button>
        <button class="xlBtn" id="xlM">M-код</button>
        <button class="xlBtn" id="xlMacro">Макрос</button>
        <button class="xlBtn" id="xlAdvisor">Советник</button>
        <button class="xlX" id="xlClose" title="Закрыть">×</button>
      </div>
      <div class="xlTabs" id="xlTabs"></div>
      <div class="xlMsg" id="xlMsg"></div>
      <div class="xlChartWrap" id="xlChartWrap" style="display:none;padding:10px 12px;border-bottom:1px solid #2b2346;flex:none">
        <div id="xlChartBox"></div>
      </div>
      <div class="xlChartWrap" id="xlAnWrap" style="display:none;padding:10px 12px;border-bottom:1px solid #2b2346;flex:none">
        <div style="display:flex;gap:6px;margin-bottom:8px">
          <button class="xlBtn" id="xlAnHide">Скрыть отчёт</button>
        </div>
        <pre id="xlAnBox" style="white-space:pre-wrap;margin:0;font:12.5px/1.5 system-ui,sans-serif;color:#e6ddff"></pre>
      </div>
      <div class="xlChartWrap" id="xlDashWrap" style="display:none;padding:10px 12px;border-bottom:1px solid #2b2346;flex:none">
        <div style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap" id="xlDashPts">
          <button class="xlBtn" data-p="6">6 периодов</button>
          <button class="xlBtn" data-p="12">12 периодов</button>
          <button class="xlBtn" data-p="0">Всё</button>
          <button class="xlBtn" id="xlDashHide">Скрыть</button>
        </div>
        <div id="xlDashBox"></div>
      </div>
      <div class="xlGrid" id="xlGrid"></div>
      <input type="file" id="xlFile" accept=".xlsx,.xlsm,.xls,.csv,.txt,.tsv" style="display:none">`;
    document.body.appendChild(v);

    el('xlClose').onclick = close;
    el('xlOpen').onclick = () => el('xlFile').click();
    el('xlSave').onclick = doSave;
    el('xlNew').onclick = () => { book = E().create(); cur = E().sheetNames(book)[0]; dirty = false; draw(); msg('Новая книга создана'); };
    el('xlChart').onclick = drawChart;
    el('xlDash').onclick = () => drawDash(curDashPoints);
    el('xlAnal').onclick = () => drawAnalysis();
    el('xlAnHide').onclick = () => { const w = el('xlAnWrap'); if (w) w.style.display = 'none'; };
    el('xlDedup').onclick = () => pqDedup();
    el('xlGroup').onclick = () => pqGroup();
    el('xlUnion').onclick = () => pqUnion();
    el('xlM').onclick = () => pqM();
    el('xlMacro').onclick = () => runMacro();
    el('xlDashHide').onclick = () => { const w = el('xlDashWrap'); if (w) w.style.display = 'none'; };
    el('xlDashPts').querySelectorAll('button[data-p]').forEach((b) => {
      b.onclick = () => { curDashPoints = Number(b.getAttribute('data-p')); drawDash(curDashPoints); };
    });
    el('xlAdd').onclick = () => {
      if (!book) { msg('Сначала откройте файл или создайте книгу'); return; }
      cur = E().addSheet(book, 'Лист' + (E().sheetNames(book).length + 1));
      dirty = true; draw();
    };
    el('xlFile').onchange = async (ev) => {
      const f = ev.target.files && ev.target.files[0];
      ev.target.value = '';
      if (!f) return;
      msg('Открываю «' + f.name + '»…');
      try {
        book = await E().open(f, f.name);
        cur = E().sheetNames(book)[0];
        dirty = false;
        draw();
        msg('Открыто: ' + f.name + ' · листов: ' + E().sheetNames(book).length);
      } catch (e) {
        msg('Не удалось открыть файл: ' + ((e && e.message) || e));
      }
    };

    /* ===== Советник автоматизации (этап 10) =====
       Пишем журнал действий (только вид операции), а по кнопке предлагаем макрос.
       Запуск — ТОЛЬКО после нажатия «Создать макрос», без согласия ничего не выполняется. */
    const ACT = { xlDedup: 'dedupe', xlGroup: 'group', xlUnion: 'union', xlChart: 'chart', xlDash: 'dashboard', xlAnal: 'analysis', xlMacro: 'dedupe' };
    const top = document.querySelector('#xlView .xlTop');
    if (top) top.addEventListener('click', (ev) => {
      const id = ev.target && ev.target.id;
      if (!id || !ACT[id] || !root.ExcelAdvisor) return;
      try {
        const h = root.ExcelAdvisor.record(JSON.parse(localStorage.getItem('ii_xl_actions') || '[]'), ACT[id]);
        localStorage.setItem('ii_xl_actions', JSON.stringify(h));
      } catch (e) {}
    });
    el('xlAdvisor').onclick = async () => {
      if (!root.ExcelAdvisor) {
        msg('Загружаю советник…');
        try { for (const u of scriptCandidates('excel-advisor.js')) { if (await loadWithBust(u, () => !!root.ExcelAdvisor)) break; } } catch (e) {}
      }
      const A = root.ExcelAdvisor;
      const wrap = el('xlAnWrap'), box = el('xlAnBox');
      if (!A) { msg('Модуль советника не загрузился'); return; }
      let hist = [];
      try { hist = JSON.parse(localStorage.getItem('ii_xl_actions') || '[]'); } catch (e) {}
      const s = A.suggest(hist);
      if (wrap && box) {
        wrap.style.display = 'block';
        box.textContent = s.ok
          ? s.text + '\n\nЕсли согласны — нажмите «Создать макрос». Без согласия ничего не запускается.\n\nБуду выполнять шаги:\n'
            + s.steps.map((x, i) => '  ' + (i + 1) + '. ' + (root.ExcelMacro ? root.ExcelMacro.describe(x) : x.id)).join('\n')
          : 'Пока не вижу повторяющихся действий. Сделайте пару раз одно и то же (убрать дубли, свод, дашборд) — и я предложу макрос.';
      }
      msg(s.ok ? 'Есть предложение — смотрите панель' : 'Повторов пока нет');
      if (!s.ok) return;
      const ok = (typeof askOk === 'function') ? await askOk('Создать макрос?', s.text, 'Создать макрос') : false;
      if (!ok) { msg('Оставили как есть — макрос не создан'); return; }
      if (!await ensureMacro()) { msg('Модуль макросов не загрузился'); return; }
      const res = A.accept(s, true, (steps) => root.ExcelMacro.run(E().toAoa(book, cur), steps));
      if (!res.ok) { msg(res.error); return; }
      if (!res.result || !res.result.ok) { msg((res.result && res.result.error) || 'Макрос не выполнен'); return; }
      putSheet(res.result.aoa, 'После макроса');
      msg('Макрос создан и выполнен · шагов: ' + res.result.log.length);
    };
  }

  /* Диаграмма по текущему листу: вид выбираем по форме данных (динамика -> линия,
     мало категорий -> круг, иначе столбцы). Рисуем SVG, без внешних библиотек. */
  function drawChart(kind) {
    const wrap = el('xlChartWrap'), box = el('xlChartBox');
    if (!wrap || !box) return;
    if (!book) { msg('Сначала откройте файл'); return; }
    const CH = root.ExcelChart;
    if (!CH) { msg('Модуль диаграмм не загрузился'); return; }
    const aoa = E().toAoa(book, cur);
    const series = CH.fromRange(aoa, 0, 1);
    if (!series.vals.length) { msg('Для диаграммы нужны числа во втором столбце'); return; }
    const type = kind || CH.pickType(aoa);
    wrap.style.display = 'block';
    box.innerHTML = CH.build(type, series);
    msg('Диаграмма: ' + ({ line: 'линия', bar: 'столбцы', pie: 'круг' }[type] || type)
      + ' · по столбцу «' + (series.title || 'значения') + '» (' + series.vals.length + ' точек).'
      + ' Внимание: в файл .xlsx диаграмма пока не записывается — она на экране.');
  }

  /* Дашборд: KPI + несколько графиков + фильтр по числу периодов. */
  function drawDash(points) {
    const wrap = el('xlDashWrap'), box = el('xlDashBox');
    if (!wrap || !box) return;
    if (!book) { msg('Сначала откройте файл'); return; }
    const D = root.ExcelDash, CH = root.ExcelChart;
    if (!D || !CH) { msg('Модуль дашбордов не загрузился'); return; }
    const aoa = E().toAoa(book, cur);
    const r = D.render(aoa, { points: points, chart: (kind, ser) => CH.build(kind, ser) });
    wrap.style.display = 'block';
    if (!r.ok) { box.innerHTML = '<div class="xlEmpty">' + r.error + '</div>'; return; }
    box.innerHTML = r.html;
    msg('Дашборд по листу «' + cur + '» · периодов: ' + r.shown.cats.length + ' из ' + r.series.cats.length);
  }

  /* Аналитика листа: дубликаты, пропуски, выбросы, тренд — и вывод человеческим языком. */
  async function drawAnalysis() {
    const wrap = el('xlAnWrap'), box = el('xlAnBox');
    if (!wrap || !box) return;
    if (!book) { msg('Сначала откройте файл'); return; }
    if (!root.ExcelAnalytics) {
      msg('Загружаю модуль аналитики…');
      try {
        for (const u of scriptCandidates('excel-analytics.js')) {
          if (await loadWithBust(u, () => !!root.ExcelAnalytics)) break;
        }
      } catch (e) { /* ниже проверим ещё раз */ }
    }
    const A = root.ExcelAnalytics;
    if (!A) { msg('Модуль аналитики не загрузился'); return; }
    const r = A.audit(E().toAoa(book, cur));
    wrap.style.display = 'block';
    box.textContent = r.ok ? r.text : ('Не удалось проанализировать: ' + r.error);
    msg('Отчёт по листу «' + cur + '»' + (r.ok ? ' · замечаний: ' + r.issues.length : ''));
  }

  /* ===== Power Query (этап 8): преобразования делаем сами, M-код — только текст ===== */
  async function ensureQuery() {
    if (root.ExcelQuery) return true;
    try {
      for (const u of scriptCandidates('excel-query.js')) {
        if (await loadWithBust(u, () => !!root.ExcelQuery)) return true;
      }
    } catch (e) {}
    return !!root.ExcelQuery;
  }
  function putSheet(aoa, name) {
    if (!book) book = E().create();
    const n = E().addSheet(book, name || 'Запрос');
    E().sheetNames(book);            /* лист уже добавлен движком */
    const ws = cur;
    /* записываем построчно через движок: так работают и типы, и диапазон */
    aoa.forEach((row, r) => (row || []).forEach((v, c) => {
      if (v === '' || v === null || v === undefined) return;
      E().setCell(book, n, colName(c) + (r + 1), v);
    }));
    cur = n; dirty = true; draw();
    return n;
  }
  async function pqDedup() {
    if (!book) { msg('Сначала откройте файл'); return; }
    if (!await ensureQuery()) { msg('Модуль запросов не загрузился'); return; }
    const aoa = E().toAoa(book, cur);
    const out = root.ExcelQuery.dedupe(aoa);
    const removed = (aoa.length - 1) - (out.length - 1);
    if (!removed) { msg('Полных дубликатов нет — ничего не убрано'); return; }
    putSheet(out, 'Без дублей');
    msg('Убрано дубликатов: ' + removed + ' · результат на листе «' + cur + '» (исходный лист сохранён)');
  }
  async function pqGroup() {
    if (!book) { msg('Сначала откройте файл'); return; }
    if (!await ensureQuery()) { msg('Модуль запросов не загрузился'); return; }
    const aoa = E().toAoa(book, cur);
    const out = root.ExcelQuery.groupBy(aoa, 0);
    if (out.length < 2) { msg('Нечего группировать: нужен столбец подписей и числа'); return; }
    putSheet(out, 'Свод');
    msg('Свод по первой колонке готов · строк: ' + (out.length - 1) + ' · лист «' + cur + '»');
  }
  async function pqUnion() {
    if (!await ensureQuery()) { msg('Модуль запросов не загрузился'); return; }
    const inp = document.createElement('input');
    inp.type = 'file'; inp.multiple = true;
    inp.accept = '.xlsx,.xlsm,.xls,.csv,.txt,.tsv';
    inp.onchange = async () => {
      const files = Array.from(inp.files || []);
      if (!files.length) return;
      msg('Объединяю файлов: ' + files.length + '…');
      const tables = [];
      for (const f of files) {
        try {
          const b = await E().open(f, f.name);
          tables.push(E().toAoa(b, E().sheetNames(b)[0]));
        } catch (e) { msg('Файл «' + f.name + '» не открылся: ' + ((e && e.message) || e)); }
      }
      if (tables.length < 1) { msg('Ни один файл не открылся'); return; }
      const r = root.ExcelQuery.union(tables);
      if (!r.report.ok) { msg(r.report.error); return; }
      putSheet(r.aoa, 'Объединено');
      msg('Объединено: файлов ' + r.report.tables + ', строк ' + r.report.rows + ', колонок ' + r.report.cols
        + (r.report.mismatches.length ? ' · разная структура у файлов: ' + r.report.mismatches.map((m) => m.table).join(', ') : ''));
    };
    inp.click();
  }
  async function pqM() {
    if (!book) { msg('Сначала откройте файл'); return; }
    if (!await ensureQuery()) { msg('Модуль запросов не загрузился'); return; }
    const code = root.ExcelQuery.mCode(cur, []);
    const wrap = el('xlAnWrap'), box = el('xlAnBox');
    if (wrap && box) {
      wrap.style.display = 'block';
      box.textContent = 'M-код (это ТЕКСТ для вставки в Excel — здесь он не выполняется):\n\n' + code;
    }
    msg('M-код сформирован как текст для Excel');
  }

  /* Макрос (этап 9): цепочка наших операций выполняется по-настоящему, VBA — только текст. */
  async function ensureMacro() {
    if (root.ExcelMacro) return true;
    try {
      for (const u of scriptCandidates('excel-macro.js')) {
        if (await loadWithBust(u, () => !!root.ExcelMacro)) return true;
      }
    } catch (e) {}
    return !!root.ExcelMacro;
  }
  async function runMacro() {
    if (!book) { msg('Сначала откройте файл'); return; }
    if (!await ensureQuery() || !await ensureMacro()) { msg('Модуль макросов не загрузился'); return; }
    /* Пока один готовый сценарий: чистка таблицы. Следующий этап — сборка своих сценариев. */
    const steps = [{ id: 'dropEmpty' }, { id: 'dedupe' }, { id: 'sortDesc', col: 1 }];
    const aoa = E().toAoa(book, cur);
    const r = root.ExcelMacro.run(aoa, steps);
    const wrap = el('xlAnWrap'), box = el('xlAnBox');
    if (!r.ok) {
      if (wrap && box) { wrap.style.display = 'block'; box.textContent = 'Макрос не выполнен: ' + r.error; }
      msg('Макрос не выполнен: ' + r.error);
      return;
    }
    putSheet(r.aoa, 'После макроса');
    const vba = root.ExcelMacro.toVba(steps, cur);
    if (wrap && box) {
      wrap.style.display = 'block';
      box.textContent = 'Макрос выполнен (журнал):\n' + r.log.map((x) => '  ' + x.info).join('\n')
        + '\n\nVBA — это ТЕКСТ для Excel, здесь он не выполняется:\n\n' + vba;
    }
    msg('Макрос выполнен · лист «' + cur + '» · шагов: ' + r.log.length);
  }

  function draw() {
    const nameEl = el('xlName'); if (nameEl) nameEl.textContent = book ? (book.fileName + (dirty ? ' •' : '')) : 'Таблица';
    const tabs = el('xlTabs');
    tabs.innerHTML = '';
    if (book) {
      E().sheetNames(book).forEach((n) => {
        const b = document.createElement('div');
        b.className = 'xlTab' + (n === cur ? ' on' : '');
        b.textContent = n;
        b.onclick = () => { cur = n; draw(); };
        tabs.appendChild(b);
      });
    }
    const g = el('xlGrid');
    if (!book) {
      g.innerHTML = '<div class="xlEmpty">Откройте файл Excel (xlsx, xls, csv, txt) или создайте новую книгу.<br>Правка ячеек: двойной щелчок по ячейке, Enter — готово.</div>';
      return;
    }
    const aoa = E().toAoa(book, cur);
    const ref = E().usedRange(book, cur);
    const cols = Math.min(30, (function () {
      let n = 1;
      aoa.forEach((r) => { if (r && r.length > n) n = r.length; });
      return n;
    })());
    const rows = Math.min(300, Math.max(1, aoa.length));
    let h = '<table><thead><tr><th></th>';
    for (let c = 0; c < cols; c++) h += '<th>' + colName(c) + '</th>';
    h += '</tr></thead><tbody>';
    for (let r = 0; r < rows; r++) {
      h += '<tr><th>' + (r + 1) + '</th>';
      for (let c = 0; c < cols; c++) {
        const cell = (aoa[r] && aoa[r][c] !== undefined) ? aoa[r][c] : '';
        const isNum = typeof cell === 'number';
        h += '<td data-a="' + colName(c) + (r + 1) + '"' + (isNum ? ' class="num"' : '') + '>' + esc(cell) + '</td>';
      }
      h += '</tr>';
    }
    h += '</tbody></table>';
    g.innerHTML = h;
    g.querySelectorAll('td[data-a]').forEach((td) => {
      td.addEventListener('dblclick', () => {
        td.setAttribute('contenteditable', 'true');
        td.focus();
        document.execCommand && document.execCommand('selectAll', false, null);
      });
      td.addEventListener('blur', () => {
        if (td.getAttribute('contenteditable') !== 'true') return;
        td.removeAttribute('contenteditable');
        const addr = td.getAttribute('data-a');
        const text = td.textContent.trim();
        if (text === '') E().setCell(book, cur, addr, null);
        /* Если начали с «=» — это формула: сохраняем как формулу, а не как текст */
        else if (text.charAt(0) === '=') E().setCell(book, cur, addr, null, text);
        else if (/^-?\d+([.,]\d+)?$/.test(text)) E().setCell(book, cur, addr, Number(text.replace(',', '.')));
        else E().setCell(book, cur, addr, text);
        dirty = true;
        msg('Записано: ' + addr + ' = ' + (text || '(пусто)') + '  · не забудьте «Сохранить»');
        draw();
      });
      td.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); td.blur(); } });
    });
    const m = el('xlMsg');
    if (m && !m.textContent) m.textContent = 'Диапазон: ' + ref + ' · лист «' + cur + '»';
  }

  function colName(i) {
    let s = '';
    i = Number(i) || 0;
    do { s = String.fromCharCode(65 + (i % 26)) + s; i = Math.floor(i / 26) - 1; } while (i >= 0);
    return s;
  }

  function doSave() {
    if (!book) { msg('Сначала откройте файл или создайте книгу'); return; }
    try {
      const out = E().save(book, book.fileName && /\.xlsx$/i.test(book.fileName) ? book.fileName : 'книга.xlsx');
      const blob = new Blob([out.bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = out.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      dirty = false; draw();
      msg('Сохранено: ' + out.name + ' · ' + Math.round(out.bytes.length / 1024) + ' КБ');
    } catch (e) {
      msg('Не удалось сохранить: ' + ((e && e.message) || e));
    }
  }

  function open() {
    mount();
    el('xlView').classList.add('on');
    draw();
  }
  function close() { const v = el('xlView'); if (v) v.classList.remove('on'); }

  root.ExcelUI = { open, close, mount };
})(typeof window !== 'undefined' ? window : this);
