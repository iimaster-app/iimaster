'use strict';

/**
 * Дашборд (этап 6, 30.10.2026).
 *
 * Задача: из обычного листа (массив строк) собрать готовый дашборд — KPI-карточки,
 * несколько графиков и фильтр по периоду. Без внешних библиотек, чистые функции:
 * так его можно проверить в Node и потом отрисовать в приложении как HTML.
 *
 * Как понимает данные (без ручной настройки):
 *   - шапка = первая строка;
 *   - текстовые колонки — подписи (периоды/категории), числовые — показатели;
 *   - первая числовая колонка считается главной («сумма»), вторая — «расход», если её имя
 *     похоже на расходы/затраты; иначе считаем её вторым показателем;
 *   - если есть колонка с датой/месяцем — строим динамику, иначе — по категориям.
 *
 * Ограничения честно: это дашборд НА ЭКРАНЕ и в отчёте; в .xlsx он пока не пишется.
 */
(function (root) {
  const num = (v) => {
    if (typeof v === 'number' && isFinite(v)) return v;
    const s = String(v === undefined || v === null ? '' : v).replace(/\s/g, '').replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : null;
  };
  const isNumCol = (aoa, c) => {
    let n = 0, t = 0;
    for (let r = 1; r < aoa.length; r++) {
      const v = aoa[r] && aoa[r][c];
      if (v === '' || v === undefined || v === null) continue;
      t++;
      if (num(v) !== null) n++;
    }
    return t > 0 && n / t >= 0.8;
  };
  const fmt = (n) => {
    const a = Math.abs(n);
    if (a >= 1e9) return (n / 1e9).toFixed(1).replace('.', ',') + ' млрд';
    if (a >= 1e6) return (n / 1e6).toFixed(1).replace('.', ',') + ' млн';
    if (a >= 1000) return Math.round(n).toLocaleString('ru-RU');
    return String(Math.round(n * 100) / 100).replace('.', ',');
  };
  const isCost = (name) => /расход|затрат|издерж|cost|expense|себестоим|списан/i.test(String(name || ''));
  const isDate = (name) => /дата|date|месяц|month|период|период|квартал|week|недел|день|year|год/i.test(String(name || ''));

  /* Разбор листа в схему: какие колонки подписи, какие числа, где расходы. */
  function analyze(aoa) {
    const rows = (aoa || []).filter((r) => Array.isArray(r));
    if (rows.length < 2) return { ok: false, error: 'В листе слишком мало данных (нужна шапка и хотя бы одна строка).' };
    const header = rows[0].map((h) => String(h === undefined || h === null ? '' : h).trim());
    const cols = header.map((name, i) => ({ i: i, name: name || ('Колонка ' + (i + 1)), numeric: isNumCol(rows, i) }));
    const label = cols.find((c) => !c.numeric) || cols[0];
    const numeric = cols.filter((c) => c.numeric && c.i !== label.i);
    if (!numeric.length) return { ok: false, error: 'Не нашёл числовых колонок — дашборд строить не из чего.' };
    const main = numeric[0];
    const second = numeric.find((c) => c !== main && isCost(c.name)) || numeric[1] || null;
    const body = rows.slice(1);
    return { ok: true, header: header, cols: cols, label: label, main: main, second: second, body: body, hasDates: isDate(label.name) };
  }

  function sumOf(body, c) {
    return body.reduce((s, r) => { const v = num(r && r[c]); return s + (v === null ? 0 : v); }, 0);
  }

  /* KPI: сумма, среднее, максимум, количество строк; если есть «расходы» — ещё прибыль и маржа. */
  function kpis(model) {
    const main = sumOf(model.body, model.main.i);
    const values = model.body.map((r) => num(r && r[model.main.i])).filter((v) => v !== null);
    const out = [
      { key: 'sum', title: 'Всего: ' + model.main.name, value: fmt(main), raw: main },
      { key: 'avg', title: 'В среднем', value: fmt(values.length ? main / values.length : 0) },
      { key: 'max', title: 'Максимум', value: fmt(values.length ? Math.max.apply(null, values) : 0) },
      { key: 'rows', title: 'Строк данных', value: String(model.body.length) },
    ];
    if (model.second && isCost(model.second.name)) {
      const cost = sumOf(model.body, model.second.i);
      const profit = main - cost;
      out.push({ key: 'cost', title: 'Расходы', value: fmt(cost), raw: cost });
      out.push({ key: 'profit', title: 'Прибыль', value: fmt(profit), raw: profit, good: profit >= 0 });
      out.push({ key: 'margin', title: 'Маржа', value: (main ? Math.round(profit / main * 1000) / 10 : 0) + ' %', raw: main ? profit / main : 0 });
    }
    return out;
  }

  /* Ряды для графиков: динамика по подписям (в порядке листа) и топ-5 по значению. */
  function series(model) {
    const cats = [], vals = [], costs = [];
    model.body.forEach((r) => {
      const v = num(r && r[model.main.i]);
      if (v === null) return;
      cats.push(String((r && r[model.label.i]) === undefined ? '' : r[model.label.i]));
      vals.push(v);
      if (model.second && isCost(model.second.name)) costs.push(num(r && r[model.second.i]) || 0);
    });
    const top = cats.map((c, i) => ({ c: c, v: vals[i] })).sort((a, b) => b.v - a.v).slice(0, 5);
    return { cats: cats, vals: vals, costs: costs, top: top };
  }

  /* Фильтр по периоду: последние N точек (по умолчанию 12) либо всё. */
  function filterPeriod(ser, points) {
    const n = Number(points) || 0;
    if (!n || n >= ser.cats.length) return ser;
    const cut = ser.cats.length - n;
    return {
      cats: ser.cats.slice(cut), vals: ser.vals.slice(cut),
      costs: ser.costs.length ? ser.costs.slice(cut) : [],
      top: ser.top,
    };
  }

  /* Готовый HTML дашборда. charts: функция (kind, series) -> SVG (передаём снаружи). */
  function render(aoa, opts) {
    const o = opts || {};
    const model = analyze(aoa);
    if (!model.ok) return { ok: false, error: model.error, html: '' };
    const all = series(model);
    const shown = filterPeriod(all, o.points);
    const k = kpis(model);
    const chart = typeof o.chart === 'function' ? o.chart : null;
    const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    let html = '<div class="dash">';
    html += '<div class="dashKpis">';
    k.forEach((x) => {
      html += '<div class="dashKpi"><div class="dashKTitle">' + esc(x.title) + '</div><div class="dashKVal'
        + (x.good === false ? ' bad' : '') + '">' + esc(x.value) + '</div></div>';
    });
    html += '</div>';
    if (chart) {
      html += '<div class="dashChart"><div class="dashCTitle">' + (model.hasDates ? 'Динамика' : 'По категориям') + ': ' + esc(model.main.name) + '</div>'
        + chart(model.hasDates ? 'line' : 'bar', { cats: shown.cats, vals: shown.vals, title: model.main.name }) + '</div>';
      if (model.second && isCost(model.second.name)) {
        html += '<div class="dashChart"><div class="dashCTitle">' + esc(model.main.name) + ' и ' + esc(model.second.name) + '</div>'
          + chart('bar', { cats: shown.cats, vals: shown.vals, title: '' }) + '</div>';
      }
      if (shown.top.length) {
        html += '<div class="dashChart"><div class="dashCTitle">Топ-5</div>'
          + chart('pie', { cats: shown.top.map((t) => t.c), vals: shown.top.map((t) => t.v), title: 'Топ-5' }) + '</div>';
      }
    }
    html += '<div class="dashFoot">Периодов: ' + shown.cats.length + ' из ' + all.cats.length
      + ' · главный показатель: «' + esc(model.main.name) + '»'
      + (model.second ? ' · второй: «' + esc(model.second.name) + '»' : '') + '</div>';
    html += '</div>';
    return { ok: true, html: html, model: model, series: all, shown: shown, kpis: k };
  }

  const api = { analyze, kpis, series, filterPeriod, render };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelDash = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
