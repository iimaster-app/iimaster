'use strict';

/**
 * Аналитика таблицы (этап 7, 30.10.2026).
 *
 * Задача: по обычному листу найти проблемы и объяснить их человеческим языком —
 * дубликаты, пропуски, выбросы, отрицательные значения там, где их быть не должно,
 * тренд, доля топ-3, «дыры» в периодах.
 *
 * Принципы:
 *  - ничего не выдумываем: если данных мало, так и говорим;
 *  - каждое замечание содержит конкретику (сколько строк, какие значения, какой столбец);
 *  - чистые функции без DOM — проверяются в Node.
 */
(function (root) {
  const num = (v) => {
    if (typeof v === 'number' && isFinite(v)) return v;
    const s = String(v === undefined || v === null ? '' : v).replace(/\s/g, '').replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : null;
  };
  const fmt = (n) => {
    const a = Math.abs(n);
    if (a >= 1e6) return (n / 1e6).toFixed(1).replace('.', ',') + ' млн';
    if (a >= 1000) return Math.round(n).toLocaleString('ru-RU');
    return String(Math.round(n * 100) / 100).replace('.', ',');
  };
  const isNumCol = (rows, c) => {
    let n = 0, t = 0;
    for (let r = 1; r < rows.length; r++) {
      const v = rows[r] && rows[r][c];
      if (v === '' || v === undefined || v === null) continue;
      t++;
      if (num(v) !== null) n++;
    }
    return { numeric: t > 0 && n / t >= 0.8, filled: t, empty: (rows.length - 1) - t };
  };

  function audit(aoa) {
    const rows = (aoa || []).filter((r) => Array.isArray(r));
    if (rows.length < 2) return { ok: false, error: 'Слишком мало данных: нужна шапка и хотя бы одна строка.', issues: [], text: '' };
    const header = rows[0].map((h) => String(h === undefined || h === null ? '' : h).trim());
    const body = rows.slice(1).filter((r) => r && r.some((v) => v !== '' && v !== null && v !== undefined));
    const nCols = Math.max.apply(null, rows.map((r) => r.length));
    const issues = [];

    /* 1. Пропуски */
    let emptyCells = 0;
    const emptyByCol = [];
    for (let c = 0; c < nCols; c++) {
      let e = 0;
      body.forEach((r) => { const v = r[c]; if (v === '' || v === null || v === undefined) e++; });
      emptyCells += e;
      if (e > 0) emptyByCol.push({ col: header[c] || ('Колонка ' + (c + 1)), n: e });
    }
    if (emptyCells) {
      const worst = emptyByCol.slice().sort((a, b) => b.n - a.n)[0];
      issues.push({
        kind: 'empty', level: 'warn',
        text: 'Пустых ячеек: ' + emptyCells + '. Больше всего в «' + worst.col + '» — ' + worst.n + '.',
      });
    }

    /* 2. Дубликаты строк (сравниваем по всем колонкам) */
    const seen = new Map();
    body.forEach((r, i) => {
      const key = r.map((v) => String(v === undefined || v === null ? '' : v).trim().toLowerCase()).join('|');
      if (!key.replace(/\|/g, '')) return;
      if (!seen.has(key)) seen.set(key, []);
      seen.get(key).push(i + 2);   /* +2: строка шапки и нумерация с единицы */
    });
    const dups = [];
    seen.forEach((where) => { if (where.length > 1) dups.push(where); });
    if (dups.length) {
      const first = dups[0];
      issues.push({
        kind: 'duplicates', level: 'warn',
        text: 'Полных дубликатов строк: ' + dups.length + '. Например, строки ' + first.slice(0, 4).join(', ')
          + (first.length > 4 ? ' и ещё ' + (first.length - 4) : '') + ' совпадают целиком.',
      });
    }

    /* 3. Числовые колонки: выбросы (правило 3 сигм) и отрицательные значения */
    const numericCols = [];
    for (let c = 0; c < nCols; c++) {
      const inf = isNumCol(rows, c);
      if (!inf.numeric) continue;
      const vals = body.map((r) => num(r[c])).filter((v) => v !== null);
      if (vals.length < 4) continue;
      const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
      const sd = Math.sqrt(vals.reduce((a, v) => a + (v - mean) * (v - mean), 0) / vals.length);
      /* Выбросы ищем по квартилям (правило 1,5 межквартильного размаха) — на малых выборках
         правило 3 сигм молчит, потому что сам выброс раздувает отклонение. */
      const sorted = vals.slice().sort((a, b) => a - b);
      const q = (p) => {
        const pos = (sorted.length - 1) * p;
        const lo = Math.floor(pos), hi = Math.ceil(pos);
        return lo === hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo);
      };
      const q1 = q(0.25), q3 = q(0.75), iqr = q3 - q1;
      const outliers = iqr > 0
        ? vals.filter((v) => v < q1 - 1.5 * iqr || v > q3 + 1.5 * iqr)
        : vals.filter((v) => sd > 0 && Math.abs(v - mean) > 3 * sd);
      const negatives = vals.filter((v) => v < 0).length;
      numericCols.push({ name: header[c] || ('Колонка ' + (c + 1)), mean: mean, sd: sd, vals: vals, outliers: outliers, negatives: negatives });
      if (outliers.length) {
        issues.push({
          kind: 'outliers', level: 'warn',
          text: 'В «' + (header[c] || ('Колонка ' + (c + 1))) + '» ' + outliers.length + ' резких выброс'
            + (outliers.length === 1 ? '' : 'а') + ': ' + outliers.slice(0, 3).map(fmt).join(', ')
            + ' при среднем ' + fmt(mean) + '. Проверьте, не опечатка ли.',
        });
      }
      if (negatives) {
        issues.push({
          kind: 'negatives', level: 'info',
          text: 'В «' + (header[c] || ('Колонка ' + (c + 1))) + '» ' + negatives + ' отрицательн'
            + (negatives === 1 ? 'ое значение' : 'ых значений') + ' — проверьте, так и должно быть.',
        });
      }
    }

    /* 4. Тренд по главному числовому столбцу: сравнение первой и второй половины */
    let trend = null;
    if (numericCols.length) {
      const col = numericCols[0];
      const h = Math.floor(col.vals.length / 2);
      if (h >= 2) {
        const firstHalf = col.vals.slice(0, h).reduce((a, b) => a + b, 0) / h;
        const lastHalf = col.vals.slice(-h).reduce((a, b) => a + b, 0) / h;
        if (firstHalf !== 0) {
          const pct = (lastHalf - firstHalf) / Math.abs(firstHalf) * 100;
          trend = { name: col.name, pct: pct, from: firstHalf, to: lastHalf };
        }
      }
    }

    /* 5. Доля топ-3, если есть колонка подписей */
    let topShare = null;
    if (numericCols.length) {
      const col = numericCols[0];
      const total = col.vals.reduce((a, b) => a + b, 0);
      if (total !== 0) {
        const sorted = col.vals.slice().sort((a, b) => b - a).slice(0, 3);
        topShare = { pct: sorted.reduce((a, b) => a + b, 0) / total * 100, name: col.name };
      }
    }

    return {
      ok: true,
      issues: issues,
      steps: body.length,
      cols: nCols,
      trend: trend,
      topShare: topShare,
      text: summarize(issues, trend, topShare, body.length),
    };
  }

  /* Итог человеческим языком: что нашли, что делать, что смотреть дальше. */
  function summarize(issues, trend, topShare, n) {
    const out = [];
    out.push('Проверил ' + n + ' строк. ' + (issues.length ? 'Замечаний: ' + issues.length + '.' : 'Явных проблем не нашёл.'));
    issues.forEach((i) => out.push('• ' + i.text));
    if (trend) {
      const dir = trend.pct >= 0 ? 'вырос' : 'упал';
      out.push('• Динамика по «' + trend.name + '»: вторая половина периода ' + dir + ' на '
        + Math.abs(Math.round(trend.pct * 10) / 10) + ' % (было ' + fmt(trend.from) + ' → стало ' + fmt(trend.to) + ').');
    }
    if (topShare) {
      out.push('• Топ-3 даёт ' + Math.round(topShare.pct) + ' % всего объёма по «' + topShare.name + '».'
        + (topShare.pct >= 70 ? ' Сильная зависимость от нескольких позиций — риск.' : ''));
    }
    if (!issues.length && !trend) out.push('• Данных мало для выводов — добавьте больше строк, тогда смогу сказать про динамику.');
    return out.join('\n');
  }

  const api = { audit, summarize };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelAnalytics = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
