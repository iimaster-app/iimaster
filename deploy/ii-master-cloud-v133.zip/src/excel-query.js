'use strict';

/**
 * Power Query (этап 8, 30.10.2026).
 *
 * Честно о границах: движка языка M от Microsoft вне Excel не существует. Поэтому:
 *   - ПРЕОБРАЗОВАНИЯ выполняем сами (это настоящая работа с данными, а не картинка);
 *   - M-код ГЕНЕРИРУЕМ как текст, который можно вставить в Excel — и прямо это помечаем.
 * Подмены «сделали вид, что выполнили M» здесь нет: либо данные реально преобразованы,
 * либо в отчёте написано, что это только текст для Excel.
 *
 * Всё чистыми функциями: проверяется в Node, работает и в браузере, и на телефоне.
 */
(function (root) {
  const num = (v) => {
    if (typeof v === 'number' && isFinite(v)) return v;
    const s = String(v === undefined || v === null ? '' : v).replace(/\s/g, '').replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : null;
  };
  const norm = (s) => String(s === undefined || s === null ? '' : s).trim().toLowerCase();

  /* ---------- импорт ---------- */

  /* CSV/TSV: свой разбор с кавычками (иначе «Иванов, Иван» рвёт строку) */
  function parseCsv(text, opts) {
    const o = opts || {};
    const sep = o.sep || (String(text).indexOf('\t') >= 0 && String(text).indexOf(';') < 0 ? '\t' : (String(text).split('\n')[0].split(';').length > String(text).split('\n')[0].split(',').length ? ';' : ','));
    const rows = [];
    let row = [], cell = '', q = false;
    const s = String(text).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if (q) {
        if (ch === '"' && s[i + 1] === '"') { cell += '"'; i++; }
        else if (ch === '"') q = false;
        else cell += ch;
      } else if (ch === '"') q = true;
      else if (ch === sep) { row.push(cell); cell = ''; }
      else if (ch === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
      else cell += ch;
    }
    if (cell.length || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.some((c) => String(c).trim() !== ''));
  }

  /* JSON -> таблица: массив объектов; вложенные значения разворачиваем в «a.b» */
  function parseJson(text) {
    const data = typeof text === 'string' ? JSON.parse(text) : text;
    const arr = Array.isArray(data) ? data : (Array.isArray(data && data.data) ? data.data : [data]);
    if (!arr.length) return [[]];
    const flat = (obj, prefix, out) => {
      Object.keys(obj || {}).forEach((k) => {
        const v = obj[k];
        const key = prefix ? prefix + '.' + k : k;
        if (v && typeof v === 'object' && !Array.isArray(v)) flat(v, key, out);
        else out[key] = Array.isArray(v) ? v.join('; ') : v;
      });
      return out;
    };
    const objs = arr.map((x) => flat(x, '', {}));
    const cols = [];
    objs.forEach((o) => Object.keys(o).forEach((k) => { if (cols.indexOf(k) < 0) cols.push(k); }));
    const rows = [cols].concat(objs.map((o) => cols.map((c) => (o[c] === undefined ? '' : o[c]))));
    return rows;
  }

  /* ---------- преобразования ---------- */

  function filterRows(aoa, colIndex, test) {
    if (!aoa || aoa.length < 2) return aoa || [[]];
    const head = aoa[0], body = aoa.slice(1);
    return [head].concat(body.filter((r) => test(r[colIndex], r)));
  }

  function sortRows(aoa, colIndex, desc) {
    if (!aoa || aoa.length < 2) return aoa || [[]];
    const head = aoa[0], body = aoa.slice(1);
    const cmp = (a, b) => {
      const x = num(a[colIndex]), y = num(b[colIndex]);
      if (x !== null && y !== null) return x - y;
      return String(a[colIndex] === undefined ? '' : a[colIndex]).localeCompare(String(b[colIndex] === undefined ? '' : b[colIndex]), 'ru');
    };
    body.sort((a, b) => (desc ? -cmp(a, b) : cmp(a, b)));
    return [head].concat(body);
  }

  function dedupe(aoa) {
    if (!aoa || aoa.length < 2) return aoa || [[]];
    const seen = new Set(), out = [aoa[0]];
    aoa.slice(1).forEach((r) => {
      const k = r.map((v) => norm(v)).join('|');
      if (seen.has(k)) return;
      seen.add(k); out.push(r);
    });
    return out;
  }

  function dropEmptyRows(aoa) {
    if (!aoa || !aoa.length) return [[]];
    return [aoa[0]].concat(aoa.slice(1).filter((r) => r && r.some((v) => String(v === undefined || v === null ? '' : v).trim() !== '')));
  }

  /* Группировка: по колонке-подписи, суммы/средние по остальным числовым */
  function groupBy(aoa, colIndex) {
    if (!aoa || aoa.length < 2) return aoa || [[]];
    const head = aoa[0];
    const ci = colIndex === undefined ? 0 : colIndex;
    const numericCols = [];
    for (let c = 0; c < head.length; c++) {
      if (c === ci) continue;
      const vals = aoa.slice(1).map((r) => num(r[c])).filter((v) => v !== null);
      if (vals.length >= Math.max(1, (aoa.length - 1) * 0.8)) numericCols.push(c);
    }
    const groups = new Map();
    aoa.slice(1).forEach((r) => {
      const key = String(r[ci] === undefined || r[ci] === null ? '' : r[ci]);
      if (!groups.has(key)) groups.set(key, { n: 0, sums: {}, counts: {} });
      const g = groups.get(key);
      g.n++;
      numericCols.forEach((c) => {
        const v = num(r[c]);
        if (v === null) return;
        g.sums[c] = (g.sums[c] || 0) + v;
        g.counts[c] = (g.counts[c] || 0) + 1;
      });
    });
    const outHead = [head[ci] || 'Категория', 'Строк'].concat(
      numericCols.reduce((acc, c) => acc.concat(['Сумма: ' + (head[c] || c), 'Среднее: ' + (head[c] || c)]), []));
    const out = [outHead];
    groups.forEach((g, key) => {
      const row = [key, g.n];
      numericCols.forEach((c) => {
        const s = g.sums[c] || 0, n = g.counts[c] || 0;
        row.push(Math.round(s * 100) / 100, n ? Math.round(s / n * 100) / 100 : '');
      });
      out.push(row);
    });
    return out;
  }

  /* Объединение таблиц с проверкой структуры: колонки сопоставляем по имени, а не по позиции */
  function union(tables) {
    const list = (tables || []).filter((t) => t && t.length);
    if (!list.length) return { aoa: [[]], report: { ok: false, error: 'Нет таблиц для объединения' } };
    const cols = [];
    list.forEach((t) => (t[0] || []).forEach((c) => { const n = String(c); if (cols.indexOf(n) < 0) cols.push(n); }));
    const mismatches = [];
    list.forEach((t, i) => {
      const h = (t[0] || []).map(String);
      const missing = cols.filter((c) => h.indexOf(c) < 0);
      const extra = h.filter((c) => (list[0][0] || []).map(String).indexOf(c) < 0);
      if (missing.length || extra.length) mismatches.push({ table: i + 1, missing: missing, extra: extra });
    });
    const out = [cols];
    let rows = 0;
    list.forEach((t) => {
      const h = (t[0] || []).map(String);
      const idx = cols.map((c) => h.indexOf(c));
      t.slice(1).forEach((r) => {
        if (!r || !r.some((v) => String(v === undefined || v === null ? '' : v).trim() !== '')) return;
        out.push(idx.map((i) => (i < 0 ? '' : (r[i] === undefined ? '' : r[i]))));
        rows++;
      });
    });
    return { aoa: out, report: { ok: true, tables: list.length, rows: rows, cols: cols.length, mismatches: mismatches } };
  }

  /* ---------- M-код (текст для Excel, НЕ исполняется здесь) ---------- */

  function mCode(sheetName, steps) {
    const name = String(sheetName || 'Данные').replace(/"/g, '""');
    const src = 'Excel.CurrentWorkbook(){[Name="' + name + '"]}[Content]';
    const lines = ['let', '    Источник = ' + src + ','];
    (steps || []).forEach((s, i) => {
      lines.push('    Шаг' + (i + 1) + ' = ' + s + (i === (steps || []).length - 1 ? '' : ','));
    });
    lines.push('in');
    lines.push('    Шаг' + ((steps || []).length || 1));
    return lines.join('\n');
  }

  const api = { parseCsv, parseJson, filterRows, sortRows, dedupe, dropEmptyRows, groupBy, union, mCode };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelQuery = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
