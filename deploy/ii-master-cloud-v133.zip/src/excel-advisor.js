'use strict';

/**
 * Советник автоматизации (этап 10, 30.10.2026).
 *
 * Задача: заметить, что человек делает одно и то же несколько раз в Excel, и предложить
 * собрать из этого макрос. Запуск — ТОЛЬКО после явного согласия (consent), без него
 * выполнение не начинается: это требование ТЗ и просто здравый смысл.
 *
 * Чистые функции: проверяются в Node, ничего не рисуют и никуда не ходят.
 */
(function (root) {
  const TITLES = {
    dedupe: 'убираете дубликаты строк',
    dropEmpty: 'убираете пустые строки',
    group: 'делаете свод по колонке',
    sortDesc: 'сортируете по убыванию',
    sortAsc: 'сортируете по возрастанию',
    filterGt: 'фильтруете по числу',
    union: 'объединяете таблицы',
    dashboard: 'строите дашборд',
    chart: 'строите диаграмму',
    analysis: 'запускаете анализ',
  };

  /* Журнал действий пользователя. Храним только вид операции — без данных листа. */
  function record(history, action) {
    const list = Array.isArray(history) ? history.slice(-60) : [];
    const id = String(action || '');
    if (!id || !TITLES[id]) return list;
    list.push({ id: id, at: new Date().toISOString() });
    return list.slice(-60);
  }

  /* Ищем повтор: одна и та же операция не меньше `need` раз за последние `window` действий. */
  function suggest(history, opts) {
    const o = opts || {};
    const need = Number(o.need) || 3;
    const win = Number(o.window) || 20;
    const list = (Array.isArray(history) ? history : []).slice(-win);
    const counts = {};
    list.forEach((a) => { const id = a && a.id; if (id && TITLES[id]) counts[id] = (counts[id] || 0) + 1; });
    const best = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
    if (!best || counts[best] < need) return { ok: false };
    /* Предлагаем цепочку: повторяемый шаг + чистка, если её ещё не делали рядом */
    const steps = [{ id: 'dropEmpty' }];
    if (best !== 'dedupe') steps.push({ id: 'dedupe' });
    steps.push({ id: best });
    return {
      ok: true,
      action: best,
      count: counts[best],
      steps: steps,
      text: 'Вы уже ' + counts[best] + ' раза ' + (TITLES[best] || best)
        + '. Хотите, соберу из этого макрос и буду делать это одной кнопкой? Запускать без вашего согласия не буду.',
    };
  }

  /* Согласие: явное «да» от человека. Без него run не выполняется. */
  function canRun(consent) {
    if (consent === true) return { ok: true };
    return { ok: false, error: 'Нужно согласие человека: автоматизация без подтверждения не запускается.' };
  }

  /* Выполнение предложения: только при согласии. runner — функция, которая реально применяет шаги. */
  function accept(suggestion, consent, runner) {
    const gate = canRun(consent);
    if (!gate.ok) return { ok: false, error: gate.error };
    if (!suggestion || !suggestion.ok) return { ok: false, error: 'Нет предложения для запуска' };
    if (typeof runner !== 'function') return { ok: false, error: 'Нет исполнителя шагов' };
    try {
      const out = runner(suggestion.steps);
      return { ok: true, result: out, steps: suggestion.steps };
    } catch (e) {
      return { ok: false, error: 'Не удалось выполнить: ' + ((e && e.message) || e) };
    }
  }

  const api = { record, suggest, canRun, accept, TITLES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ExcelAdvisor = api;
})(typeof window !== 'undefined' ? window : (typeof global !== 'undefined' ? global : this));
