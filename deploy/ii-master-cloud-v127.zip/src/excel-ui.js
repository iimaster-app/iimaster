'use strict';

/**
 * Экран Excel (этап 3, 30.10.2026).
 *
 * Что делает: открывает настоящий файл, показывает сетку с листами, даёт править ячейки
 * и сохранять книгу. Работает на движке из этапа 2 (src/excel.js + SheetJS).
 *
 * Чего ещё НЕТ (честно, чтобы не искать): формул в интерфейсе (движок их читает и хранит,
 * но ввода формулы с пересчётом пока нет), диаграмм, дашбордов, Power Query, макросов.
 * Всё это - следующие этапы.
 */
(function (root) {
  const E = () => root.ExcelEngine;
  let book = null;
  let cur = null;         /* текущий лист */
  let dirty = false;

  const style = document.createElement('style');
  style.textContent = `
  #xlView{position:fixed;inset:0;z-index:9000;background:#0d0819;display:none;flex-direction:column;
    font:13px/1.35 system-ui,sans-serif;color:#efe9ff}
  #xlView.on{display:flex}
  .xlTop{display:flex;align-items:center;gap:8px;padding:calc(10px + env(safe-area-inset-top,0px)) 12px 10px;
    border-bottom:1px solid #2b2346;flex:none;flex-wrap:wrap}
  .xlName{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:40vw}
  .xlBtn{padding:7px 11px;border-radius:10px;border:1px solid #5a3fa0;background:#1b1430;color:#efe9ff;
    cursor:pointer;font:600 12.5px system-ui,sans-serif}
  .xlBtn:active{transform:translateY(1px)}
  .xlBtn.p{background:#6b4bd6;border-color:#6b4bd6}
  .xlX{margin-left:auto;border:0;background:none;color:#b9a6f5;font-size:22px;cursor:pointer;padding:0 4px}
  .xlTabs{display:flex;gap:6px;overflow-x:auto;padding:8px 12px;border-bottom:1px solid #2b2346;flex:none}
  .xlTab{padding:5px 11px;border-radius:9px;background:#171027;border:1px solid #33285a;cursor:pointer;white-space:nowrap}
  .xlTab.on{background:#6b4bd6;border-color:#6b4bd6;color:#fff}
  .xlGrid{flex:1;overflow:auto;padding:0 0 20px}
  .xlGrid table{border-collapse:collapse;font-size:12.5px}
  .xlGrid th,.xlGrid td{border:1px solid #2b2346;padding:4px 8px;min-width:78px;max-width:320px;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:26px}
  .xlGrid th{background:#171027;color:#b9a6f5;position:sticky;top:0;z-index:2;font-weight:600}
  .xlGrid td[contenteditable="true"]{outline:2px solid #6b4bd6;background:#1b1430;white-space:pre-wrap}
  .xlGrid td.num{color:#8ef0c0}
  .xlEmpty{padding:26px;color:#b9a6f5;text-align:center;line-height:1.6}
  .xlMsg{padding:6px 12px;color:#b9a6f5;font-size:12px;flex:none;min-height:18px}
  `;
  document.head.appendChild(style);

  function el(id) { return document.getElementById(id); }
  function esc(s) { return String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function msg(t) { const m = el('xlMsg'); if (m) m.textContent = t || ''; }

  function mount() {
    if (el('xlView')) return;
    const v = document.createElement('div');
    v.id = 'xlView';
    v.innerHTML = `
      <div class="xlTop">
        <span class="xlName" id="xlName">Таблица</span>
        <button class="xlBtn" id="xlOpen">Открыть</button>
        <button class="xlBtn p" id="xlSave">Сохранить</button>
        <button class="xlBtn" id="xlAdd">+ Лист</button>
        <button class="xlBtn" id="xlNew">Новая книга</button>
        <button class="xlX" id="xlClose" title="Закрыть">×</button>
      </div>
      <div class="xlTabs" id="xlTabs"></div>
      <div class="xlMsg" id="xlMsg"></div>
      <div class="xlGrid" id="xlGrid"></div>
      <input type="file" id="xlFile" accept=".xlsx,.xlsm,.xls,.csv,.txt,.tsv" style="display:none">`;
    document.body.appendChild(v);

    el('xlClose').onclick = close;
    el('xlOpen').onclick = () => el('xlFile').click();
    el('xlSave').onclick = doSave;
    el('xlNew').onclick = () => { book = E().create(); cur = E().sheetNames(book)[0]; dirty = false; draw(); msg('Новая книга создана'); };
    el('xlAdd').onclick = () => {
      if (!book) { msg('Сначала откройте файл или создайте книгу'); return; }
      cur = E().addSheet(book, 'Лист' + (E().sheetNames(book).length + 1));
      dirty = true; draw();
    };
    el('xlFile').onchange = async (ev) => {
      const f = ev.target.files && ev.target.files[0];
      ev.target.value = '';
      if (!f) return;
      msg('Открываю «' + f.name + '»…');
      try {
        book = await E().open(f, f.name);
        cur = E().sheetNames(book)[0];
        dirty = false;
        draw();
        msg('Открыто: ' + f.name + ' · листов: ' + E().sheetNames(book).length);
      } catch (e) {
        msg('Не удалось открыть файл: ' + ((e && e.message) || e));
      }
    };
  }

  function draw() {
    const nameEl = el('xlName'); if (nameEl) nameEl.textContent = book ? (book.fileName + (dirty ? ' •' : '')) : 'Таблица';
    const tabs = el('xlTabs');
    tabs.innerHTML = '';
    if (book) {
      E().sheetNames(book).forEach((n) => {
        const b = document.createElement('div');
        b.className = 'xlTab' + (n === cur ? ' on' : '');
        b.textContent = n;
        b.onclick = () => { cur = n; draw(); };
        tabs.appendChild(b);
      });
    }
    const g = el('xlGrid');
    if (!book) {
      g.innerHTML = '<div class="xlEmpty">Откройте файл Excel (xlsx, xls, csv, txt) или создайте новую книгу.<br>Правка ячеек: двойной щелчок по ячейке, Enter — готово.</div>';
      return;
    }
    const aoa = E().toAoa(book, cur);
    const ref = E().usedRange(book, cur);
    const cols = Math.min(30, (function () {
      let n = 1;
      aoa.forEach((r) => { if (r && r.length > n) n = r.length; });
      return n;
    })());
    const rows = Math.min(300, Math.max(1, aoa.length));
    let h = '<table><thead><tr><th></th>';
    for (let c = 0; c < cols; c++) h += '<th>' + colName(c) + '</th>';
    h += '</tr></thead><tbody>';
    for (let r = 0; r < rows; r++) {
      h += '<tr><th>' + (r + 1) + '</th>';
      for (let c = 0; c < cols; c++) {
        const cell = (aoa[r] && aoa[r][c] !== undefined) ? aoa[r][c] : '';
        const isNum = typeof cell === 'number';
        h += '<td data-a="' + colName(c) + (r + 1) + '"' + (isNum ? ' class="num"' : '') + '>' + esc(cell) + '</td>';
      }
      h += '</tr>';
    }
    h += '</tbody></table>';
    g.innerHTML = h;
    g.querySelectorAll('td[data-a]').forEach((td) => {
      td.addEventListener('dblclick', () => {
        td.setAttribute('contenteditable', 'true');
        td.focus();
        document.execCommand && document.execCommand('selectAll', false, null);
      });
      td.addEventListener('blur', () => {
        if (td.getAttribute('contenteditable') !== 'true') return;
        td.removeAttribute('contenteditable');
        const addr = td.getAttribute('data-a');
        const text = td.textContent.trim();
        if (text === '') E().setCell(book, cur, addr, null);
        /* Если начали с «=» — это формула: сохраняем как формулу, а не как текст */
        else if (text.charAt(0) === '=') E().setCell(book, cur, addr, null, text);
        else if (/^-?\d+([.,]\d+)?$/.test(text)) E().setCell(book, cur, addr, Number(text.replace(',', '.')));
        else E().setCell(book, cur, addr, text);
        dirty = true;
        msg('Записано: ' + addr + ' = ' + (text || '(пусто)') + '  · не забудьте «Сохранить»');
        draw();
      });
      td.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); td.blur(); } });
    });
    const m = el('xlMsg');
    if (m && !m.textContent) m.textContent = 'Диапазон: ' + ref + ' · лист «' + cur + '»';
  }

  function colName(i) {
    let s = '';
    i = Number(i) || 0;
    do { s = String.fromCharCode(65 + (i % 26)) + s; i = Math.floor(i / 26) - 1; } while (i >= 0);
    return s;
  }

  function doSave() {
    if (!book) { msg('Сначала откройте файл или создайте книгу'); return; }
    try {
      const out = E().save(book, book.fileName && /\.xlsx$/i.test(book.fileName) ? book.fileName : 'книга.xlsx');
      const blob = new Blob([out.bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = out.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      dirty = false; draw();
      msg('Сохранено: ' + out.name + ' · ' + Math.round(out.bytes.length / 1024) + ' КБ');
    } catch (e) {
      msg('Не удалось сохранить: ' + ((e && e.message) || e));
    }
  }

  function open() {
    mount();
    el('xlView').classList.add('on');
    draw();
  }
  function close() { const v = el('xlView'); if (v) v.classList.remove('on'); }

  root.ExcelUI = { open, close, mount };
})(typeof window !== 'undefined' ? window : this);
